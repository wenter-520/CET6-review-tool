/* ============================================================
   store.js — 数据目录探测 / IndexedDB / 词库加载
   ============================================================ */
(function () {
  'use strict';

  /* ============================================================
     Store —— 数据目录
     ============================================================ */
  window.Store = {
    base: null,
    files: [],
    mode: 'http',

    async init() {
      const candidates = [
        new URL('../', location.href),
        new URL('./', location.href)
      ];
      for (let i = 0; i < candidates.length; i++) {
        const files = await this._probe(candidates[i]);
        if (files) {
          this.base = candidates[i];
          this.files = files;
          return true;
        }
      }
      return false;
    },

    async _probe(url) {
      try {
        const r = await fetch(url.href, { cache: 'no-store' });
        if (r.ok) {
          const html = await r.text();
          const files = parseDirLinks(html);
          if (files.length && files.some(f => /\.xlsx$/i.test(f))) return files;
        }
      } catch (e) { /* ignore */ }

      try {
        const r2 = await fetch(new URL(AUX_SYNONYMS, url).href, { cache: 'no-store' });
        if (r2.ok) return [AUX_SYNONYMS];
      } catch (e) { /* ignore */ }

      try {
        const r3 = await fetch(new URL(AUX_TYPO_HINTS, url).href, { cache: 'no-store' });
        if (r3.ok) return [AUX_TYPO_HINTS];
      } catch (e) { /* ignore */ }

      return null;
    },

    url(name) { return new URL(name, this.base).href; },

    async readText(name) {
      const r = await fetch(this.url(name), { cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    },
    async readJSON(name) {
      try {
        const t = await this.readText(name);
        return JSON.parse(t);
      } catch (e) { return null; }
    },
    async readBuffer(name) {
      const r = await fetch(this.url(name), { cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.arrayBuffer();
    },

    listStudyXlsx() {
      const out = [];
      for (let i = 0; i < this.files.length; i++) {
        const f = this.files[i];
        const lf = f.toLowerCase();
        if (!lf.endsWith('.xlsx')) continue;
        if (lf.indexOf('~$') === 0) continue;
        let excluded = false;
        for (let e = 0; e < EXPORT_NAMES.length; e++) {
          if (f.indexOf(EXPORT_NAMES[e]) >= 0) { excluded = true; break; }
        }
        if (excluded) continue;
        out.push(f);
      }
      return out;
    }
  };

  /* 解析目录索引 HTML，提取文件名 */
  window.parseDirLinks = function (html) {
    const out = [];
    if (!html) return out;
    const re = /<a\s+[^>]*href\s*=\s*["']([^"']+)["']/gi;
    let m;
    while ((m = re.exec(html))) {
      let href = m[1];
      if (!href) continue;
      if (href.charAt(0) === '?' || href.charAt(0) === '#' || href.charAt(0) === '/') continue;
      if (href.indexOf('://') !== -1) continue;
      if (href.slice(-1) === '/') continue;
      let name = href.split('?')[0].split('#')[0];
      try { name = decodeURIComponent(name); } catch (e) { /* ignore */ }
      if (name && out.indexOf(name) < 0) out.push(name);
    }
    return out;
  };

  /* ============================================================
     IndexedDB
     ============================================================ */
  const IDB_NAME = 'cet6-vocab-db';
  const IDB_STORE = 'userdata';

  function idbOpen() {
    return new Promise((res, rej) => {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = function () {
        const db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
      };
      req.onsuccess = () => res(req.result);
      req.onerror = () => rej(req.error);
    });
  }
  window.idbOpen = idbOpen;

  window.idbGet = function (key) {
    return idbOpen().then(db => new Promise((res, rej) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const r = tx.objectStore(IDB_STORE).get(key);
      r.onsuccess = () => res(r.result == null ? null : r.result);
      r.onerror = () => rej(r.error);
    }));
  };
  window.idbSet = function (key, val) {
    return idbOpen().then(db => new Promise((res, rej) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put(val, key);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    }));
  };
  window.idbDel = function (key) {
    return idbOpen().then(db => new Promise((res, rej) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).delete(key);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    }));
  };

  /* 写队列 */
  let writeChain = Promise.resolve();
  window.enqueueWrite = function (fn) {
    writeChain = writeChain.then(fn).catch(e => {
      console.error('[write]', e);
      setSavingState('saving', '⚠ 保存失败');
    });
    return writeChain;
  };

  /* ============================================================
     用户数据读写
     —— 优先从 .userdata/ 目录读取（可纳入版本控制、跨设备同步），
        读不到再退回 IndexedDB。
     ============================================================ */
  window.loadUserdata = async function () {
    /* ---------- 1) 尝试从 .userdata/ 目录读取 ---------- */
    let fileStates   = null;
    let fileMeta     = null;
    let fileSettings = null;
    let fileSessions = {};
    let hasFiles = false;

    try {
      /* states.json */
      try {
        fileStates = await Store.readJSON('.userdata/states.json');
      } catch (e) { /* 忽略 */ }

      /* meta.json */
      try {
        fileMeta = await Store.readJSON('.userdata/meta.json');
      } catch (e) { /* 忽略 */ }

      /* settings.json */
      try {
        fileSettings = await Store.readJSON('.userdata/settings.json');
      } catch (e) { /* 忽略 */ }

      /* sessions 子目录：先拿索引，再逐个读 */
      try {
        const sessBase = new URL('.userdata/sessions/', Store.base);
        const listResp = await fetch(sessBase.href, { cache: 'no-store' });
        if (listResp.ok) {
          const listHtml = await listResp.text();
          const names = parseDirLinks(listHtml).filter(f => f.endsWith('.json'));
          for (let i = 0; i < names.length; i++) {
            const dateStr = names[i].replace(/\.json$/i, '');
            try {
              const sessData = await Store.readJSON('.userdata/sessions/' + names[i]);
              if (sessData && sessData.sessions) fileSessions[dateStr] = sessData;
            } catch (e) { /* 单个失败不阻断 */ }
          }
        }
      } catch (e) {
        console.warn('[loadUserdata] sessions 目录读取失败：', e);
      }

      hasFiles = (fileStates && Object.keys(fileStates).length > 0) ||
                 (Object.keys(fileSessions).length > 0);
      if (fileStates) hasFiles = hasFiles || true;
      if (fileMeta || fileSettings) hasFiles = hasFiles || true;

      console.log('[loadUserdata] .userdata/ 探测：',
        'states=', fileStates ? Object.keys(fileStates).length : 0,
        'sessions=', Object.keys(fileSessions).length,
        'meta=', fileMeta ? 'yes' : 'no',
        'settings=', fileSettings ? 'yes' : 'no');
    } catch (e) {
      console.warn('[loadUserdata] .userdata/ 读取异常：', e);
    }

    /* ---------- 2) 读 IndexedDB ---------- */
    const idbStates   = (await idbGet('states'))   || {};
    const idbSessions = (await idbGet('sessions')) || {};
    const idbMeta     = (await idbGet('meta'))     || { vocabSnapshot: {}, lastLoaded: null };
    const idbSettings = (await idbGet('settings')) || {};
    const idbTraining = (await idbGet('training')) || {};
    const idbPlan     = (await idbGet('plan'))     || null;

    const hasIDB = Object.keys(idbStates).length > 0 ||
                   Object.keys(idbSessions).length > 0;

    /* ---------- 3) 决定数据来源 ---------- */
    if (hasFiles) {
      console.log('[loadUserdata] 使用 .userdata/ 文件数据（会同步回 IndexedDB）');

      App.sessions  = Object.keys(fileSessions).length ? fileSessions : idbSessions;
      App.meta      = Object.assign({ vocabSnapshot: {}, lastLoaded: null }, fileMeta || idbMeta || {});
      App.settings  = Object.assign({}, DEFAULT_SETTINGS, fileSettings || idbSettings || {});
      App.training  = idbTraining || {};
      App.plan      = idbPlan || null;

      /* 回写 IndexedDB，保证下次无需再解析文件 */
      if (fileStates) await idbSet('states', fileStates);
      await idbSet('sessions', App.sessions);
      await idbSet('meta', App.meta);
      await idbSet('settings', App.settings);

      showToast('已从 .userdata/ 加载 ' +
        Object.keys(App.sessions).length + ' 天会话，' +
        Object.keys(fileStates || {}).length + ' 条状态', 'ok');

      return fileStates || idbStates;
    }

    /* ---------- 4) 只用 IndexedDB ---------- */
    console.log('[loadUserdata] 使用 IndexedDB 数据，hasIDB=', hasIDB);
    App.settings = Object.assign({}, DEFAULT_SETTINGS, idbSettings);
    App.sessions = idbSessions;
    App.meta     = idbMeta;
    App.training = idbTraining;
    App.plan     = idbPlan;
    return idbStates;
  };

  window.saveStates = async function () {
    setSavingState('saving', '保存中…');
    await enqueueWrite(async () => {
      const exported = {};
      for (const k in App.states) {
        if (!App.states.hasOwnProperty(k)) continue;
        const s = App.states[k];
        if (!s.reviews && !s.last_rating && !s.due) continue;
        exported[k] = {
          stage: s.stage || 0, reviews: s.reviews || 0,
          wrong: s.wrong || 0, confuse: s.confuse || 0,
          due: s.due || null, last_review: s.last_review || null,
          last_rating: s.last_rating || null,
          known: !!s.known
        };
      }
      await idbSet('states', exported);
    });
    setSavingState('saved', '✓ 已保存');
  };

  window.saveSession = async function (date, session) {
    App.sessions[date] = session;
    await enqueueWrite(async () => { await idbSet('sessions', App.sessions); });
  };
  window.saveMeta = async function () {
    await enqueueWrite(async () => { await idbSet('meta', App.meta); });
  };
  window.saveSettings = async function () {
    await enqueueWrite(async () => { await idbSet('settings', App.settings); });
  };
  window.saveTraining = async function () {
    await enqueueWrite(async () => { await idbSet('training', App.training); });
  };
  window.saveMastery = async function () {
    await enqueueWrite(async () => { await idbSet('mastery', App.mastery); });
  };
  window.savePlan = async function () {
    await enqueueWrite(async () => { await idbSet('plan', App.plan); });
  };

  /* ============================================================
     辅助数据
     ============================================================ */
  window.loadAuxData = async function () {
    const syn   = await Store.readJSON(AUX_SYNONYMS);
    const typo  = await Store.readJSON(AUX_TYPO_HINTS);
    const collo = await Store.readJSON(AUX_COLLOCATIONS);
    const plan  = await Store.readJSON(AUX_PLAN);

    App.synonyms     = (syn && typeof syn === 'object' && !Array.isArray(syn)) ? syn : {};
    App.typoHints    = (typo && typeof typo === 'object' && !Array.isArray(typo)) ? typo : (deepClone(SEED_TYPO_HINTS) || {});
    App.collocations = (collo && typeof collo === 'object' && !Array.isArray(collo)) ? collo : {};
    if (plan && typeof plan === 'object' && !App.plan) App.plan = plan;

    return { syn: App.synonyms, typo: App.typoHints, collocations: App.collocations };
  };

  /* ============================================================
     学习文件解析
     ============================================================ */
  window.parseStudyWorkbook = function (fileName, wb) {
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    let day = parseDayLabel(fileName);
    let group = '';
    const words = [], typos = [];

    const cw = App.settings.colWord != null ? App.settings.colWord : 0;
    const cm = App.settings.colMeaning != null ? App.settings.colMeaning : 1;
    const ct = App.settings.colTag != null ? App.settings.colTag : 2;

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const a = String(row[cw] != null ? row[cw] : '').trim();
      const b = String(row[cm] != null ? row[cm] : '').trim();
      const c = String(row[ct] != null ? row[ct] : '').trim();
      if (!a) continue;
      if (a.indexOf('日期') === 0) {
        const d = parseDayLabel(c) || parseDayLabel(a);
        if (d != null) day = d;
        continue;
      }
      const ng = normalizeGroup(a);
      if (GROUP_ORDER.indexOf(ng) >= 0) { group = ng; continue; }
      if (!isValidWord(a)) continue;
      if (day == null) continue;
      const sug = detectTypo(a);
      if (sug) typos.push([a, sug]);
      words.push({ text: a, meaning: b, tags: c ? [c] : [], day: day, group: group, source: fileName });
    }
    return { day: day, words: words, typos: typos };
  };

  /* ============================================================
     词库加载
     ============================================================ */
  window.loadLibrary = async function () {
    let xlsxFiles = Store.listStudyXlsx();

    if (App.settings.libPrefix) {
      const prefix = App.settings.libPrefix.toLowerCase();
      xlsxFiles = xlsxFiles.filter(f => f.toLowerCase().indexOf(prefix) === 0);
    }

    xlsxFiles.sort((a, b) => {
      let da = parseDayLabel(a); if (da == null) da = 999;
      let db = parseDayLabel(b); if (db == null) db = 999;
      return da - db || a.localeCompare(b);
    });

    const library = {}, days = {}, skipped = [], typos = [];
    const byGroup = {}, byGroupDay = {};

    for (let i = 0; i < xlsxFiles.length; i++) {
      const name = xlsxFiles[i];
      try {
        const buf = await Store.readBuffer(name);
        const wb = XLSX.read(buf, { type: 'array' });
        const r = parseStudyWorkbook(name, wb);
        if (r.day == null) { skipped.push({ name: name, why: '无法识别天号' }); continue; }
        if (!r.words.length) { skipped.push({ name: name, why: '未解析到单词行' }); continue; }

        for (let t = 0; t < r.typos.length; t++) typos.push([name, r.typos[t][0], r.typos[t][1]]);

        for (let k = 0; k < r.words.length; k++) {
          const w = r.words[k];
          const key = w.text.trim().toLowerCase();
          if (!key) continue;
          if (key in library) {
            const o = library[key];
            if (!o.meaning && w.meaning) o.meaning = w.meaning;
            for (let tt = 0; tt < w.tags.length; tt++) if (o.tags.indexOf(w.tags[tt]) < 0) o.tags.push(w.tags[tt]);
            if (!o.group && w.group) o.group = w.group;
          } else {
            library[key] = w;
          }
          if (w.day) {
            if (!days[w.day]) days[w.day] = [];
            if (days[w.day].indexOf(key) < 0) days[w.day].push(key);
          }
          const g = normalizeGroup(w.group) || '未分组';
          byGroup[g] = (byGroup[g] || 0) + 1;
          if (w.day) {
            if (!byGroupDay[g]) byGroupDay[g] = {};
            byGroupDay[g][w.day] = (byGroupDay[g][w.day] || 0) + 1;
          }
        }
      } catch (e) {
        skipped.push({ name: name, why: '解析异常：' + e.message });
      }
    }

    return {
      library: library, days: days, skipped: skipped, typos: typos,
      byGroup: byGroup, byGroupDay: byGroupDay, studyFiles: xlsxFiles
    };
  };

  console.log('[store] 已加载');
})();