/* ============================================================
   scheduler.js — 复习调度 / 保持率 / 弱项判定 / 队列构建
   ============================================================ */
(function () {
  'use strict';

  /* ---------- 空状态 ---------- */
  window.blankState = function () {
    return {
      stage: 0, reviews: 0, wrong: 0, confuse: 0,
      due: null, last_review: null, last_rating: null,
      history: [], known: false
    };
  };

  /* ---------- 应用评分 ---------- */
  window.applyRating = function (state, rating, dateStr, elapsedMs) {
    let stage = state.stage || 0;
    let mod = 0;

    if (rating === '熟悉') {
      const fastMs = App.settings.fastMs || 2000;
      const slowMs = App.settings.slowMs || 10000;
      if (elapsedMs && elapsedMs < fastMs) mod = 1;
      else if (elapsedMs && elapsedMs > slowMs) mod = -1;
    }

    if (rating === '熟悉') stage = Math.min(Math.max(0, stage + 1 + mod), INTERVALS.length - 1);
    else if (rating === '模糊') stage = Math.max(0, stage - 1);
    else { stage = 0; state.wrong = (state.wrong || 0) + 1; }

    if (rating === '混淆') state.confuse = (state.confuse || 0) + 1;

    state.stage = stage;
    state.reviews = (state.reviews || 0) + 1;
    state.last_review = dateStr;
    state.last_rating = rating;
    state.due = addDays(dateStr, INTERVALS[stage]);
    state.known = true;

    if (!state.history) state.history = [];
    state.history.push({ d: dateStr, r: rating });
  };

  /* ---------- 重建 states ---------- */
  window.rebuildStates = function (savedStates) {
    savedStates = savedStates || {};
    const states = {};
    const keys = Object.keys(App.library);

    for (let i = 0; i < keys.length; i++) {
      const k = keys[i], s = savedStates[k];
      if (s) {
        states[k] = {
          stage: s.stage || 0, reviews: s.reviews || 0,
          wrong: s.wrong || 0, confuse: s.confuse || 0,
          due: s.due || null, last_review: s.last_review || null,
          last_rating: s.last_rating || null,
          history: s.history || [], known: !!s.known
        };
      } else {
        states[k] = blankState();
      }
    }

    const dates = Object.keys(App.sessions).sort();
    for (let di = 0; di < dates.length; di++) {
      const sess = App.sessions[dates[di]].sessions || [];
      for (let i = 0; i < sess.length; i++) {
        const rev = sess[i].reviews || [];
        for (let j = 0; j < rev.length; j++) {
          const key = String(rev[j].key || rev[j].word || '').trim().toLowerCase();
          if (key && states[key]) applyRating(states[key], rev[j].rating, dates[di], rev[j].elapsed_ms);
        }
      }
    }
    return states;
  };

  /* ---------- 逾期降级 ---------- */
  window.applyOverdueDegradation = function () {
    const today = todayStr();
    const threshold = App.settings.overdueDays || 3;
    const keys = Object.keys(App.states);
    let changed = 0;
    for (let i = 0; i < keys.length; i++) {
      const st = App.states[keys[i]];
      if (!st || !st.due) continue;
      const overdue = daysBetween(st.due, today);
      if (overdue > threshold) {
        const oldStage = st.stage || 0;
        if (oldStage > 0) {
          st.stage = oldStage - 1;
          st.due = addDays(today, INTERVALS[st.stage]);
          changed++;
        }
      }
    }
    return changed;
  };

  /* ---------- 保持率 ---------- */
  window.retentionRate = function (key, today) {
    today = today || todayStr();
    const st = App.states[key];
    if (!st || !st.reviews || !st.last_review) return 0;
    const elapsed = Math.max(0, daysBetween(st.last_review, today));
    const interval = INTERVALS[st.stage || 0];
    if (interval <= 0) return 0;
    const r = Math.exp(-0.5 * elapsed / interval);
    return Math.max(0, Math.min(1, r));
  };
  window.retentionLevel = function (r) {
    if (r >= 0.7) return 'safe';
    if (r >= 0.4) return 'mid';
    return 'danger';
  };
  window.retentionColor = function (r) {
    if (r >= 0.7) return '#22c55e';
    if (r >= 0.4) return '#f59e0b';
    return '#ef4444';
  };
  window.retentionBarHtml = function (key) {
    const r = retentionRate(key);
    if (!r) return '<span class="muted">—</span>';
    const pct = Math.round(r * 100);
    const color = retentionColor(r);
    return '<span class="ret-bar" title="' + pct + '%"><i style="width:' + pct + '%;background:' + color + '"></i></span>' +
      '<span class="ret-label" style="color:' + color + '">' + pct + '%</span>';
  };

  /* ---------- 判定 ---------- */
  window.isUnfamiliar = function (key) {
    const st = App.states[key];
    if (!st) return true;
    if (UNFAMILIAR_RATINGS[st.last_rating]) return true;
    if (!st.reviews && !st.last_rating) return true;
    return false;
  };
  window.isWeakGlobal = function (key) {
    const st = App.states[key];
    if (!st) return false;
    if ((st.stage || 0) >= 4) return false;
    if ((st.wrong || 0) >= 2) return true;
    if ((st.confuse || 0) >= 1) return true;
    if (st.last_rating === '陌生' || st.last_rating === '混淆') return true;
    return false;
  };
  window.isMastered = function (key) {
    const st = App.states[key];
    if (!st) return false;
    if ((st.stage || 0) < 4) return false;
    return !isWeakGlobal(key);
  };
  window.priorityScore = function (st) {
    let s = 0;
    switch (st.last_rating) {
      case '混淆': s += 1000; break;
      case '陌生': s += 800; break;
      case '模糊': s += 400; break;
      case '熟悉': s += 50; break;
      default: s += 200;
    }
    s -= (st.reviews || 0) * 15;
    s -= (st.stage || 0) * 8;
    return s;
  };
  window.getLastWrongDate = function (key) {
    const st = App.states[key];
    if (!st || !st.history) return null;
    for (let i = st.history.length - 1; i >= 0; i--) {
      const r = st.history[i].r;
      if (r === '陌生' || r === '混淆') return st.history[i].d;
    }
    return null;
  };
  window.compareMistakes = function (a, b) {
    const A = App.states[a] || {}, B = App.states[b] || {};
    const ca = A.confuse || 0, cb = B.confuse || 0;
    if (ca !== cb) return cb - ca;
    const wa = A.wrong || 0, wb = B.wrong || 0;
    if (wa !== wb) return wb - wa;
    const da = getLastWrongDate(a) || '0000-00-00';
    const db = getLastWrongDate(b) || '0000-00-00';
    if (da !== db) return db.localeCompare(da);
    return (A.stage || 0) - (B.stage || 0);
  };

  /* ---------- 队列 ---------- */
  window.groupMatch = function (w) {
    const gf = App.groupFilter;
    if (gf === 'all') return true;
    return normalizeGroup(w.group) === gf;
  };
  window.groupPriority = function (w) { return groupWeight(w.group); };

  window.applyDailyLimits = function (queue) {
    const newLimit = App.settings.dailyNewLimit || 0;
    const revLimit = App.settings.dailyReviewLimit || 0;
    if (!newLimit && !revLimit) return queue;

    let newWords = [], reviewWords = [];   /* ← 从 const 改为 let */
    for (let i = 0; i < queue.length; i++) {
      const st = App.states[queue[i]];
      if (!st || !st.reviews) newWords.push(queue[i]);
      else reviewWords.push(queue[i]);
    }
    if (revLimit > 0 && reviewWords.length > revLimit) reviewWords = reviewWords.slice(0, revLimit);
    if (newLimit > 0 && newWords.length > newLimit) newWords = newWords.slice(0, newLimit);
    return reviewWords.concat(newWords);
  };

  window.buildQueue = function (mode) {
    const day = App.selectedDay;
    const queue = [], reasons = {};

    function push(k, reason) {
      if (queue.indexOf(k) >= 0) return;
      const w = App.library[k];
      if (!w) return;
      if (!groupMatch(w)) return;
      queue.push(k); reasons[k] = reason;
    }
    function sortQueue() {
      queue.sort((a, b) => {
        const ga = groupPriority(App.library[a]), gb = groupPriority(App.library[b]);
        if (ga !== gb) return gb - ga;
        return priorityScore(App.states[b] || {}) - priorityScore(App.states[a] || {});
      });
    }

    let i, k, keys, dayKeys, n, d, targetDays;

    if (day === 'all') {
      keys = Object.keys(App.library);
      for (i = 0; i < keys.length; i++) {
        k = keys[i];
        if (mode === 'weak') {
          if (isWeakGlobal(k)) push(k, '全库弱项');
        } else if (mode === 'star1') {
          const stars = starOf(k);
          if (stars <= 2) push(k, '★' + stars + ' 急救');
        } else if (mode === 'all') {
          push(k, '全量复习');
        } else {
          if (isUnfamiliar(k)) push(k, '全库非熟悉');
        }
      }
      sortQueue();
    } else {
      n = parseInt(day, 10);
      if (mode === 'review') {
        targetDays = [];
        if (n - 2 >= 1) targetDays.push(n - 2);
        if (n - 1 >= 1) targetDays.push(n - 1);
        for (i = 0; i < targetDays.length; i++) {
          d = targetDays[i];
          dayKeys = App.days[d] || [];
          for (let j = 0; j < dayKeys.length; j++) {
            k = dayKeys[j];
            if (isUnfamiliar(k)) push(k, '第' + d + '天 非熟悉');
          }
        }
        sortQueue();
      } else if (mode === 'weak') {
        dayKeys = App.days[n] || [];
        for (i = 0; i < dayKeys.length; i++) {
          k = dayKeys[i];
          if (isWeakGlobal(k)) push(k, '第' + n + '天 弱项');
        }
        sortQueue();
      } else if (mode === 'star1') {
        dayKeys = App.days[n] || [];
        for (i = 0; i < dayKeys.length; i++) {
          k = dayKeys[i];
          const stars = starOf(k);
          if (stars <= 2) push(k, '★' + stars + ' 急救');
        }
        sortQueue();
      } else {
        dayKeys = App.days[n] || [];
        for (i = 0; i < dayKeys.length; i++) push(dayKeys[i], '第' + n + '天 全量');
        sortQueue();
      }
    }

    const limited = applyDailyLimits(queue);
    if (limited.length !== queue.length) {
      const newReasons = {};
      for (i = 0; i < limited.length; i++) newReasons[limited[i]] = reasons[limited[i]] || '';
      return { queue: limited, reasons: newReasons, limited: true };
    }
    return { queue: queue, reasons: reasons };
  };

  window.collectPools = function (day) {
    const queueObj = buildQueue(App.mode);
    const all = [], weak = [], good = [], unfam = [];
    let starSum = 0, starN = 0;
    const keys = Object.keys(App.library);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i], w = App.library[k];
      if (day !== 'all' && String(w.day) !== String(day)) continue;
      if (!groupMatch(w)) continue;
      all.push(k);
      if (isWeakGlobal(k)) weak.push(k);
      if (isMastered(k)) good.push(k);
      if (isUnfamiliar(k)) unfam.push(k);
      const m = App.mastery[k];
      if (m) { starSum += m.stars; starN++; }
    }
    return {
      all: all, weak: weak, good: good, unfam: unfam,
      queueCount: queueObj.queue.length,
      avgStars: starN ? starSum / starN : 0
    };
  };

  /* ---------- 调度 ---------- */
  window.computeSchedule = function () {
    const today = todayStr();
    const overdue = [], dueByDate = {}, unscheduled = [];
    const keys = Object.keys(App.library);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i], st = App.states[k];
      if (!st || !st.due) { unscheduled.push(k); continue; }
      if (st.due < today) { overdue.push(k); continue; }
      if (!dueByDate[st.due]) dueByDate[st.due] = [];
      dueByDate[st.due].push(k);
    }
    overdue.sort((a, b) => String(App.states[a].due).localeCompare(String(App.states[b].due)));
    return { today: today, overdue: overdue, dueByDate: dueByDate, unscheduled: unscheduled, total: keys.length };
  };

  console.log('[scheduler] 已加载');
})();