/* ============================================================
   session.js — 复习会话生命周期
   ============================================================ */
(function () {
  'use strict';

  window.setRateButtons = function (enabled) {
    qsa('.rate-btn').forEach(b => { b.disabled = !enabled; });
  };

  window.updateNavButtons = function () {
    const flip = el('btnFlip'), prev = el('btnPrev'), skip = el('btnSkip');
    if (!flip || !prev || !skip) return;
    const s = App.session;
    const hasSession = !!s;
    const hasCurrent = !!App.currentKey;
    const canPrev = hasSession && s.idx > 0;
    const canSkip = hasSession && hasCurrent;

    if (!hasSession || !hasCurrent) {
      flip.disabled = true; skip.disabled = true; prev.disabled = true;
      setRateButtons(false);
      return;
    }
    if (App.cardFlipped) {
      flip.disabled = true; skip.disabled = false; prev.disabled = !canPrev;
      setRateButtons(true);
    } else {
      flip.disabled = false; skip.disabled = !canSkip; prev.disabled = !canPrev;
      setRateButtons(false);
    }
  };

  window.histChainHtml = function (ratings) {
    if (!ratings || !ratings.length) return '<span style="color:#94a3b8">（无历史记录）</span>';
    const parts = [];
    for (let i = 0; i < ratings.length; i++) {
      if (i > 0) parts.push('<span style="color:#cbd5e1;margin:0 6px">→</span>');
      parts.push('<span class="r-' + esc(ratings[i]) + '">' + esc(ratings[i]) + '</span>');
    }
    return parts.join('');
  };

  window.showCurrent = function () {
    const s = App.session;
    if (!s) return;
    while (s.idx < s.queue.length && !App.library[s.queue[s.idx]]) s.idx++;
    if (s.idx >= s.queue.length) { finishSession(); return; }
    const k = s.queue[s.idx];
    const w = App.library[k];
    if (!w) { s.idx++; return showCurrent(); }

    App.currentKey = k;
    App.cardFlipped = false;
    App.cardStartTs = Date.now();

    const rb = el('reasonBadge');
    const reason = App.sessionReasons[k] || '';
    if (reason) {
      rb.style.display = 'inline-block';
      rb.textContent = reason;
      const sm = s.mode || App.mode;
      rb.className = 'reason-badge' + (sm === 'weak' ? ' weak' : (sm === 'all' ? ' all' : (sm === 'due' ? ' due' : (sm === 'star1' ? ' star1' : ''))));
    } else {
      rb.style.display = 'none';
    }

    const badge = el('cardDayBadge');
    badge.style.display = 'inline-block';
    badge.textContent = '第' + w.day + '天' + (w.group ? ' · ' + w.group : '');

    /* 星级 */
    const starRow = el('cardStars');
    if (starRow) {
      const m = App.mastery[k];
      if (m) {
        starRow.style.display = 'flex';
        starRow.innerHTML = starHtml(m.stars) +
          '<span style="font-size:11.5px;color:var(--text-2);margin-left:8px;align-self:center">掌握分 ' +
          m.score.toFixed(1) + '</span>';
      } else {
        starRow.style.display = 'none';
      }
    }

    el('cardWord').textContent = w.text;
    el('cardMeaning').textContent = '';
    el('cardMeaning').classList.remove('show');
    el('cardExtra').textContent = '';
    el('cardExtra').classList.remove('show');
    el('histBlock').classList.remove('show');

    const total = s.queue.length, done = s.idx;
    el('progFill').style.width = (total ? done / total * 100 : 0) + '%';
    el('progLabel').textContent = done + ' / ' + total;

    updateNavButtons();
  };

  window.flipCard = function () {
    if (!App.currentKey || App.cardFlipped) return;
    const w = App.library[App.currentKey];
    const st = App.states[App.currentKey] || blankState();
    const rel = App.relations[App.currentKey] || { syn: [], form: [] };
    const colloc = App.collocations[App.currentKey];

    el('cardMeaning').textContent = w.meaning || '（无释义）';
    el('cardMeaning').classList.add('show');

    const extra = [];
    if (rel.syn.length) {
      const syns = rel.syn.slice(0, 6).map(sk => App.library[sk] ? App.library[sk].text : sk);
      extra.push('近义替换：' + syns.join('  /  '));
    }
    if (rel.form.length) {
      const forms = rel.form.slice(0, 6).map(fk => App.library[fk] ? App.library[fk].text : fk);
      extra.push('形近易混：' + forms.join('  /  '));
    }
    if (colloc) {
      if (Array.isArray(colloc) && colloc.length) extra.push('常用搭配：' + colloc.slice(0, 5).join('  ／  '));
      else if (typeof colloc === 'string') extra.push('常用搭配：' + colloc);
    }
    if (st.reviews) {
      extra.push('已复习 ' + st.reviews + ' 次 · 阶段 ' + (st.stage || 0) +
        ' · 间隔 ' + INTERVALS[st.stage || 0] + ' 天 · 上次 ' + (st.last_rating || '-') +
        ' · 错误 ' + (st.wrong || 0) + ' 次');
    }
    if (st.due) {
      const dd = daysBetween(todayStr(), st.due);
      extra.push('下次到期：' + st.due + (dd > 0 ? '（' + dd + ' 天后）' : (dd === 0 ? '（今天）' : '（已逾期 ' + (-dd) + ' 天）')));
    }
    const ret = retentionRate(App.currentKey);
    if (ret > 0) {
      const pct = Math.round(ret * 100);
      const lvl = retentionLevel(ret);
      const lvlTxt = lvl === 'safe' ? '安全' : (lvl === 'mid' ? '临界' : '危险');
      extra.push('记忆保持率：' + pct + '%（' + lvlTxt + '）');
    }
    el('cardExtra').textContent = extra.join('\n');
    el('cardExtra').classList.add('show');

    const hist = (st.history || []).map(h => h.r);
    el('histChain').innerHTML = histChainHtml(hist);
    el('histBlock').classList.add('show');

    App.cardFlipped = true;
    updateNavButtons();
  };

  window.rate = async function (rating) {
    const s = App.session;
    if (!s || !App.currentKey) return;
    if (!App.cardFlipped) { flipCard(); return; }
    const k = App.currentKey, w = App.library[k];
    const elapsed = Date.now() - App.cardStartTs;

    const prevState = App.states[k] ? deepClone(App.states[k]) : null;

    s.answers.push({
      word: w.text, key: k, rating: rating, ts: nowISO(),
      day: w.day, group: w.group, elapsed_ms: elapsed
    });
    s.idx++;

    if (App.states[k]) applyRating(App.states[k], rating, todayStr(), elapsed);

    s.appliedHistory.push({
      key: k, rating: rating, prevState: prevState, reinserted: false
    });

    const today = todayStr();
    if (!App.sessions[today]) App.sessions[today] = { date: today, sessions: [], updated_at: nowISO() };
    const todaySessions = App.sessions[today].sessions;
    let idx = -1;
    for (let i = 0; i < todaySessions.length; i++) {
      if (todaySessions[i].session_id === s.session_id) { idx = i; break; }
    }
    const rec = {
      session_id: s.session_id, started_at: s.started_at,
      updated_at: nowISO(), mode: s.mode, finished: false,
      total_planned: s.queue.length, answered: s.answers.length,
      summary: summarize(s.answers), reviews: s.answers
    };
    if (idx >= 0) todaySessions[idx] = rec; else todaySessions.push(rec);
    App.sessions[today].updated_at = nowISO();
    saveStates();
    saveSession(today, App.sessions[today]);

    if ((rating === '陌生' || rating === '混淆') && !s.reinserted[k]) {
      s.reinserted[k] = true;
      s.appliedHistory[s.appliedHistory.length - 1].reinserted = true;
      const pos = Math.min(s.queue.length, s.idx + 3 + Math.floor(Math.random() * 3));
      s.queue.splice(pos, 0, k);
    }

    /* 单次评分后刷新掌握度 */
    const m = computeScore(k);
    if (m) App.mastery[k] = m;

    showCurrent();
  };

  window.skipWord = function () {
    const s = App.session;
    if (!s || !App.currentKey) return;
    s.idx++;
    showCurrent();
  };

  window.goPrev = function () {
    const s = App.session;
    if (!s || s.idx <= 0) return;
    s.idx--;
    if (s.idx >= s.queue.length) { showCurrent(); return; }
    const curKey = s.queue[s.idx];

    if (s.answers.length) {
      const last = s.answers[s.answers.length - 1];
      if (last.key === curKey) {
        s.answers.pop();
        const h = s.appliedHistory.pop();
        if (h && h.prevState) App.states[last.key] = h.prevState;
        else App.states[last.key] = blankState();

        if (h && h.reinserted && s.reinserted[last.key]) {
          delete s.reinserted[last.key];
          for (let i = s.queue.length - 1; i > s.idx; i--) {
            if (s.queue[i] === last.key) { s.queue.splice(i, 1); break; }
          }
        }

        const today = todayStr();
        if (App.sessions[today]) {
          const ts = App.sessions[today].sessions;
          let idx = -1;
          for (let i = 0; i < ts.length; i++) {
            if (ts[i].session_id === s.session_id) { idx = i; break; }
          }
          const rec = {
            session_id: s.session_id, started_at: s.started_at,
            updated_at: nowISO(), mode: s.mode, finished: false,
            total_planned: s.queue.length, answered: s.answers.length,
            summary: summarize(s.answers), reviews: s.answers
          };
          if (idx >= 0) ts[idx] = rec; else ts.push(rec);
          App.sessions[today].updated_at = nowISO();
          saveStates();
          saveSession(today, App.sessions[today]);
        }

        /* 撤回后重新计算掌握度 */
        const m = computeScore(last.key);
        if (m) App.mastery[last.key] = m;
      }
    }
    showCurrent();
  };

  window.summarize = function (answers) {
    const s = { 熟悉: 0, 模糊: 0, 陌生: 0, 混淆: 0 };
    for (let i = 0; i < answers.length; i++) if (answers[i].rating in s) s[answers[i].rating]++;
    return s;
  };

  window.startSession = function () {
    if (!Object.keys(App.library).length) { showToast('请先加载词库', 'warn'); return; }
    const r = buildQueue(App.mode);
    if (!r.queue.length) { showToast('当前筛选没有可复习的词', 'warn'); return; }
    App.session = {
      session_id: uid(), started_at: nowISO(),
      mode: App.mode, queue: r.queue.slice(),
      idx: 0, answers: [], reinserted: {}, appliedHistory: []
    };
    App.sessionReasons = r.reasons;
    App.cardFlipped = false;
    App.currentKey = null;
    showCurrent();
  };

  window.startQueueFromKeys = function (keys, mode, reasonText) {
    const q = [];
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      if (App.library[k] && q.indexOf(k) < 0) q.push(k);
    }
    if (!q.length) { showToast('这一组没有可复习的词', 'warn'); return; }

    App.session = {
      session_id: uid(), started_at: nowISO(),
      mode: mode || 'due', queue: q.slice(),
      idx: 0, answers: [], reinserted: {}, appliedHistory: []
    };
    App.sessionReasons = {};
    for (let j = 0; j < q.length; j++) App.sessionReasons[q[j]] = reasonText || '到期复习';
    App.cardFlipped = false;
    App.currentKey = null;

    switchTab('review');
    showCurrent();
    showToast('已载入 ' + q.length + ' 个词', 'ok');
  };

  window.finishSession = async function () {
    const s = App.session;
    if (!s) return;
    if (s.answers.length) {
      const today = todayStr();
      if (!App.sessions[today]) App.sessions[today] = { date: today, sessions: [] };
      const ts = App.sessions[today].sessions;
      let idx = -1;
      for (let i = 0; i < ts.length; i++) {
        if (ts[i].session_id === s.session_id) { idx = i; break; }
      }
      const rec = {
        session_id: s.session_id, started_at: s.started_at,
        updated_at: nowISO(), ended_at: nowISO(),
        mode: s.mode, finished: true,
        total_planned: s.queue.length, answered: s.answers.length,
        summary: summarize(s.answers), reviews: s.answers
      };
      if (idx >= 0) ts[idx] = rec; else ts.push(rec);
      App.sessions[today].updated_at = nowISO();
      await saveStates();
      await saveSession(today, App.sessions[today]);
    }
    const sum = summarize(s.answers);
    const n = s.answers.length;
    const acc = n ? ((sum.熟悉 + sum.模糊) / n * 100).toFixed(1) : 0;

    App.session = null; App.currentKey = null; App.cardFlipped = false; App.sessionReasons = {};

    el('reasonBadge').style.display = 'none';
    el('cardDayBadge').style.display = 'none';
    if (el('cardStars')) el('cardStars').style.display = 'none';
    el('cardWord').textContent = '🎉  本轮完成';
    el('cardMeaning').textContent = '共 ' + n + ' 题    熟悉 ' + sum.熟悉 + '  ·  模糊 ' + sum.模糊 + '  ·  陌生 ' + sum.陌生 + '  ·  混淆 ' + sum.混淆;
    el('cardMeaning').classList.add('show');
    el('cardExtra').textContent = '掌握率（熟悉 + 模糊）：' + acc + '%\n点击「▶ 开始本轮」继续下一轮';
    el('cardExtra').classList.add('show');
    el('histBlock').classList.remove('show');

    el('btnFlip').disabled = true;
    el('btnPrev').disabled = true;
    el('btnSkip').disabled = true;
    setRateButtons(false);

    el('progFill').style.width = '0%';
    el('progLabel').textContent = '0 / 0';

    refreshMastery();
    updateHeader();
    updatePoolBar();
    renderBrowse();
    renderMistakes();
    renderStats();
    renderCurve();
    showToast('本轮完成：' + n + ' 题，掌握率 ' + acc + '%', 'ok');
  };

  console.log('[session] 已加载');
})();