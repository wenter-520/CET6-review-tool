/* ============================================================
   views.js — 各标签页渲染 + 导出
   ============================================================ */
(function () {
  'use strict';

  /* ============================================================
     头部 / 池 / 模式描述
     ============================================================ */
  window.updateHeader = function () {
    el('hWordCount').textContent = Object.keys(App.library).length;
    el('hDayCount').textContent = Object.keys(App.days).filter(d => +d > 0).length;
    el('hAnswers').textContent = computeStats().answers;
    const dist = starDistribution();
    const avg = dist.total ? (
      dist.dist[1] * 1 + dist.dist[2] * 2 + dist.dist[3] * 3 + dist.dist[4] * 4 + dist.dist[5] * 5
    ) / dist.total : 0;
    if (el('hAvgStars')) el('hAvgStars').textContent = avg.toFixed(2);
  };

  window.updatePoolBar = function () {
    const p = collectPools(App.selectedDay);
    el('poolTotal').textContent = p.all.length;
    el('poolQueue').textContent = p.queueCount;
    if (el('poolNew')) el('poolNew').textContent = p.untouched.length;
    el('poolWeak').textContent = p.weak.length;
    el('poolGood').textContent = p.good.length;
    if (el('poolStars')) el('poolStars').textContent = p.avgStars.toFixed(2);
  };

  window.renderModeDesc = function () {
    const day = App.selectedDay, m = App.mode;
    const gf = App.groupFilter;
    const gfText = gf === 'all' ? '' : ('，分组限定 <b>' + gf + '</b>');
    const limits = [];
    if (App.settings.dailyNewLimit > 0) limits.push('新词≤' + App.settings.dailyNewLimit);
    if (App.settings.dailyReviewLimit > 0) limits.push('复习≤' + App.settings.dailyReviewLimit);
    const limitText = limits.length ? ('，每日上限 <b>' + limits.join(' / ') + '</b>') : '';
    let text = '';

    if (day === 'all') {
      if (m === 'new') {
        text = '🆕 <b>全库新词学习</b>：所有从未复习过的词，按学习天从早到晚依次补学' + gfText + limitText;
      } else if (m === 'review') {
        text = '📖 <b>全库复习优先</b>：复习所有非熟悉词' + gfText + limitText;
      } else if (m === 'weak') {
        text = '⚠ <b>全库弱项强化</b>：阶段 &lt; 4 且（错误 ≥ 2 或 混淆 ≥ 1）的词' + gfText + limitText;
      } else if (m === 'star1') {
        text = '🚨 <b>★1–★2 急救</b>：掌握分 &lt; 50 的高危词' + gfText + limitText;
      } else {
        text = '🎯 <b>全库全量抽题</b>：全部词按优先级排序（核心 &gt; 过考 &gt; 基础）' + gfText + limitText;
      }
    } else {
      const n = parseInt(day, 10);
      if (m === 'new') {
        text = '🆕 <b>第 ' + n + ' 天新词学习</b>：只学第 ' + n + ' 天尚未复习过的词' + gfText;
      } else if (m === 'review') {
        if (n === 1) text = '📖 <b>第 1 天</b>：没有更早的天数，建议改用「新词学习」或「★1 急救」';
        else if (n === 2) text = '📖 <b>第 2 天</b>：复习 <b>第 1 天</b> 的非熟悉词' + gfText;
        else text = '📖 <b>第 ' + n + ' 天</b>：复习 <b>第 ' + (n - 2) + '、' + (n - 1) + ' 天</b> 的非熟悉词' + gfText;
      } else if (m === 'weak') {
        text = '⚠ <b>第 ' + n + ' 天弱项</b>：只抽第 ' + n + ' 天弱项词' + gfText;
      } else if (m === 'star1') {
        text = '🚨 <b>第 ' + n + ' 天 ★1–★2</b>：优先攻克' + gfText;
      } else {
        text = '🎯 <b>第 ' + n + ' 天全量</b>：按优先级排序' + gfText;
      }
    }
    el('modeDesc').innerHTML = text;
  };

  /* ============================================================
     日进度条
     ============================================================ */
  window.renderDayBar = function () {
    const bar = el('dayBar'); if (!bar) return;
    qsa('.day-btn', bar).forEach(b => { if (b.dataset.day !== 'all') b.remove(); });
    const hintEl = el('dayBarHint'), allBtn = el('dayBtnAll');
    const dayNums = Object.keys(App.days).map(Number).filter(n => n > 0).sort((a, b) => a - b);

    if (!dayNums.length) {
      if (allBtn) allBtn.classList.add('active');
      if (hintEl) hintEl.textContent = '尚未加载词库';
      return;
    }
    dayNums.forEach(d => {
      const btn = document.createElement('button');
      btn.className = 'day-btn';
      btn.dataset.day = d;
      btn.innerHTML = '第' + d + '天 <span class="cnt">' + (App.days[d] || []).length + '</span>';
      if (String(App.selectedDay) === String(d)) btn.classList.add('active');
      btn.addEventListener('click', () => selectDay(d));
      if (hintEl) bar.insertBefore(btn, hintEl);
      else bar.appendChild(btn);
    });
    if (allBtn) {
      if (App.selectedDay === 'all') allBtn.classList.add('active');
      else allBtn.classList.remove('active');
    }
    if (hintEl) {
      if (App.selectedDay === 'all') hintEl.textContent = '全部 ' + Object.keys(App.library).length + ' 词';
      else hintEl.textContent = '第' + App.selectedDay + '天 · ' + (App.days[App.selectedDay] || []).length + ' 词';
    }
  };

  window.selectDay = function (day) {
    App.selectedDay = day;
    safe('renderDayBar', renderDayBar);
    safe('renderModeDesc', renderModeDesc);
    safe('updatePoolBar', updatePoolBar);
    safe('renderNewWordPanel', renderNewWordPanel);
    safe('renderBrowse', renderBrowse);
    safe('renderStats', renderStats);
    safe('renderMistakes', renderMistakes);
    safe('renderData', renderData);
    safe('renderPlan', renderPlan);
  };

  /* ============================================================
     错题本
     ============================================================ */
  window.getMistakeKeys = function (filter) {
    filter = filter || 'all';
    const keys = Object.keys(App.library);
    const out = [];
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      const st = App.states[k];
      if (!st) continue;
      if (filter === 'confused') {
        if ((st.confuse || 0) < 1) continue;
      } else if (filter === 'wrong') {
        if ((st.wrong || 0) < 1) continue;
      } else {
        if (!isWeakGlobal(k) && (st.wrong || 0) === 0 && (st.confuse || 0) === 0) continue;
      }
      out.push(k);
    }
    out.sort(compareMistakes);
    return out;
  };

  window.renderMistakes = function () {
    const tbody = el('mistakeTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    const keys = getMistakeKeys('all');
    let confN = 0, wrongN = 0, weakN = 0;
    for (let i = 0; i < keys.length; i++) {
      const st = App.states[keys[i]];
      if (st.confuse) confN++;
      if (st.wrong) wrongN++;
      if (isWeakGlobal(keys[i])) weakN++;
    }

    el('mistakeStats').innerHTML =
      '<div class="card stat-card"><div class="stat-num" style="color:var(--bad)">' + keys.length + '</div><div class="stat-label">错题总数</div><div class="stat-hint">有错误或混淆记录</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--pur)">' + confN + '</div><div class="stat-label">混淆词</div><div class="stat-hint">有混淆记录</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--warn)">' + wrongN + '</div><div class="stat-label">错误词</div><div class="stat-hint">有陌生记录</div></div>' +
      '<div class="card stat-card"><div class="stat-num">' + weakN + '</div><div class="stat-label">当前弱项</div><div class="stat-hint">阶段 &lt; 4 且错误多</div></div>';

    if (!keys.length) {
      tbody.innerHTML = '<tr><td colspan="12"><div class="empty"><div class="empty-icon">🎉</div><div class="empty-title">还没有错题</div><div class="empty-hint">继续加油，保持记录</div></div></td></tr>';
      return;
    }

    const frag = document.createDocumentFragment();
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i], w = App.library[k], st = App.states[k] || blankState();
      const m = App.mastery[k] || { stars: 1 };
      const tr = document.createElement('tr');
      tr.className = 'mistake';
      const lastWrong = getLastWrongDate(k) || '—';

      tr.innerHTML =
        '<td class="word-cell">' + esc(w.text) + '</td>' +
        '<td>' + esc(w.meaning || '') + '</td>' +
        '<td><span class="pill gray">第' + w.day + '天</span></td>' +
        '<td>' + groupPill(w) + '</td>' +
        '<td>' + starHtml(m.stars) + '</td>' +
        '<td><span class="pill">' + (st.stage || 0) + '</span></td>' +
        '<td><span class="badge bad" style="font-size:12px">' + (st.wrong || 0) + '</span></td>' +
        '<td><span class="badge pur" style="font-size:12px">' + (st.confuse || 0) + '</span></td>' +
        '<td><span class="muted">' + esc(lastWrong) + '</span></td>' +
        '<td><span class="muted">' + (st.last_rating || '-') + '</span></td>' +
        '<td>' + retentionBarHtml(k) + '</td>' +
        '<td><button class="btn btn-soft btn-sm" data-review-one="' + esc(k) + '">重练</button></td>';
      frag.appendChild(tr);
    }
    tbody.appendChild(frag);

    tbody.onclick = e => {
      let t = e.target;
      while (t && t !== tbody && !(t.getAttribute && t.getAttribute('data-review-one'))) t = t.parentNode;
      if (!t || t === tbody) return;
      const k = t.getAttribute('data-review-one');
      if (App.library[k]) startQueueFromKeys([k], 'weak', '错题重练');
    };
  };

  /* ============================================================
     复习曲线
     ============================================================ */
  window.renderCurve = function () {
    if (!el('curveStats')) return;
    const sched = computeSchedule();
    App._sched = sched;
    const today = sched.today;

    const todayKeys = sched.dueByDate[today] || [];
    const tomorrowKeys = sched.dueByDate[addDays(today, 1)] || [];
    let week7 = 0, later30 = 0;
    for (let i = 1; i <= 7; i++) week7 += (sched.dueByDate[addDays(today, i)] || []).length;
    for (let i = 8; i <= 30; i++) later30 += (sched.dueByDate[addDays(today, i)] || []).length;

    el('curveStats').innerHTML =
      '<div class="card stat-card"><div class="stat-num" style="color:var(--bad)">' + sched.overdue.length + '</div><div class="stat-label">已逾期</div><div class="stat-hint">需尽快补复习</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--primary)">' + todayKeys.length + '</div><div class="stat-label">今日到期</div><div class="stat-hint">' + today + '</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--warn)">' + tomorrowKeys.length + '</div><div class="stat-label">明日到期</div><div class="stat-hint">提前预热</div></div>' +
      '<div class="card stat-card"><div class="stat-num">' + week7 + '</div><div class="stat-label">未来 7 天</div><div class="stat-hint">复习压力预估</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--pur)">' + later30 + '</div><div class="stat-label">8–30 天</div><div class="stat-hint">长期记忆队列</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--text-m)">' + sched.unscheduled.length + '</div><div class="stat-label">尚未安排</div><div class="stat-hint">从未反馈过</div></div>';

    let maxN = 1;
    const cols = [];
    for (let d = 0; d < 14; d++) {
      const ds = addDays(today, d);
      const n = (sched.dueByDate[ds] || []).length;
      if (n > maxN) maxN = n;
      cols.push({ d: ds, n: n });
    }
    el('curveChart').innerHTML = cols.map((c, i) => {
      const pct = c.n ? Math.max(5, Math.round(c.n / maxN * 100)) : 0;
      const isToday = (i === 0);
      return '<div class="curve-col">' +
        '<div class="curve-num">' + (c.n || '') + '</div>' +
        '<div class="curve-track"><div class="curve-bar' + (c.n ? '' : ' zero') + (isToday ? ' is-today' : '') + '" style="height:' + pct + '%"></div></div>' +
        '<div class="curve-lab' + (isToday ? ' today' : '') + '">' + (isToday ? '今天' : c.d.slice(5)) + '</div>' +
      '</div>';
    }).join('');

    const allKeys = Object.keys(App.library);
    let dangerN = 0, midN = 0, safeN = 0;
    for (let i = 0; i < allKeys.length; i++) {
      if (!App.states[allKeys[i]] || !App.states[allKeys[i]].last_review) continue;
      const r = retentionRate(allKeys[i], today);
      const lvl = retentionLevel(r);
      if (lvl === 'danger') dangerN++;
      else if (lvl === 'mid') midN++;
      else safeN++;
    }
    el('memGrid').innerHTML =
      '<div class="mem-card"><div class="m-name" style="color:#22c55e">🟢 安全区（≥70%）</div><div class="m-num" style="color:#22c55e">' + safeN + '</div><div class="m-hint">记忆牢固，按计划复习即可</div></div>' +
      '<div class="mem-card"><div class="m-name" style="color:#f59e0b">🟡 临界区（40–70%）</div><div class="m-num" style="color:#f59e0b">' + midN + '</div><div class="m-hint">建议 1–2 天内复习</div></div>' +
      '<div class="mem-card"><div class="m-name" style="color:#ef4444">🔴 危险区（&lt;40%）</div><div class="m-num" style="color:#ef4444">' + dangerN + '</div><div class="m-hint">即将遗忘，优先复习</div></div>';

    const stageAcc = {};
    for (let i = 0; i < allKeys.length; i++) {
      const kk = allKeys[i];
      if (!App.states[kk] || !App.states[kk].last_review) continue;
      const sg = App.states[kk].stage || 0;
      if (!stageAcc[sg]) stageAcc[sg] = { sum: 0, n: 0 };
      stageAcc[sg].sum += retentionRate(kk, today);
      stageAcc[sg].n++;
    }
    let memRows = '';
    for (let si = 0; si < STAGE_GROUPS.length; si++) {
      const g = STAGE_GROUPS[si];
      let sum = 0, cnt = 0;
      for (let s = g.from; s <= g.to; s++) {
        if (stageAcc[s]) { sum += stageAcc[s].sum; cnt += stageAcc[s].n; }
      }
      if (!cnt) continue;
      const avg = sum / cnt;
      const pct = Math.round(avg * 100);
      const color = retentionColor(avg);
      const intervalTxt = INTERVALS[g.from] + (INTERVALS[g.to] !== INTERVALS[g.from] ? ('~' + INTERVALS[g.to]) : '') + ' 天';
      memRows += '<div class="dp-item">' +
        '<div class="dp-name">' + g.label + '</div>' +
        '<div class="dp-bar"><i style="width:' + pct + '%;background:' + color + '"></i></div>' +
        '<div class="dp-nums">平均保持率 <b style="color:' + color + '">' + pct + '%</b> ｜ 间隔 ' + intervalTxt + ' ｜ ' + cnt + ' 词</div>' +
      '</div>';
    }
    el('memCompare').innerHTML = memRows || '<div class="muted">暂无数据</div>';

    const stageKeys = {};
    const keys = Object.keys(App.library);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i], st = App.states[k] || {};
      const sg = st.stage || 0;
      if (!stageKeys[sg]) stageKeys[sg] = [];
      stageKeys[sg].push(k);
    }
    el('stagePlan').innerHTML = STAGE_GROUPS.map(g => {
      let total = 0, dueCount = 0;
      for (let s = g.from; s <= g.to; s++) {
        const arr = stageKeys[s] || [];
        total += arr.length;
        for (let j = 0; j < arr.length; j++) {
          const stt = App.states[arr[j]];
          if (stt && stt.due && stt.due <= today) dueCount++;
        }
      }
      const intervalTxt = '间隔 ' + INTERVALS[g.from] + (INTERVALS[g.to] !== INTERVALS[g.from] ? (' ~ ' + INTERVALS[g.to]) : '') + ' 天';
      const btn = dueCount
        ? '<button class="btn btn-soft sc-btn" data-stage-from="' + g.from + '" data-stage-to="' + g.to + '">▶ 复习到期 ' + dueCount + '</button>'
        : '<span class="muted" style="font-size:11.5px">当前无到期词</span>';
      return '<div class="stage-card">' +
        '<div class="sc-name">' + g.label + '</div>' +
        '<div class="sc-int">' + intervalTxt + ' · ' + g.hint + '</div>' +
        '<div class="sc-num">' + total + '</div>' +
        '<div class="sc-hint">词 · 其中到期 <b style="color:#ef4444">' + dueCount + '</b></div>' +
        btn +
      '</div>';
    }).join('');

    const dayNums = Object.keys(App.days).map(Number).filter(n => n > 0).sort((a, b) => a - b);
    if (!dayNums.length) {
      el('dayProgress').innerHTML = '<div class="muted">暂无按天数据</div>';
    } else {
      el('dayProgress').innerHTML = dayNums.map(d => {
        const arr = App.days[d] || [];
        const total = arr.length;
        let reviewed = 0, mastered = 0, dueN = 0;
        for (let i = 0; i < arr.length; i++) {
          const st = App.states[arr[i]] || {};
          if ((st.reviews || 0) > 0) reviewed++;
          if (isMastered(arr[i])) mastered++;
          if (st.due && st.due <= today) dueN++;
        }
        const pct = total ? Math.round(reviewed / total * 100) : 0;
        return '<div class="dp-item">' +
          '<div class="dp-name">第 ' + d + ' 天</div>' +
          '<div class="dp-bar"><i style="width:' + pct + '%"></i></div>' +
          '<div class="dp-nums">已复习 <b>' + reviewed + '</b>/' + total +
            ' ｜ 已掌握 <b style="color:#22c55e">' + mastered + '</b>' +
            ' ｜ 到期 <b style="color:#ef4444">' + dueN + '</b></div>' +
        '</div>';
      }).join('');
    }

    renderDueList(sched);
  };

  function dueGroupHtml(title, keys, cls, attr) {
    if (!keys.length) return '';
    const show = keys.slice(0, 120);
    const words = show.map(k => {
      const w = App.library[k];
      const r = retentionRate(k);
      const color = retentionColor(r);
      return '<span class="w" style="border-left:3px solid ' + color + '">' + esc(w ? w.text : k) + '</span>';
    }).join('');
    const more = keys.length > 120 ? '<span class="muted">… 等 ' + (keys.length - 120) + ' 个</span>' : '';
    return '<div class="due-group">' +
      '<div class="due-head' + (cls ? ' ' + cls : '') + '">' +
        '<div class="due-title">' + title + ' <b>' + keys.length + '</b> 词</div>' +
        '<button class="btn btn-soft" style="margin-left:auto" data-due="' + esc(attr) + '">▶ 复习这一组</button>' +
      '</div>' +
      '<div class="due-words">' + words + more + '</div>' +
    '</div>';
  }

  window.renderDueList = function (sched) {
    if (!el('dueList')) return;
    sched = sched || App._sched || computeSchedule();
    const today = sched.today;
    let html = '';

    if (sched.overdue.length) {
      const oldest = sched.overdue[0];
      const od = App.states[oldest] && App.states[oldest].due ? App.states[oldest].due : '';
      const odTxt = od ? ('（最早 ' + od + '，已逾期 ' + daysBetween(od, today) + ' 天）') : '';
      html += dueGroupHtml('⚠ 已逾期 ' + odTxt, sched.overdue, 'overdue', 'overdue');
    }

    const tKeys = sched.dueByDate[today] || [];
    if (tKeys.length) html += dueGroupHtml('📌 今天到期', tKeys, 'is-today', 'today');

    for (let i = 1; i <= 7; i++) {
      const d = addDays(today, i);
      const arr = sched.dueByDate[d] || [];
      if (arr.length) html += dueGroupHtml('📅 ' + d + '（第 ' + i + ' 天后）', arr, '', d);
    }

    let laterN = 0;
    for (let j = 8; j <= 30; j++) laterN += (sched.dueByDate[addDays(today, j)] || []).length;
    if (laterN) html += '<div class="due-later">另有 <b>' + laterN + '</b> 个词将在 8–30 天后到期</div>';

    if (!html) {
      html = '<div class="empty" style="padding:30px">' +
        '<div class="empty-icon">🌱</div>' +
        '<div class="empty-title">暂无到期词</div>' +
        '<div class="empty-hint">先去「今日复习」过一遍词汇，系统会自动安排复习曲线</div>' +
      '</div>';
    }
    el('dueList').innerHTML = html;
  };

  /* ============================================================
     未复习新词面板
     ============================================================ */
  window.renderNewWordPanel = function () {
    const panel = el('newWordPanel');
    const box = el('newWordGroups');
    if (!panel || !box) return;

    const keys = allUntouchedKeys();
    if (!keys.length) {
      panel.style.display = 'none';
      box.innerHTML = '';
      return;
    }
    panel.style.display = '';

    /* 按学习天分组 */
    const byDay = {};
    for (let i = 0; i < keys.length; i++) {
      const d = App.library[keys[i]].day || 0;
      if (!byDay[d]) byDay[d] = [];
      byDay[d].push(keys[i]);
    }
    const days = Object.keys(byDay).map(Number).sort((a, b) => a - b);

    let html = '';
    for (let i = 0; i < days.length; i++) {
      const d = days[i];
      const list = byDay[d];
      const show = list.slice(0, 14);
      const words = show.map(k =>
        '<span class="w">' + esc(App.library[k].text) + '</span>'
      ).join('');
      const more = list.length > show.length
        ? '<span class="muted">… 等 ' + (list.length - show.length) + ' 个</span>'
        : '';
      html += '<div class="due-group">' +
        '<div class="due-head">' +
          '<div class="due-title">第 ' + d + ' 天 · 未复习 <b>' + list.length + '</b> 个</div>' +
          '<button class="btn btn-soft" style="margin-left:auto" data-new-day="' + d + '">▶ 学这一组</button>' +
        '</div>' +
        '<div class="due-words">' + words + more + '</div>' +
      '</div>';
    }
    box.innerHTML = html;

    box.onclick = function (e) {
      let t = e.target;
      while (t && t !== box && !(t.getAttribute && t.getAttribute('data-new-day'))) t = t.parentNode;
      if (!t || t === box) return;
      const d = parseInt(t.getAttribute('data-new-day'), 10);
      const list = byDay[d] || [];
      if (!list.length) { showToast('这一组已无未复习词', 'warn'); return; }
      startQueueFromKeys(list, 'new', '第' + d + '天 新词学习');
    };
  };

  /* ============================================================
     词汇总览
     ============================================================ */
  window.groupPill = function (w) {
    const g = normalizeGroup(w.group) || '';
    if (!g) return '<span class="pill gray">-</span>';
    const cls = g === '基础词汇' ? 'g-basic' : (g === '过考词汇' ? 'g-pass' : (g === '核心' ? 'g-core' : 'gray'));
    return '<span class="pill ' + cls + '">' + esc(g) + '</span>';
  };

  window.renderBrowse = function () {
    const tbody = el('bTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    const q = (el('bSearch').value || '').trim().toLowerCase();
    const state = el('bState').value;
    const gfil = el('bGroup').value;
    const starFil = el('bStars') ? el('bStars').value : '全部';
    const stageFil = el('bStage') ? el('bStage').value : '全部';
    const errFil = el('bErrors') ? el('bErrors').value : '全部';
    const retFil = el('bRet') ? el('bRet').value : '全部';
    const day = App.selectedDay;
    const today = todayStr();
    const rows = [];
    const keys = Object.keys(App.library);

    for (let i = 0; i < keys.length; i++) {
      const k = keys[i], w = App.library[k];
      if (day !== 'all' && String(w.day) !== String(day)) continue;
      if (gfil !== '全部' && normalizeGroup(w.group) !== gfil) continue;
      const st = App.states[k] || blankState();
      const m = App.mastery[k] || { stars: 1, score: 0 };
      if (q && k.indexOf(q) < 0 && (w.meaning || '').toLowerCase().indexOf(q) < 0) continue;

      const isWeak = isWeakGlobal(k);
      const isGood = isMastered(k);
      const isUnfam = isUnfamiliar(k);
      const n = st.reviews || 0;
      const isUntouched = (n === 0 && !st.last_rating);
      const isDue = !!(st.due && st.due <= today);
      const sg = st.stage || 0;

      if (state === '未复习' && !isUntouched) continue;
      if (state === '非熟悉' && !isUnfam) continue;
      if (state === '弱项' && !isWeak) continue;
      if (state === '已掌握' && !isGood) continue;
      if (state === '已到期' && !isDue) continue;

      if (starFil !== '全部' && String(m.stars) !== String(starFil)) continue;

      if (stageFil !== '全部') {
        if (stageFil === '0-1' && sg > 1) continue;
        if (stageFil === '2' && sg !== 2) continue;
        if (stageFil === '3' && sg !== 3) continue;
        if (stageFil === '4' && sg !== 4) continue;
        if (stageFil === '5-9' && sg < 5) continue;
      }
      if (errFil !== '全部') {
        const wc = st.wrong || 0;
        if (errFil === '0' && wc !== 0) continue;
        if (errFil === '1' && wc !== 1) continue;
        if (errFil === '2' && wc !== 2) continue;
        if (errFil === '3+' && wc < 3) continue;
      }
      if (retFil !== '全部') {
        const r = retentionRate(k, today);
        const lvl = retentionLevel(r);
        if (retFil === 'safe' && lvl !== 'safe') continue;
        if (retFil === 'mid' && lvl !== 'mid') continue;
        if (retFil === 'danger' && lvl !== 'danger') continue;
      }

      let cls = '';
      if (isWeak) cls = 'weak';
      else if (isGood) cls = 'good';
            rows.push({ k: k, w: w, st: st, m: m, cls: cls, day: w.day || 999 });
    }
    rows.sort((a, b) => (a.day - b.day) || a.w.text.localeCompare(b.w.text));

    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="13"><div class="empty"><div class="empty-icon">🔍</div><div class="empty-title">没有符合条件的词</div><div class="empty-hint">试试切换天数、分组或调整筛选</div></div></td></tr>';
      return;
    }

    const frag = document.createDocumentFragment();
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i], k = r.k, w = r.w, st = r.st, m = r.m;
      const tr = document.createElement('tr');
      if (r.cls) tr.className = r.cls;
      const hist = (st.history || []).map(h => h.r);
      const histHtml = hist.length
        ? '<span class="hist-cell">' + histChainHtml(hist) + '</span>'
        : '<span class="muted">—</span>';

      let dueHtml = '<span class="muted">—</span>';
      if (st.due) {
        const dd = daysBetween(today, st.due);
        const color = dd < 0 ? 'var(--bad)' : (dd === 0 ? 'var(--ok)' : 'var(--text-2)');
        const label = dd < 0 ? ('逾期 ' + (-dd) + ' 天') : (dd === 0 ? '今天' : (dd + ' 天后'));
        dueHtml = '<span class="muted" style="color:' + color + ';font-weight:600">' + st.due +
          '<br><span style="font-size:10.5px">' + label + '</span></span>';
      }

      tr.innerHTML =
        '<td class="word-cell">' + esc(w.text) + '</td>' +
        '<td>' + esc(w.meaning) + '</td>' +
        '<td><span class="pill gray">第' + w.day + '天</span></td>' +
        '<td>' + groupPill(w) + '</td>' +
        '<td>' + starHtml(m.stars) + '</td>' +
        '<td><span class="muted" style="font-weight:700;color:var(--primary)">' + m.score.toFixed(1) + '</span></td>' +
        '<td>' + histHtml + '</td>' +
        '<td><span class="pill">' + (st.stage || 0) + '</span></td>' +
        '<td><span class="muted">' + (st.reviews || 0) + '</span></td>' +
        '<td><span class="muted">' + (st.last_rating || '-') + '</span></td>' +
        '<td><span class="muted">' + (st.wrong || 0) + '</span></td>' +
        '<td>' + retentionBarHtml(k) + '</td>' +
        '<td>' + dueHtml + '</td>';
      frag.appendChild(tr);
    }
    tbody.appendChild(frag);
  };

  /* ============================================================
     易混 / 近义
     ============================================================ */
  window.relationGroups = function () {
    const rel = App.relations, groups = [];
    let seen = {}, keys = Object.keys(rel);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      if (seen[k] || !rel[k].form.length) continue;
      const comp = [k]; seen[k] = 1;
      const stack = rel[k].form.slice();
      while (stack.length) {
        const x = stack.pop();
        if (seen[x]) continue;
        seen[x] = 1; comp.push(x);
        const xf = (rel[x] && rel[x].form) || [];
        for (let j = 0; j < xf.length; j++) if (!seen[xf[j]]) stack.push(xf[j]);
      }
      if (comp.length >= 2) {
        comp.sort((a, b) => App.library[a].text.localeCompare(App.library[b].text));
        groups.push(['形近易混', comp]);
      }
    }
    let seen2 = {}, keys2 = Object.keys(rel);
    for (let i = 0; i < keys2.length; i++) {
      const k2 = keys2[i];
      if (seen2[k2] || !rel[k2].syn.length) continue;
      const comp2 = [k2]; seen2[k2] = 1;
      const stack2 = rel[k2].syn.slice();
      while (stack2.length) {
        const x2 = stack2.pop();
        if (seen2[x2]) continue;
        seen2[x2] = 1; comp2.push(x2);
        const xs = (rel[x2] && rel[x2].syn) || [];
        for (let j = 0; j < xs.length; j++) if (!seen2[xs[j]]) stack2.push(xs[j]);
      }
      if (comp2.length >= 2) {
        comp2.sort((a, b) => App.library[a].text.localeCompare(App.library[b].text));
        groups.push(['近义替换', comp2]);
      }
    }
    return groups;
  };

  window.renderConfuse = function () {
    const list = el('relList');
    if (!list) return;
    list.innerHTML = '';
    const filter = el('cFilter').value;
    const day = App.selectedDay;
    const groups = relationGroups();
    const items = groups.filter(g => {
      if (filter !== '全部' && g[0] !== filter) return false;
      if (day !== 'all') {
        for (let i = 0; i < g[1].length; i++) {
          const w = App.library[g[1][i]];
          if (w && String(w.day) === String(day)) return true;
        }
        return false;
      }
      return true;
    });
    if (!items.length) {
      const hintTxt = (App.synonyms && Object.keys(App.synonyms).length === 0)
        ? '当前 synonyms.json 为空，可在数据页查看路径并手动编辑'
        : '试试切换天数或类型';
      list.innerHTML = '<div class="card empty"><div class="empty-icon">🧩</div><div class="empty-title">暂无可显示的词组</div><div class="empty-hint">' + hintTxt + '</div></div>';
      return;
    }
    for (let i = 0; i < items.length; i++) {
      (function (item) {
        const type = item[0], keys = item[1];
        const div = document.createElement('div');
        div.className = 'card rel-item';
        const words = keys.map(k => App.library[k].text).join('  ·  ');
        const means = keys.map(k => (App.library[k].meaning || '').slice(0, 26)).join('  ／  ');
        const typeCls = type === '近义替换' ? 'syn' : 'form';
        div.innerHTML =
          '<div class="rel-words"><span class="r-type ' + typeCls + '">' + type + '</span>' + esc(words) + '</div>' +
          '<div class="rel-mean">' + esc(means) + '</div>';
        div.addEventListener('click', () => {
          const detail = keys.map(k => {
            const w = App.library[k];
            const st = App.states[k] || blankState();
            const m = App.mastery[k] || { stars: 1 };
            const hist = (st.history || []).map(h => h.r);
            const histHtml = hist.length ? '　历史：' + histChainHtml(hist) : '';
            return '● <b>' + esc(w.text) + '</b> ' + starText(m.stars) +
              '  ——  ' + esc(w.meaning || '（无释义）') + histHtml;
          }).join('<br>');
          let box = div.querySelector('.rel-detail');
          if (box) box.remove();
          else {
            box = document.createElement('div');
            box.className = 'rel-detail';
            box.innerHTML = detail;
            div.appendChild(box);
          }
        });
        list.appendChild(div);
      })(items[i]);
    }
  };

  /* ============================================================
     诊断统计
     ============================================================ */
  window.renderStats = function () {
    const s = computeStats();
    const pools = collectPools(App.selectedDay);
    const dist = starDistribution();
    const dayText = App.selectedDay === 'all' ? '全部' : ('第' + App.selectedDay + '天');

    el('statsGrid').innerHTML =
      '<div class="card stat-card"><div class="stat-num">' + pools.all.length + '</div><div class="stat-label">当前范围</div><div class="stat-hint">' + dayText + '</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--primary)">' + pools.queueCount + '</div><div class="stat-label">本轮候选</div><div class="stat-hint">当前模式筛选结果</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--warn)">' + pools.unfam.length + '</div><div class="stat-label">非熟悉</div><div class="stat-hint">需巩固的词</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--bad)">' + pools.weak.length + '</div><div class="stat-label">弱项 / 重灾</div><div class="stat-hint">阶段&lt;4 且错误多</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--ok)">' + pools.good.length + '</div><div class="stat-label">已掌握</div><div class="stat-hint">阶段 ≥ 4</div></div>' +
      '<div class="card stat-card"><div class="stat-num">' + s.sessions + '</div><div class="stat-label">历史会话数</div><div class="stat-hint">共 ' + s.answers + ' 次答题</div></div>';

    /* 星级分布 */
    const starColors = { 1: 'var(--star1)', 2: 'var(--star2)', 3: 'var(--star3)', 4: 'var(--star4)', 5: 'var(--star5)' };
    const starLabels = { 1: '★1 生疏', 2: '★2 薄弱', 3: '★3 一般', 4: '★4 良好', 5: '★5 精通' };
    const maxStar = Math.max(1, ...Object.values(dist.dist));
    el('starDist').innerHTML = [1, 2, 3, 4, 5].map(n => {
      const v = dist.dist[n] || 0;
      const pct = (v / maxStar * 100).toFixed(1);
      return '<div class="dist-row">' +
        '<div class="dist-name" style="color:' + starColors[n] + ';width:64px">' + starLabels[n] + '</div>' +
        '<div class="dist-track"><div class="dist-fill" style="width:' + pct + '%;background:' + starColors[n] + '"></div></div>' +
        '<div class="dist-num">' + v + '</div>' +
      '</div>';
    }).join('');

    /* 反馈分布 */
    let maxN = 1;
    for (let i = 0; i < RATINGS.length; i++) {
      const n = s.byRating[RATINGS[i]] || 0;
      if (n > maxN) maxN = n;
    }
    el('distList').innerHTML = RATINGS.map(r => {
      const n = s.byRating[r] || 0;
      const pct = (n / maxN * 100).toFixed(1);
      return '<div class="dist-row"><div class="dist-name" style="color:' + RATING_COLORS[r] + '">' + r + '</div>' +
        '<div class="dist-track"><div class="dist-fill" style="width:' + pct + '%;background:' + RATING_COLORS[r] + '"></div></div>' +
        '<div class="dist-num">' + n + '</div></div>';
    }).join('');

    renderHeatmapLegacy();
    renderEfficiency();

    /* 分组统计 */
    const gstats = {};
    for (const k in App.library) {
      const w = App.library[k];
      const g = normalizeGroup(w.group) || '未分组';
      const s2 = gstats[g] || (gstats[g] = { total: 0, known: 0, weak: 0, newc: 0, stageSum: 0, starSum: 0, starN: 0 });
      const st = App.states[k] || {};
      const m = App.mastery[k];
      s2.total++;
      if (isMastered(k)) s2.known++;
      if (isWeakGlobal(k)) s2.weak++;
      if ((st.reviews || 0) === 0) s2.newc++;
      s2.stageSum += (st.stage || 0);
      if (m) { s2.starSum += m.stars; s2.starN++; }
    }
    let html = '';
    const order = GROUP_ORDER.concat(['未分组']);
    for (let oi = 0; oi < order.length; oi++) {
      const g = order[oi];
      const st2 = gstats[g]; if (!st2) continue;
      const color = GROUP_COLORS[g] || '#94a3b8';
      const hint = GROUP_HINTS[g] || '';
      const avg = (st2.total ? st2.stageSum / st2.total : 0).toFixed(2);
      const avgStar = st2.starN ? (st2.starSum / st2.starN).toFixed(2) : '—';
      html += '<div class="group-card" style="border-left-color:' + color + '">' +
        '<div class="g-name" style="color:' + color + '">' + g + ' <span class="g-hint">' + hint + '</span></div>' +
        '<div class="g-nums">共 <b>' + st2.total + '</b> 词 ｜ 已掌握 <b>' + st2.known + '</b> ｜ 薄弱 <b style="color:#ef4444">' + st2.weak + '</b> ｜ 未学 <b>' + st2.newc + '</b> ｜ 平均阶段 <b>' + avg + '</b> ｜ 平均 <b>' + avgStar + '★</b></div>' +
      '</div>';
    }
    el('groupStats').innerHTML = html || '<div class="muted">暂无分组数据</div>';

    /* 焦点词 */
    const candidates = pools.all.length ? pools.all.slice() : Object.keys(App.library);
    candidates.sort((a, b) => {
      const A = App.states[a] || {}, B = App.states[b] || {};
      return (B.confuse || 0) - (A.confuse || 0) || (B.wrong || 0) - (A.wrong || 0) || (A.stage || 0) - (B.stage || 0) || (B.reviews || 0) - (A.reviews || 0);
    });
    const top = candidates.slice(0, 25);
    if (!top.length) {
      el('focusList').innerHTML = '<div class="empty" style="padding:30px"><div class="empty-hint">暂无数据</div></div>';
    } else {
      el('focusList').innerHTML = top.map((k, idx) => {
        const w = App.library[k], st = App.states[k] || {};
        const m = App.mastery[k] || { stars: 1 };
        const badges = [];
        const grp = normalizeGroup(w.group);
        if (grp) badges.push('<span class="badge gray">' + esc(grp) + '</span>');
        if (st.confuse) badges.push('<span class="badge pur">混淆 ' + st.confuse + '</span>');
        if (st.wrong) badges.push('<span class="badge bad">错误 ' + st.wrong + '</span>');
        badges.push('<span class="badge warn">阶段 ' + (st.stage || 0) + '</span>');
        return '<div class="focus-item">' +
          '<div class="focus-rank">' + (idx + 1) + '</div>' +
          '<div class="focus-word">' + esc(w.text) + '</div>' +
          '<div class="focus-meaning">' + esc(w.meaning || '') + '</div>' +
          '<div class="focus-badges">' + starHtml(m.stars) + badges.join('') + '</div>' +
        '</div>';
      }).join('');
    }

    const days = Object.keys(s.byDate).sort();
    el('dailyList').innerHTML = days.length
      ? days.map(d => d + '    <b style="color:var(--text)">' + s.byDate[d] + '</b> 题').join('<br>')
      : '<div class="muted">暂无历史记录</div>';
  };

  function renderHeatmapLegacy() {
    const hm = el('heatmap'); if (!hm) return;
    const byDate = computeStats().byDate;
    const today = todayStr();
    const start = addDays(today, -89);

    const cells = [];
    let d = start, maxN = 1, totalN = 0, activeDays = 0;
    while (d <= today) {
      const n = byDate[d] || 0;
      if (n > maxN) maxN = n;
      if (n > 0) { totalN += n; activeDays++; }
      cells.push({ d: d, n: n });
      d = addDays(d, 1);
    }

    hm.innerHTML = cells.map(c => {
      let level = 0;
      if (c.n > 0) {
        const r = c.n / maxN;
        if (r <= 0.15) level = 1;
        else if (r <= 0.4) level = 2;
        else if (r <= 0.7) level = 3;
        else level = 4;
      }
      return '<div class="hm-cell hm-' + level + '" title="' + c.d + '：' + c.n + ' 题"></div>';
    }).join('');

    const hint = el('heatmapHint');
    if (hint) hint.textContent = '近 90 天：' + activeDays + ' 天有记录，共 ' + totalN + ' 题';
  }

  function renderEfficiency() {
    const box = el('efficiencyStats'); if (!box) return;
    const all = allSessionsFlat();
    let totalMs = 0, msN = 0, totalN = 0, rightN = 0;
    const byDate = {};

    for (let i = 0; i < all.length; i++) {
      const date = all[i][0];
      const rev = all[i][1].reviews || [];
      if (!byDate[date]) byDate[date] = { n: 0, right: 0, ms: 0, msN: 0 };
      for (let j = 0; j < rev.length; j++) {
        const r = rev[j];
        totalN++;
        if (r.elapsed_ms) { totalMs += r.elapsed_ms; msN++; }
        const isRight = (r.rating === '熟悉' || r.rating === '模糊');
        if (isRight) rightN++;
        byDate[date].n++;
        if (isRight) byDate[date].right++;
        if (r.elapsed_ms) { byDate[date].ms += r.elapsed_ms; byDate[date].msN++; }
      }
    }

    const avgSec = msN ? (totalMs / msN / 1000).toFixed(2) : '—';
    const acc = totalN ? (rightN / totalN * 100).toFixed(1) : '—';
    const dates = Object.keys(byDate).sort().slice(-14);

    const trendRows = dates.map(d => {
      const s = byDate[d];
      const a = s.n ? (s.right / s.n * 100) : 0;
      const ms = s.msN ? (s.ms / s.msN / 1000) : 0;
      const color = a >= 80 ? '#22c55e' : (a >= 60 ? '#f59e0b' : '#ef4444');
      return '<div class="dp-item">' +
        '<div class="dp-name" style="width:88px">' + d + '</div>' +
        '<div class="dp-bar"><i style="width:' + a.toFixed(1) + '%;background:' + color + '"></i></div>' +
        '<div class="dp-nums">正确率 <b style="color:' + color + '">' + a.toFixed(1) + '%</b> ｜ ' + s.n + ' 题 ｜ 均 ' + ms.toFixed(2) + ' 秒</div>' +
      '</div>';
    }).join('');

    box.innerHTML =
      '<div class="stats-grid" style="margin-bottom:14px">' +
        '<div class="card stat-card"><div class="stat-num" style="color:var(--primary)">' + avgSec + '<span style="font-size:14px"> 秒</span></div><div class="stat-label">平均每题耗时</div><div class="stat-hint">' + msN + ' 次有计时</div></div>' +
        '<div class="card stat-card"><div class="stat-num" style="color:var(--ok)">' + acc + '<span style="font-size:14px">%</span></div><div class="stat-label">总体正确率</div><div class="stat-hint">熟悉 + 模糊</div></div>' +
        '<div class="card stat-card"><div class="stat-num">' + totalN + '</div><div class="stat-label">总答题数</div><div class="stat-hint">含所有轮次</div></div>' +
        '<div class="card stat-card"><div class="stat-num">' + Object.keys(byDate).length + '</div><div class="stat-label">有效学习天数</div><div class="stat-hint">有过答题记录</div></div>' +
      '</div>' +
      '<div style="font-size:13px;font-weight:700;margin-bottom:6px">最近 14 天正确率趋势</div>' +
      (trendRows || '<div class="muted">暂无数据</div>');
  }

  /* ============================================================
     学习计划
     ============================================================ */
  window.renderPlan = async function () {
    if (!el('planStats')) return;

    if (!App.plan || App.plan.base_date !== todayStr()) {
      generateLearningPlan();
      await savePlan();          /* 生成后立即持久化到 IndexedDB */
    }
    const plan = App.plan;
    const dist = starDistribution();

    el('planStats').innerHTML =
      '<div class="card stat-card"><div class="stat-num" style="color:var(--bad)">' + dist.dist[1] + '</div><div class="stat-label">★1 生疏</div><div class="stat-hint">每日专项 15 词</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--warn)">' + dist.dist[2] + '</div><div class="stat-label">★2 薄弱</div><div class="stat-hint">反向回忆训练</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--star3)">' + dist.dist[3] + '</div><div class="stat-label">★3 一般</div><div class="stat-hint">常规复习</div></div>' +
      '<div class="card stat-card"><div class="stat-num" style="color:var(--ok)">' + (dist.dist[4] + dist.dist[5]) + '</div><div class="stat-label">★4–★5 稳固</div><div class="stat-hint">维持即可</div></div>';

    el('planTable').innerHTML = plan.daily.map(d => {
      const totalT = d.review_target + d.new_target + d.hard_target;
      const cap = Math.max(totalT, 40);
      const wRev = (d.review_target / cap * 100).toFixed(1);
      const wNew = (d.new_target / cap * 100).toFixed(1);
      const wHard = (d.hard_target / cap * 100).toFixed(1);
      return '<div class="plan-day">' +
        '<div class="pd-name">' + (d.day === 0 ? '今天' : '第' + d.day + '天') + '<br><span style="font-size:10.5px;color:var(--text-m);font-weight:400">' + d.date.slice(5) + '</span></div>' +
        '<div class="pd-bar">' +
          '<i class="rev" style="width:' + wRev + '%" title="复习"></i>' +
          '<i class="new" style="width:' + wNew + '%" title="新词"></i>' +
          '<i class="hard" style="width:' + wHard + '%" title="难词"></i>' +
        '</div>' +
        '<div class="pd-nums">复习 <b>' + d.review_target + '</b> ｜ 新词 <b>' + d.new_target + '</b> ｜ 难词 <b>' + d.hard_target + '</b>' +
          ' ｜ 到期 <b style="color:var(--warn)">' + d.due_total + '</b>' +
          (d.note ? '<br><span style="font-size:10.5px;color:var(--text-m)">' + esc(d.note) + '</span>' : '') +
        '</div>' +
      '</div>';
    }).join('');

    el('planAdvice').innerHTML = plan.advice.map(a =>
      '<div class="plan-advice-item s' + a.level + '">' + a.text + '</div>'
    ).join('');
  };

  /* ============================================================
     数据页
     ============================================================ */
  window.renderData = function () {
    const wdInfo = el('wdInfo');
    if (!wdInfo) return;
    if (!Store.base) {
      wdInfo.innerHTML = '未连接数据目录';
    } else {
      wdInfo.innerHTML =
        '<div>数据根：<b>' + esc(Store.base.href) + '</b></div>' +
        '<div>目录下文件：<b>' + Store.files.length + '</b> 个</div>' +
        '<div>状态：' + (App.ready ? '已连接，实时保存中' : '未连接') + '</div>';
    }

    const li = App.loadInfo;
    let info = '';
    info += '<div>✔ 已加载 <b>' + Object.keys(App.library).length + '</b> 个单词，覆盖 <b>' + Object.keys(App.days).filter(d => +d > 0).length + '</b> 天</div>';
    info += '<div>学习文件：' + ((li.studyFiles && li.studyFiles.length) ? li.studyFiles.join('、') : '（未加载）') + '</div>';
    if (li.byGroup) {
      const parts = [];
      for (const g in li.byGroup) if (li.byGroup[g]) parts.push(g + ' ' + li.byGroup[g]);
      info += '<div>分组分布：' + (parts.length ? parts.join('  ·  ') : '—') + '</div>';
    }
    info += '<div>历史会话天数：<b>' + Object.keys(App.sessions).length + '</b> 天</div>';
    info += '<div>训练记录：<b>' + Object.keys(App.training).length + '</b> 天</div>';
    if (App.settings.libPrefix) info += '<div>当前词库前缀：<b>' + esc(App.settings.libPrefix) + '</b></div>';
    el('libInfo').innerHTML = info;

    const auxInfo = el('auxInfo');
    if (auxInfo) {
      const synCount = Object.keys(App.synonyms || {}).length;
      const typoCount = Object.keys(App.typoHints || {}).length;
      const colloCount = Object.keys(App.collocations || {}).length;
      const synUrl = Store.base ? Store.url(AUX_SYNONYMS) : AUX_SYNONYMS;
      const typoUrl = Store.base ? Store.url(AUX_TYPO_HINTS) : AUX_TYPO_HINTS;
      const colloUrl = Store.base ? Store.url(AUX_COLLOCATIONS) : AUX_COLLOCATIONS;
      auxInfo.innerHTML =
        '<div><a href="' + esc(synUrl) + '" target="_blank" style="color:var(--primary)">' + esc(AUX_SYNONYMS) + '</a> — 近义词典，当前 <b>' + synCount + '</b> 个词条</div>' +
        '<div><a href="' + esc(typoUrl) + '" target="_blank" style="color:var(--primary)">' + esc(AUX_TYPO_HINTS) + '</a> — 拼写提示，当前 <b>' + typoCount + '</b> 条</div>' +
        '<div><a href="' + esc(colloUrl) + '" target="_blank" style="color:var(--primary)">' + esc(AUX_COLLOCATIONS) + '</a> — 常用搭配，当前 <b>' + colloCount + '</b> 条</div>' +
        '<div style="color:var(--text-m);font-size:11.5px;margin-top:6px">格式：JSON 对象，键为小写单词。</div>';
    }

    const notice = el('dataNotice');
    const notices = [];
    if (!Object.keys(App.library).length) {
      notices.push('<div class="notice info">尚未加载词库。请检查数据目录下是否有 <code>第N天词汇学习.xlsx</code> 文件，然后点「重载词库」。</div>');
    } else {
      notices.push('<div class="notice ok">✔ 词库已就绪，数据实时保存中</div>');
    }
    if (li.skipped && li.skipped.length) {
      const list = li.skipped.map(s => '· <code>' + esc(s.name) + '</code> —— ' + esc(s.why)).join('<br>');
      notices.push('<div class="notice warn"><b>⚠ 以下文件被跳过：</b><br>' + list + '</div>');
    }
    if (li.typos && li.typos.length) {
      const tl = li.typos.map(t => '· <code>' + esc(t[0]) + '</code> 中 <code>' + esc(t[1]) + '</code> → 建议 <code>' + esc(t[2]) + '</code>').join('<br>');
      notices.push('<div class="notice warn"><b>⚠ 拼写疑似错误：</b><br>' + tl + '</div>');
    }
    notice.innerHTML = notices.join('');

    if (el('setNewLimit')) el('setNewLimit').value = App.settings.dailyNewLimit;
    if (el('setReviewLimit')) el('setReviewLimit').value = App.settings.dailyReviewLimit;
    if (el('setOverdueDays')) el('setOverdueDays').value = App.settings.overdueDays;
    if (el('setFastMs')) el('setFastMs').value = App.settings.fastMs;
    if (el('setSlowMs')) el('setSlowMs').value = App.settings.slowMs;
    if (el('setTrainBatch')) el('setTrainBatch').value = App.settings.trainBatch;
    if (el('setLibPrefix')) el('setLibPrefix').value = App.settings.libPrefix || '';
    if (el('setColWord')) el('setColWord').value = App.settings.colWord;
    if (el('setColMeaning')) el('setColMeaning').value = App.settings.colMeaning;
    if (el('setColTag')) el('setColTag').value = App.settings.colTag;
  };

  /* ============================================================
     导出
     ============================================================ */
  function collectDayWordRatings() {
    const dayWord = {};
    for (const k in App.library) {
      const w = App.library[k];
      if (!w.day) continue;
      if (!dayWord[w.day]) dayWord[w.day] = {};
      dayWord[w.day][w.text] = [];
    }
    const dates = Object.keys(App.sessions).sort();
    for (let di = 0; di < dates.length; di++) {
      const sess = App.sessions[dates[di]].sessions || [];
      for (let si = 0; si < sess.length; si++) {
        const rev = sess[si].reviews || [];
        for (let ri = 0; ri < rev.length; ri++) {
          const r = rev[ri];
          const key = String(r.key || r.word || '').trim().toLowerCase();
          const w = App.library[key];
          if (!w || !w.day) continue;
          if (!dayWord[w.day]) dayWord[w.day] = {};
          if (!dayWord[w.day][w.text]) dayWord[w.day][w.text] = [];
          dayWord[w.day][w.text].push({ ts: r.ts || dates[di] + 'T00:00:00', rating: r.rating || '' });
        }
      }
    }
    for (const d in dayWord) {
      for (const text in dayWord[d]) {
        dayWord[d][text].sort((a, b) => a.ts.localeCompare(b.ts));
      }
    }
    return dayWord;
  }

  window.exportMaster = function () {
    try {
      const dayWord = collectDayWordRatings();
      const aoa = [];
      const dayNums = Object.keys(dayWord).map(Number).sort((a, b) => a - b);
      for (let di = 0; di < dayNums.length; di++) {
        const d = dayNums[di];
        aoa.push(['第' + d + '天']);
        const words = Object.keys(dayWord[d]).sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
        for (let wi = 0; wi < words.length; wi++) {
          const text = words[wi];
          const entries = dayWord[d][text];
          const row = [text];
          for (let ei = 0; ei < entries.length; ei++) row.push(entries[ei].rating);
          aoa.push(row);
        }
        aoa.push([]);
      }
      downloadXlsx('词汇熟悉度总表.xlsx', aoa, 'Sheet1');
      showToast('已导出 词汇熟悉度总表.xlsx', 'ok');
    } catch (e) {
      console.error('[export]', e);
      showToast('导出失败：' + e.message, 'err');
    }
  };

  window.previewMaster = function () {
    const dayWord = collectDayWordRatings();
    const dayNums = Object.keys(dayWord).map(Number).sort((a, b) => a - b);
    if (!dayNums.length) {
      el('masterPreview').innerHTML = '<div class="muted">暂无数据</div>';
      return;
    }
    let html = '';
    for (let di = 0; di < dayNums.length; di++) {
      const d = dayNums[di];
      const total = Object.keys(dayWord[d]).length;
      let withHist = 0, ratingsCount = 0;
      for (const text in dayWord[d]) {
        if (dayWord[d][text].length) { withHist++; ratingsCount += dayWord[d][text].length; }
      }
      html += '<div style="margin:6px 0">第 <b>' + d + '</b> 天：共 <b>' + total + '</b> 词，已反馈 <b>' + withHist + '</b> 词，共 <b>' + ratingsCount + '</b> 条反馈</div>';
    }
    el('masterPreview').innerHTML = html;
  };

  window.exportMastery = function () {
    try {
      refreshMastery();
      const dist = starDistribution();
      const out = {
        generated_at: nowISO(),
        version: 1,
        total: dist.total,
        avg_score: dist.avg,
        star_distribution: dist.dist,
        words: {}
      };
      for (const k in App.mastery) {
        if (!App.mastery.hasOwnProperty(k)) continue;
        const m = App.mastery[k];
        out.words[k] = {
          text: m.text,
          meaning: m.meaning,
          day: m.day,
          group: m.group,
          stars: m.stars,
          score: parseFloat(m.score.toFixed(2)),
          stage: m.stage,
          reviews: m.reviews,
          wrong: m.wrong,
          confuse: m.confuse,
          retention: parseFloat(m.retention.toFixed(4)),
          accuracy: parseFloat(m.accuracy.toFixed(4)),
          streak: m.streak,
          confidence: m.confidence
        };
      }
      downloadJSON('vocabulary_mastery.json', out);
      showToast('已导出 vocabulary_mastery.json', 'ok');
    } catch (e) {
      console.error('[export mastery]', e);
      showToast('导出失败：' + e.message, 'err');
    }
  };

  window.exportMistakes = function () {
    try {
      const keys = getMistakeKeys('all');
      const aoa = [['单词', '释义', '天', '分组', '星级', '掌握分', '阶段', '错误次数', '混淆次数', '最近错误', '上次评分', '保持率', '下次到期']];
      const today = todayStr();
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i], w = App.library[k], st = App.states[k] || blankState();
        const m = App.mastery[k] || { stars: 1, score: 0 };
        const r = retentionRate(k, today);
        aoa.push([
          w.text, w.meaning || '', w.day, normalizeGroup(w.group) || '',
          m.stars, m.score.toFixed(1),
          st.stage || 0, st.wrong || 0, st.confuse || 0,
          getLastWrongDate(k) || '', st.last_rating || '',
          r ? Math.round(r * 100) + '%' : '',
          st.due || ''
        ]);
      }
      downloadXlsx('错题明细.xlsx', aoa, '错题明细');
      showToast('已导出 错题明细.xlsx（' + keys.length + ' 词）', 'ok');
    } catch (e) {
      console.error('[export mistakes]', e);
      showToast('导出失败：' + e.message, 'err');
    }
  };

  window.exportWeak = function () {
    try {
      const keys = Object.keys(App.library).filter(isWeakGlobal).sort(compareMistakes);
      const aoa = [['单词', '释义', '天', '分组', '星级', '阶段', '错误次数', '混淆次数', '上次评分', '保持率', '下次到期']];
      const today = todayStr();
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i], w = App.library[k], st = App.states[k] || blankState();
        const m = App.mastery[k] || { stars: 1 };
        const r = retentionRate(k, today);
        aoa.push([
          w.text, w.meaning || '', w.day, normalizeGroup(w.group) || '',
          m.stars, st.stage || 0, st.wrong || 0, st.confuse || 0,
          st.last_rating || '',
          r ? Math.round(r * 100) + '%' : '',
          st.due || ''
        ]);
      }
      downloadXlsx('弱项清单.xlsx', aoa, '弱项');
      showToast('已导出 弱项清单.xlsx（' + keys.length + ' 词）', 'ok');
    } catch (e) {
      console.error('[export weak]', e);
      showToast('导出失败：' + e.message, 'err');
    }
  };

  window.exportDaily = function () {
    try {
      const s = computeStats();
      const dates = Object.keys(s.byDate).sort();
      const aoa = [['日期', '答题数']];
      for (let i = 0; i < dates.length; i++) aoa.push([dates[i], s.byDate[dates[i]]]);
      downloadXlsx('每日答题记录.xlsx', aoa, '每日记录');
      showToast('已导出 每日答题记录.xlsx', 'ok');
    } catch (e) {
      console.error('[export daily]', e);
      showToast('导出失败：' + e.message, 'err');
    }
  };

  window.exportSessions = function () {
    try {
      const aoa = [['日期', '会话ID', '开始时间', '结束时间', '模式', '计划题数', '完成题数', '熟悉', '模糊', '陌生', '混淆']];
      const dates = Object.keys(App.sessions).sort();
      for (let di = 0; di < dates.length; di++) {
        const d = dates[di];
        const sess = App.sessions[d].sessions || [];
        for (let si = 0; si < sess.length; si++) {
          const s = sess[si];
          const sum = s.summary || {};
          aoa.push([
            d, s.session_id || '', s.started_at || '', s.ended_at || '',
            s.mode || '', s.total_planned || 0, s.answered || 0,
            sum.熟悉 || 0, sum.模糊 || 0, sum.陌生 || 0, sum.混淆 || 0
          ]);
        }
      }
      downloadXlsx('会话明细.xlsx', aoa, '会话');
      showToast('已导出 会话明细.xlsx', 'ok');
    } catch (e) {
      console.error('[export sessions]', e);
      showToast('导出失败：' + e.message, 'err');
    }
  };

  window.exportTraining = function () {
    try {
      const aoa = [['日期', '会话ID', '开始时间', '结束时间', '题型', '范围', '总题数', '正确', '错误', '正确率', '回炉轮次', '单词', '题型', '结果', '输入', '正确答案']];
      const dates = Object.keys(App.training).sort();
      for (let di = 0; di < dates.length; di++) {
        const d = dates[di];
        const list = App.training[d] || [];
        for (let si = 0; si < list.length; si++) {
          const t = list[si];
          if (t.results && t.results.length) {
            for (let ri = 0; ri < t.results.length; ri++) {
              const r = t.results[ri];
              const w = App.library[r.key];
              aoa.push([
                d, t.session_id, t.started_at, t.ended_at,
                t.mode, t.scope, t.total, t.correct, t.wrong,
                t.accuracy.toFixed(1) + '%', t.reinserted,
                w ? w.text : r.key, r.type, r.correct ? '✓' : '✗',
                r.input, r.expected
              ]);
            }
          } else {
            aoa.push([d, t.session_id, t.started_at, t.ended_at, t.mode, t.scope,
              t.total, t.correct, t.wrong, t.accuracy.toFixed(1) + '%', t.reinserted,
              '', '', '', '', '']);
          }
        }
      }
      downloadXlsx('训练记录.xlsx', aoa, '训练');
      showToast('已导出 训练记录.xlsx', 'ok');
    } catch (e) {
      console.error('[export training]', e);
      showToast('导出失败：' + e.message, 'err');
    }
  };

  window.exportPlan = function () {
    try {
      if (!App.plan) generateLearningPlan();
      downloadJSON('learning_plan.json', App.plan);
      showToast('已导出 learning_plan.json', 'ok');
    } catch (e) {
      console.error('[export plan]', e);
      showToast('导出失败：' + e.message, 'err');
    }
  };

  console.log('[views] 已加载');
})();