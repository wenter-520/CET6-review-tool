/* ============================================================
   charts.js — 轻量 SVG 图表渲染器（高清无失真版）
   提供：lineChart / barChart / radarChart / donutChart / miniBars / heatmap
   ============================================================ */
(function () {
  'use strict';

  const NS = 'http://www.w3.org/2000/svg';

  function svgEl(tag, attrs) {
    const el = document.createElementNS(NS, tag);
    if (attrs) for (const k in attrs) el.setAttribute(k, attrs[k]);
    return el;
  }

  function emptyState(container, msg) {
    container.innerHTML = '<div class="chart-empty">' + (msg || '暂无数据') + '</div>';
  }

  /* 关键：SVG 尺寸 = 容器实际像素尺寸，viewBox 与之一致 → 1:1 无失真 */
  function ensureSvg(container) {
    container.innerHTML = '';
    const svg = svgEl('svg', { xmlns: NS });
    svg.style.display = 'block';
    container.appendChild(svg);
    return svg;
  }

  function autoBox(container, svg) {
    const w = Math.max(200, Math.floor(container.clientWidth  || 600));
    const h = Math.max(120, Math.floor(container.clientHeight || 300));
    svg.setAttribute('width',   w);
    svg.setAttribute('height',  h);
    svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    /* 使用默认 preserveAspectRatio="xMidYMid meet"；
       由于 viewBox 与 width/height 一致，实际就是 1:1 精确映射 */
    return { w: w, h: h };
  }

  /* ============================================================
     折线图（支持多序列 + 面积填充 + 散点）
     series: [{name, color, points:[{x, y}], type:'line'|'area'|'scatter', dashed}]
     ============================================================ */
  window.renderLineChart = function (container, series, opts) {
    if (!container) return;
    opts = opts || {};
    const data = (series || []).filter(s => s.points && s.points.length);
    if (!data.length) return emptyState(container);

    const svg = ensureSvg(container);
    const { w, h } = autoBox(container, svg);
    const padL = opts.padL || 52, padR = opts.padR || 20;
    const padT = opts.padT || 26, padB = opts.padB || 36;
    const iw = w - padL - padR, ih = h - padT - padB;

    /* 范围 */
    let xMin = Infinity, xMax = -Infinity;
    let yMin = opts.yMin != null ? opts.yMin : Infinity;
    let yMax = opts.yMax != null ? opts.yMax : -Infinity;
    data.forEach(s => s.points.forEach(p => {
      if (p.x < xMin) xMin = p.x;
      if (p.x > xMax) xMax = p.x;
      if (opts.yMin == null && p.y < yMin) yMin = p.y;
      if (opts.yMax == null && p.y > yMax) yMax = p.y;
    }));
    if (xMax === xMin) xMax = xMin + 1;
    if (yMax === yMin) yMax = yMin + 1;
    if (opts.yMin == null && opts.yMax == null) yMax = yMax * 1.08;

    const sx = x => padL + (x - xMin) / (xMax - xMin) * iw;
    const sy = y => padT + ih - (y - yMin) / (yMax - yMin) * ih;

    /* 网格 */
    const yTicks = opts.yTicks || 4;
    for (let i = 0; i <= yTicks; i++) {
      const y = yMin + (yMax - yMin) * i / yTicks;
      const py = sy(y);
      svg.appendChild(svgEl('line', {
        x1: padL, y1: py, x2: padL + iw, y2: py,
        class: 'chart-grid'
      }));
      const t = svgEl('text', { x: padL - 8, y: py + 3, class: 'chart-axis-label', 'text-anchor': 'end' });
      t.textContent = opts.yFormat ? opts.yFormat(y) : Math.round(y);
      svg.appendChild(t);
    }

    /* x 轴 */
    const xStep = Math.max(1, Math.round((xMax - xMin) / (opts.xTicks || 6)));
    for (let x = xMin; x <= xMax; x += xStep) {
      const px = sx(x);
      const t = svgEl('text', { x: px, y: padT + ih + 18, class: 'chart-axis-label', 'text-anchor': 'middle' });
      t.textContent = opts.xFormat ? opts.xFormat(x) : Math.round(x);
      svg.appendChild(t);
    }

    /* 序列 */
    data.forEach(s => {
      const color = s.color || '#4a6cf7';
      if (s.type === 'area' || s.type === 'line') {
        let d = '';
        s.points.forEach((p, i) => { d += (i ? ' L ' : 'M ') + sx(p.x) + ' ' + sy(p.y); });
        if (s.type === 'area') {
          const dArea = d + ' L ' + sx(s.points[s.points.length - 1].x) + ' ' + (padT + ih) +
                        ' L ' + sx(s.points[0].x) + ' ' + (padT + ih) + ' Z';
          svg.appendChild(svgEl('path', { d: dArea, class: 'chart-area', fill: color }));
        }
        const path = svgEl('path', { d: d, class: 'chart-line', stroke: color });
        if (s.dashed) path.setAttribute('stroke-dasharray', '6 5');
        svg.appendChild(path);
      }
      if (s.type === 'scatter' || s.dots) {
        s.points.forEach(p => {
          svg.appendChild(svgEl('circle', {
            cx: sx(p.x), cy: sy(p.y), r: s.r || 4,
            fill: color, class: 'chart-dot', stroke: '#0a0f22'
          }));
        });
      }
    });

    /* 图例 */
    let lx = padL;
    const ly = 14;
    data.forEach(s => {
      if (!s.name) return;
      svg.appendChild(svgEl('rect', { x: lx, y: ly - 7, width: 14, height: 3, rx: 2, fill: s.color || '#4a6cf7' }));
      const t = svgEl('text', { x: lx + 20, y: ly, class: 'chart-legend' });
      t.textContent = s.name;
      svg.appendChild(t);
      lx += 22 + (s.name.length * 12) + 24;
    });
  };

  /* ============================================================
     柱状图
     bars: [{label, value, color}]
     ============================================================ */
  window.renderBarChart = function (container, bars, opts) {
    if (!container) return;
    opts = opts || {};
    if (!bars || !bars.length) return emptyState(container);

    const svg = ensureSvg(container);
    const { w, h } = autoBox(container, svg);
    const padL = opts.padL || 46, padR = opts.padR || 16;
    const padT = opts.padT || 26, padB = opts.padB || 40;
    const iw = w - padL - padR, ih = h - padT - padB;

    const maxV = Math.max.apply(null, bars.map(b => b.value)) || 1;
    const yMax = maxV * 1.10;

    const sy = v => padT + ih - v / yMax * ih;

    /* 网格 */
    const yTicks = 4;
    for (let i = 0; i <= yTicks; i++) {
      const v = yMax * i / yTicks;
      const py = sy(v);
      svg.appendChild(svgEl('line', { x1: padL, y1: py, x2: padL + iw, y2: py, class: 'chart-grid' }));
      const t = svgEl('text', { x: padL - 8, y: py + 3, class: 'chart-axis-label', 'text-anchor': 'end' });
      t.textContent = Math.round(v);
      svg.appendChild(t);
    }

    const bw = iw / bars.length;
    const barW = Math.min(opts.barWidth || 32, bw * 0.66);

    bars.forEach((b, i) => {
      const cx = padL + bw * (i + 0.5);
      const py = sy(b.value);
      const bh = padT + ih - py;
      svg.appendChild(svgEl('rect', {
        x: cx - barW / 2, y: py, width: barW, height: Math.max(2, bh), rx: 4,
        fill: b.color || '#4a6cf7', opacity: 0.85
      }));
      svg.appendChild(svgEl('rect', {
        x: cx - barW / 2, y: py, width: barW, height: 3, rx: 2,
        fill: b.color || '#4a6cf7'
      }));
      const tv = svgEl('text', {
        x: cx, y: py - 6, class: 'chart-axis-label', 'text-anchor': 'middle'
      });
      tv.textContent = b.value;
      if (b.value > 0) svg.appendChild(tv);
      const tl = svgEl('text', {
        x: cx, y: padT + ih + 20, class: 'chart-axis-label', 'text-anchor': 'middle'
      });
      tl.textContent = b.label;
      svg.appendChild(tl);
    });
  };

  /* ============================================================
     雷达图
     axes: [{label, value(0-100), color?}]
     ============================================================ */
  window.renderRadarChart = function (container, axes, opts) {
    if (!container) return;
    opts = opts || {};
    if (!axes || axes.length < 3) return emptyState(container);

    const svg = ensureSvg(container);
    const { w, h } = autoBox(container, svg);
    const cx = w / 2, cy = h / 2 + 6;
    const R = Math.min(w, h) * 0.34;
    const N = axes.length;

    const angle = i => -Math.PI / 2 + i * 2 * Math.PI / N;

    /* 环 */
    for (let ring = 1; ring <= 5; ring++) {
      const rr = R * ring / 5;
      let d = '';
      for (let i = 0; i < N; i++) {
        const a = angle(i);
        const x = cx + Math.cos(a) * rr;
        const y = cy + Math.sin(a) * rr;
        d += (i ? ' L ' : 'M ') + x + ' ' + y;
      }
      d += ' Z';
      svg.appendChild(svgEl('path', {
        d: d, fill: 'none',
        stroke: 'rgba(148,163,184,' + (ring === 5 ? 0.35 : 0.14) + ')',
        'stroke-width': 1
      }));
    }

    /* 轴 + 标签 */
    for (let i = 0; i < N; i++) {
      const a = angle(i);
      const x = cx + Math.cos(a) * R;
      const y = cy + Math.sin(a) * R;
      svg.appendChild(svgEl('line', {
        x1: cx, y1: cy, x2: x, y2: y,
        stroke: 'rgba(148,163,184,.2)', 'stroke-width': 1
      }));
      const lx = cx + Math.cos(a) * (R + 28);
      const ly = cy + Math.sin(a) * (R + 28);
      const t = svgEl('text', {
        x: lx, y: ly + 3, class: 'chart-axis-label',
        'text-anchor': (Math.abs(Math.cos(a)) < 0.2 ? 'middle' : (Math.cos(a) > 0 ? 'start' : 'end'))
      });
      t.textContent = axes[i].label;
      svg.appendChild(t);
    }

    /* 数据多边形 */
    let d = '';
    axes.forEach((ax, i) => {
      const a = angle(i);
      const v = Math.max(0, Math.min(100, ax.value)) / 100;
      const x = cx + Math.cos(a) * R * v;
      const y = cy + Math.sin(a) * R * v;
      d += (i ? ' L ' : 'M ') + x + ' ' + y;
    });
    d += ' Z';
    svg.appendChild(svgEl('path', {
      d: d,
      fill: 'url(#radarGrad)',
      stroke: '#8b5cf6',
      'stroke-width': 2
    }));

    /* 渐变 */
    const defs = svgEl('defs');
    const grad = svgEl('linearGradient', { id: 'radarGrad', x1: 0, y1: 0, x2: 0, y2: 1 });
    grad.appendChild(svgEl('stop', { offset: '0%', 'stop-color': 'rgba(139,92,246,.65)' }));
    grad.appendChild(svgEl('stop', { offset: '100%', 'stop-color': 'rgba(74,108,247,.25)' }));
    defs.appendChild(grad);
    svg.insertBefore(defs, svg.firstChild);

    /* 顶点 */
    axes.forEach((ax, i) => {
      const a = angle(i);
      const v = Math.max(0, Math.min(100, ax.value)) / 100;
      const x = cx + Math.cos(a) * R * v;
      const y = cy + Math.sin(a) * R * v;
      svg.appendChild(svgEl('circle', { cx: x, cy: y, r: 3.5, fill: '#a5b4fc', stroke: '#0a0f22' }));
    });
  };

  /* ============================================================
     环形图
     items: [{label, value, color}]
     ============================================================ */
  window.renderDonutChart = function (container, items, opts) {
    if (!container) return;
    opts = opts || {};
    const list = (items || []).filter(i => i.value > 0);
    if (!list.length) return emptyState(container);

    const svg = ensureSvg(container);
    const { w, h } = autoBox(container, svg);
    const cx = w * 0.36, cy = h / 2;
    const R = Math.min(w * 0.55, h) * 0.35;
    const r = R * 0.62;

    const total = list.reduce((a, b) => a + b.value, 0);
    let ang = -Math.PI / 2;

    list.forEach(item => {
      const frac = item.value / total;
      const a2 = ang + frac * Math.PI * 2;
      const large = frac > 0.5 ? 1 : 0;
      const x1 = cx + Math.cos(ang) * R, y1 = cy + Math.sin(ang) * R;
      const x2 = cx + Math.cos(a2) * R, y2 = cy + Math.sin(a2) * R;
      const x3 = cx + Math.cos(a2) * r, y3 = cy + Math.sin(a2) * r;
      const x4 = cx + Math.cos(ang) * r, y4 = cy + Math.sin(ang) * r;
      const d = 'M ' + x1 + ' ' + y1 +
        ' A ' + R + ' ' + R + ' 0 ' + large + ' 1 ' + x2 + ' ' + y2 +
        ' L ' + x3 + ' ' + y3 +
        ' A ' + r + ' ' + r + ' 0 ' + large + ' 0 ' + x4 + ' ' + y4 + ' Z';
      svg.appendChild(svgEl('path', { d: d, fill: item.color || '#4a6cf7', opacity: 0.9 }));
      ang = a2;
    });

    /* 中心数值 */
    const t1 = svgEl('text', {
      x: cx, y: cy - 4, 'text-anchor': 'middle',
      style: 'font-size:26px;font-weight:800;fill:#e0e7ff;font-family:Segoe UI'
    });
    t1.textContent = opts.centerValue != null ? opts.centerValue : total;
    svg.appendChild(t1);
    const t2 = svgEl('text', {
      x: cx, y: cy + 18, 'text-anchor': 'middle',
      style: 'font-size:11px;fill:#64748b'
    });
    t2.textContent = opts.centerLabel || '总计';
    svg.appendChild(t2);

    /* 图例 */
    const lx = w * 0.66, ly0 = cy - list.length * 13;
    list.forEach((item, i) => {
      const ly = ly0 + i * 26;
      svg.appendChild(svgEl('rect', { x: lx, y: ly - 7, width: 12, height: 12, rx: 3, fill: item.color }));
      const t = svgEl('text', {
        x: lx + 18, y: ly + 3,
        style: 'font-size:12px;fill:#cbd5e1'
      });
      const pct = (item.value / total * 100).toFixed(1);
      t.textContent = item.label + '  ' + item.value + ' (' + pct + '%)';
      svg.appendChild(t);
    });
  };

  /* ============================================================
     迷你柱状（内嵌）
     ============================================================ */
  window.renderMiniBars = function (container, bars, opts) {
    if (!container) return;
    opts = opts || {};
    const list = bars || [];
    if (!list.length) return emptyState(container);

    const svg = ensureSvg(container);
    const { w, h } = autoBox(container, svg);
    const padL = 34, padR = 12, padT = 16, padB = 26;
    const iw = w - padL - padR, ih = h - padT - padB;
    const maxV = Math.max.apply(null, list.map(b => b.value)) || 1;

    const bw = iw / list.length;
    list.forEach((b, i) => {
      const cx = padL + bw * (i + 0.5);
      const bh = (b.value / maxV) * ih;
      svg.appendChild(svgEl('rect', {
        x: cx - bw * 0.32, y: padT + ih - bh, width: bw * 0.64,
        height: Math.max(2, bh), rx: 3,
        fill: b.color || '#4a6cf7', opacity: 0.85
      }));
      const tl = svgEl('text', {
        x: cx, y: padT + ih + 16, class: 'chart-axis-label', 'text-anchor': 'middle'
      });
      tl.textContent = b.label;
      svg.appendChild(tl);
    });
  };

  /* ============================================================
     热力网格
     cells: [{x, y, v, label}]
     ============================================================ */
  window.renderHeatmap = function (container, cells, opts) {
    if (!container) return;
    const list = cells || [];
    if (!list.length) return emptyState(container);

    opts = opts || {};
    const svg = ensureSvg(container);
    const { w, h } = autoBox(container, svg);
    const padL = 36, padT = 24, padB = 26, padR = 16;
    const iw = w - padL - padR, ih = h - padT - padB;

    const maxX = Math.max.apply(null, list.map(c => c.x)) + 1;
    const maxY = Math.max.apply(null, list.map(c => c.y)) + 1;
    const cw = iw / maxX, ch = ih / maxY;
    const maxV = Math.max.apply(null, list.map(c => c.v)) || 1;

    const colorFor = v => {
      if (v <= 0) return 'rgba(148,163,184,.08)';
      const r = v / maxV;
      if (r <= 0.25) return 'rgba(74,108,247,.35)';
      if (r <= 0.5)  return 'rgba(74,108,247,.6)';
      if (r <= 0.75) return 'rgba(139,92,246,.75)';
      return 'rgba(139,92,246,1)';
    };

    list.forEach(c => {
      svg.appendChild(svgEl('rect', {
        x: padL + c.x * cw + 1, y: padT + c.y * ch + 1,
        width: cw - 2, height: ch - 2, rx: 3,
        fill: colorFor(c.v)
      }));
    });

    /* y 轴标签 */
    const yLabels = opts.yLabels || [];
    yLabels.forEach((lab, i) => {
      const t = svgEl('text', {
        x: padL - 6, y: padT + i * ch + ch / 2 + 3,
        class: 'chart-axis-label', 'text-anchor': 'end'
      });
      t.textContent = lab;
      svg.appendChild(t);
    });
    /* x 轴标签 */
    const xLabels = opts.xLabels || [];
    xLabels.forEach((lab, i) => {
      if (i % Math.max(1, Math.ceil(xLabels.length / 8)) !== 0) return;
      const t = svgEl('text', {
        x: padL + i * cw + cw / 2, y: padT + ih + 16,
        class: 'chart-axis-label', 'text-anchor': 'middle'
      });
      t.textContent = lab;
      svg.appendChild(t);
    });
  };

  console.log('[charts] 已加载');
})();