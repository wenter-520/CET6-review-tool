/* ============================================================
   store.js — 词库目录 / IndexedDB / 三方合并 / 自动写文件
   ============================================================ */
(function () {
  'use strict';

  /* ============================================================
     Store —— 词库目录探测
     ============================================================ */
  window.Store = {
    base: null,
    files: [],
    mode: 'http',

    async init() {
      const candidates = [
        new URL('../', location.href),
        new URL('./', location.href)
      ];
      for (let i = 0; i < candidates.length; i++) {
        const files = await this._probe(candidates[i]);
        if (files) {
          this.base = candidates[i];
          this.files = files;
          return true;
        }
      }
      return false;
    },

    async _probe(url) {
      try {
        const r = await fetch(url.href, { cache: 'no-store' });
        if (r.ok) {
          const html = await r.text();
          const files = parseDirLinks(html);
          if (files.length && files.some(f => /\.xlsx$/i.test(f))) return files;
        }
      } catch (e) { /* ignore */ }
      try {
        const r2 = await fetch(new URL(AUX_SYNONYMS, url).href, { cache: 'no-store' });
        if (r2.ok) return [AUX_SYNONYMS];
      } catch (e) { /* ignore */ }
      try {
        const r3 = await fetch(new URL(AUX_TYPO_HINTS, url).href, { cache: 'no-store' });
        if (r3.ok) return [AUX_TYPO_HINTS];
      } catch (e) { /* ignore */ }
      return null;
    },

    url(name) { return new URL(name, this.base).href; },
    async readText(name) {
      const r = await fetch(this.url(name), { cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    },
    async readJSON(name) {
      try { return JSON.parse(await this.readText(name)); }
      catch (e) { return null; }
    },
    async readBuffer(name) {
      const r = await fetch(this.url(name), { cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.arrayBuffer();
    },
    listStudyXlsx() {
      const out = [];
      for (let i = 0; i < this.files.length; i++) {
        const f = this.files[i];
        const lf = f.toLowerCase();
        if (!lf.endsWith('.xlsx')) continue;
        if (lf.indexOf('~$') === 0) continue;
        let excluded = false;
        for (let e = 0; e < EXPORT_NAMES.length; e++) {
          if (f.indexOf(EXPORT_NAMES[e]) >= 0) { excluded = true; break; }
        }
        if (excluded) continue;
        out.push(f);
      }
      return out;
    }
  };

  window.parseDirLinks = function (html) {
    const out = [];
    if (!html) return out;
    const re = /<a\s+[^>]*href\s*=\s*["']([^"']+)["']/gi;
    let m;
    while ((m = re.exec(html))) {
      let href = m[1];
      if (!href) continue;
      if (href.charAt(0) === '?' || href.charAt(0) === '#' || href.charAt(0) === '/') continue;
      if (href.indexOf('://') !== -1) continue;
      if (href.slice(-1) === '/') continue;
      let name = href.split('?')[0].split('#')[0];
      try { name = decodeURIComponent(name); } catch (e) {}
      if (name && out.indexOf(name) < 0) out.push(name);
    }
    return out;
  };

  /* ============================================================
     IndexedDB
     ============================================================ */
  const IDB_NAME = 'cet6-vocab-db';
  const IDB_STORE = 'userdata';

  function idbOpen() {
    return new Promise((res, rej) => {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = function () {
        const db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
      };
      req.onsuccess = () => res(req.result);
      req.onerror = () => rej(req.error);
    });
  }
  window.idbOpen = idbOpen;

  window.idbGet = function (key) {
    return idbOpen().then(db => new Promise((res, rej) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const r = tx.objectStore(IDB_STORE).get(key);
      r.onsuccess = () => res(r.result == null ? null : r.result);
      r.onerror = () => rej(r.error);
    }));
  };
  window.idbSet = function (key, val) {
    return idbOpen().then(db => new Promise((res, rej) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put(val, key);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    }));
  };
  window.idbDel = function (key) {
    return idbOpen().then(db => new Promise((res, rej) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).delete(key);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    }));
  };

  let writeChain = Promise.resolve();
  window.enqueueWrite = function (fn) {
    writeChain = writeChain.then(fn).catch(e => {
      console.error('[write]', e);
      setSavingState('saving', '⚠ 保存失败');
    });
    return writeChain;
  };

  /* ============================================================
     快照工具（被 filesync.js 调用）
     ============================================================ */
  window.snapshotStates = function () {
    const out = {};
    const src = App.states || {};
    for (const k in src) {
      if (!Object.prototype.hasOwnProperty.call(src, k)) continue;
      const s = src[k];
      if (!s.reviews && !s.last_rating && !s.due) continue;
      out[k] = {
        stage: s.stage || 0,
        reviews: s.reviews || 0,
        wrong: s.wrong || 0,
        confuse: s.confuse || 0,
        due: s.due || null,
        last_review: s.last_review || null,
        last_rating: s.last_rating || null,
        known: !!s.known
      };
    }
    return out;
  };

  /* ============================================================
     合并工具
     ============================================================ */
  function isNonEmptyObj(o) {
    if (!o || typeof o !== 'object') return false;
    for (const k in o) if (Object.prototype.hasOwnProperty.call(o, k)) return true;
    return false;
  }

  /* states 合并：多源，逐 key 取 reviews 更多的 */
  function mergeStates() {
    const out = {};
    for (let i = 0; i < arguments.length; i++) {
      const src = arguments[i];
      if (!src) continue;
      for (const k in src) {
        if (!Object.prototype.hasOwnProperty.call(src, k)) continue;
        const a = out[k], b = src[k];
        if (!a) { out[k] = b; continue; }
        if (!b) continue;
        out[k] = (a.reviews || 0) >= (b.reviews || 0) ? a : b;
      }
    }
    return out;
  }

  /* sessions 合并：多源，按日期合并 */
  function mergeSessions() {
    const out = {};
    for (let i = 0; i < arguments.length; i++) {
      const src = arguments[i];
      if (!src) continue;
      for (const d in src) {
        if (!Object.prototype.hasOwnProperty.call(src, d)) continue;
        const a = out[d], b = src[d];
        if (!a) { out[d] = b; continue; }
        if (!b) continue;
        const aN = (a.sessions || []).length;
        const bN = (b.sessions || []).length;
        if (aN !== bN) out[d] = aN > bN ? a : b;
        else out[d] = (a.updated_at || '') >= (b.updated_at || '') ? a : b;
      }
    }
    return out;
  }

  /* training 合并：按日期追加，按 session_id 去重 */
  function mergeTraining() {
    const out = {};
    for (let i = 0; i < arguments.length; i++) {
      const src = arguments[i];
      if (!src) continue;
      for (const d in src) {
        if (!Object.prototype.hasOwnProperty.call(src, d)) continue;
        if (!out[d]) out[d] = [];
        const seen = {};
        for (const x of out[d]) if (x.session_id) seen[x.session_id] = 1;
        for (const x of (src[d] || [])) {
          if (!x.session_id || !seen[x.session_id]) out[d].push(x);
        }
      }
    }
    return out;
  }

  /* ============================================================
     加载用户数据 —— 三方合并
     优先级：FileSystem 目录 > .userdata/ 静态目录 > IndexedDB
     实际是"取并集"：任何一边独有的内容都不丢失
     ============================================================ */
  window.loadUserdata = async function () {
    /* ---------- 1) FileSystem 目录（如果已绑定） ---------- */
    let fsData = null;
    if (typeof FileSync !== 'undefined' && FileSync.dirHandle) {
      try {
        fsData = await FileSync.readAll();
        console.log('[loadUserdata] 目录已绑定，读取到：',
          fsData ? (Object.keys(fsData.sessions || {}).length + ' 天会话') : '空');
      } catch (e) {
        console.warn('[loadUserdata] 目录读取失败：', e);
      }
    }

    /* ---------- 2) .userdata/ 老路径（HTTP 静态目录） ---------- */
    let fileStates = null, fileMeta = null, fileSettings = null, fileSessions = {};
    try {
      try { fileStates = await Store.readJSON('.userdata/states.json'); } catch (e) {}
      try { fileMeta = await Store.readJSON('.userdata/meta.json'); } catch (e) {}
      try { fileSettings = await Store.readJSON('.userdata/settings.json'); } catch (e) {}
      try {
        const sessBase = new URL('.userdata/sessions/', Store.base);
        const listResp = await fetch(sessBase.href, { cache: 'no-store' });
        if (listResp.ok) {
          const names = parseDirLinks(await listResp.text()).filter(f => f.endsWith('.json'));
          for (const n of names) {
            try {
              const data = await Store.readJSON('.userdata/sessions/' + n);
              if (data && data.sessions) fileSessions[n.replace(/\.json$/i, '')] = data;
            } catch (e) {}
          }
        }
      } catch (e) {}
    } catch (e) {
      console.warn('[loadUserdata] .userdata/ 读取异常：', e);
    }

    /* ---------- 3) IndexedDB ---------- */
    const idbStates   = (await idbGet('states'))   || {};
    const idbSessions = (await idbGet('sessions')) || {};
    const idbMeta     = (await idbGet('meta'))     || { vocabSnapshot: {}, lastLoaded: null };
    const idbSettings = (await idbGet('settings')) || {};
    const idbTraining = (await idbGet('training')) || {};
    const idbMastery  = (await idbGet('mastery'))  || {};
    const idbPlan     = (await idbGet('plan'))     || null;

    /* ---------- 4) 合并 ---------- */
    const mergedStates = mergeStates(
      idbStates,
      fileStates,
      fsData && fsData.states
    );
    const mergedSessions = mergeSessions(
      idbSessions,
      fileSessions,
      fsData && fsData.sessions
    );
    const mergedTraining = mergeTraining(
      idbTraining,
      fsData && fsData.training
    );
    const mergedMeta = Object.assign(
      { vocabSnapshot: {}, lastLoaded: null },
      idbMeta || {},
      fileMeta || {},
      (fsData && fsData.meta) || {}
    );
    const mergedSettings = Object.assign(
      {},
      DEFAULT_SETTINGS,
      idbSettings || {},
      fileSettings || {},
      (fsData && fsData.settings) || {}
    );
    const mergedMastery = Object.assign(
      {},
      idbMastery || {},
      (fsData && fsData.mastery) || {}
    );
    const mergedPlan = idbPlan || (fsData && fsData.plan) || null;

    App.states   = mergedStates;
    App.sessions = mergedSessions;
    App.meta     = mergedMeta;
    App.settings = mergedSettings;
    App.training = mergedTraining;
    App.mastery  = mergedMastery;
    App.plan     = mergedPlan;

    /* ---------- 5) 回写 IndexedDB ---------- */
    try {
      if (Object.keys(mergedStates).length > 0)   await idbSet('states', mergedStates);
      if (Object.keys(mergedSessions).length > 0) await idbSet('sessions', mergedSessions);
      if (Object.keys(mergedTraining).length > 0) await idbSet('training', mergedTraining);
      await idbSet('meta', mergedMeta);
      await idbSet('settings', mergedSettings);
      if (Object.keys(mergedMastery).length > 0)  await idbSet('mastery', mergedMastery);
      if (mergedPlan) await idbSet('plan', mergedPlan);
    } catch (e) {
      console.warn('[loadUserdata] 回写 IDB 失败：', e);
    }

    /* ---------- 6) 提示 ---------- */
    const hasFs    = !!(fsData && (Object.keys(fsData.states || {}).length || Object.keys(fsData.sessions || {}).length));
    const hasFiles = !!(isNonEmptyObj(fileStates) || Object.keys(fileSessions).length);

    if (hasFs) {
      showToast('已从绑定目录合并：' +
        Object.keys(mergedSessions).length + ' 天会话，' +
        Object.keys(mergedStates).length + ' 条状态', 'ok');
    } else if (hasFiles) {
      showToast('已从 .userdata/ 合并：' +
        Object.keys(mergedSessions).length + ' 天会话，' +
        Object.keys(mergedStates).length + ' 条状态', 'ok');
    }

    /* ---------- 7) 如果绑定了目录，把合并结果写回（保证文件是最新的） ---------- */
    if (FileSync && FileSync.dirHandle && hasFs) {
      /* 只有在文件确实比浏览器旧时才需要回写；这里简单粗暴：始终写一次 */
      setTimeout(() => { FileSync.writeAll(); }, 500);
    }

    return mergedStates;
  };

  /* ============================================================
     保存函数 —— 同时写 IndexedDB（双保险）和磁盘文件（主存储）
     ============================================================ */

  window.saveStates = async function () {
    setSavingState('saving', '保存中…');
    await enqueueWrite(async () => {
      await idbSet('states', window.snapshotStates());
    });
    if (typeof FileSync !== 'undefined' && FileSync.dirHandle) {
      FileSync.markDirty('states');
    }
    setSavingState('saved', FileSync && FileSync.dirHandle ? '✓ 已保存（文件+浏览器）' : '✓ 已保存');
  };

  window.saveSession = async function (date, session) {
    App.sessions[date] = session;
    await enqueueWrite(async () => { await idbSet('sessions', App.sessions); });
    if (typeof FileSync !== 'undefined' && FileSync.dirHandle) {
      FileSync.markDirty('session', date);
    }
  };

  window.saveMeta = async function () {
    await enqueueWrite(async () => { await idbSet('meta', App.meta); });
    if (typeof FileSync !== 'undefined' && FileSync.dirHandle) FileSync.markDirty('meta');
  };
  window.saveSettings = async function () {
    await enqueueWrite(async () => { await idbSet('settings', App.settings); });
    if (typeof FileSync !== 'undefined' && FileSync.dirHandle) FileSync.markDirty('settings');
  };
  window.saveTraining = async function () {
    await enqueueWrite(async () => { await idbSet('training', App.training); });
    if (typeof FileSync !== 'undefined' && FileSync.dirHandle) FileSync.markDirty('training');
  };
  window.saveMastery = async function () {
    await enqueueWrite(async () => { await idbSet('mastery', App.mastery); });
    if (typeof FileSync !== 'undefined' && FileSync.dirHandle) FileSync.markDirty('mastery');
  };
  window.savePlan = async function () {
    await enqueueWrite(async () => { await idbSet('plan', App.plan); });
    if (typeof FileSync !== 'undefined' && FileSync.dirHandle) FileSync.markDirty('plan');
  };

  /* ============================================================
     辅助数据
     ============================================================ */
  window.loadAuxData = async function () {
    const syn   = await Store.readJSON(AUX_SYNONYMS);
    const typo  = await Store.readJSON(AUX_TYPO_HINTS);
    const collo = await Store.readJSON(AUX_COLLOCATIONS);
    const plan  = await Store.readJSON(AUX_PLAN);

    App.synonyms     = (syn && typeof syn === 'object' && !Array.isArray(syn)) ? syn : {};
    App.typoHints    = (typo && typeof typo === 'object' && !Array.isArray(typo)) ? typo : (deepClone(SEED_TYPO_HINTS) || {});
    App.collocations = (collo && typeof collo === 'object' && !Array.isArray(collo)) ? collo : {};
    if (plan && typeof plan === 'object' && !App.plan) App.plan = plan;

    return { syn: App.synonyms, typo: App.typoHints, collocations: App.collocations };
  };

  /* ============================================================
     学习文件解析
     ============================================================ */
  window.parseStudyWorkbook = function (fileName, wb) {
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    let day = parseDayLabel(fileName);
    let group = '';
    const words = [], typos = [];

    const cw = App.settings.colWord != null ? App.settings.colWord : 0;
    const cm = App.settings.colMeaning != null ? App.settings.colMeaning : 1;
    const ct = App.settings.colTag != null ? App.settings.colTag : 2;

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const a = String(row[cw] != null ? row[cw] : '').trim();
      const b = String(row[cm] != null ? row[cm] : '').trim();
      const c = String(row[ct] != null ? row[ct] : '').trim();
      if (!a) continue;
      if (a.indexOf('日期') === 0) {
        const d = parseDayLabel(c) || parseDayLabel(a);
        if (d != null) day = d;
        continue;
      }
      const ng = normalizeGroup(a);
      if (GROUP_ORDER.indexOf(ng) >= 0) { group = ng; continue; }
      if (!isValidWord(a)) continue;
      if (day == null) continue;
      const sug = detectTypo(a);
      if (sug) typos.push([a, sug]);
      words.push({ text: a, meaning: b, tags: c ? [c] : [], day: day, group: group, source: fileName });
    }
    return { day: day, words: words, typos: typos };
  };

  /* ============================================================
     词库加载
     ============================================================ */
  window.loadLibrary = async function () {
    let xlsxFiles = Store.listStudyXlsx();
    if (App.settings.libPrefix) {
      const prefix = App.settings.libPrefix.toLowerCase();
      xlsxFiles = xlsxFiles.filter(f => f.toLowerCase().indexOf(prefix) === 0);
    }
    xlsxFiles.sort((a, b) => {
      let da = parseDayLabel(a); if (da == null) da = 999;
      let db = parseDayLabel(b); if (db == null) db = 999;
      return da - db || a.localeCompare(b);
    });

    const library = {}, days = {}, skipped = [], typos = [];
    const byGroup = {}, byGroupDay = {};

    for (let i = 0; i < xlsxFiles.length; i++) {
      const name = xlsxFiles[i];
      try {
        const buf = await Store.readBuffer(name);
        const wb = XLSX.read(buf, { type: 'array' });
        const r = parseStudyWorkbook(name, wb);
        if (r.day == null) { skipped.push({ name: name, why: '无法识别天号' }); continue; }
        if (!r.words.length) { skipped.push({ name: name, why: '未解析到单词行' }); continue; }

        for (let t = 0; t < r.typos.length; t++) typos.push([name, r.typos[t][0], r.typos[t][1]]);

        for (let k = 0; k < r.words.length; k++) {
          const w = r.words[k];
          const key = w.text.trim().toLowerCase();
          if (!key) continue;
          if (key in library) {
            const o = library[key];
            if (!o.meaning && w.meaning) o.meaning = w.meaning;
            for (let tt = 0; tt < w.tags.length; tt++) if (o.tags.indexOf(w.tags[tt]) < 0) o.tags.push(w.tags[tt]);
            if (!o.group && w.group) o.group = w.group;
          } else {
            library[key] = w;
          }
          if (w.day) {
            if (!days[w.day]) days[w.day] = [];
            if (days[w.day].indexOf(key) < 0) days[w.day].push(key);
          }
          const g = normalizeGroup(w.group) || '未分组';
          byGroup[g] = (byGroup[g] || 0) + 1;
          if (w.day) {
            if (!byGroupDay[g]) byGroupDay[g] = {};
            byGroupDay[g][w.day] = (byGroupDay[g][w.day] || 0) + 1;
          }
        }
      } catch (e) {
        skipped.push({ name: name, why: '解析异常：' + e.message });
      }
    }

    return {
      library: library, days: days, skipped: skipped, typos: typos,
      byGroup: byGroup, byGroupDay: byGroupDay, studyFiles: xlsxFiles
    };
  };

  console.log('[store] 已加载（三方合并 + 目录自动写）');
})();