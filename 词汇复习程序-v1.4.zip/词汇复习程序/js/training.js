/* ============================================================
   training.js — 深度训练营
   题型：拼写重构 / 词义辨析 / 反向回忆 / 形近对抗
   ============================================================ */
(function () {
  'use strict';

  const MODES = [
    { id: 'spelling',  label: '拼写重构' },
    { id: 'meaning',   label: '词义辨析' },
    { id: 'reverse',   label: '反向回忆' },
    { id: 'contrast',  label: '形近对抗' }
  ];

  /* ---------- 工具 ---------- */
  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }
  function scramble(word) {
    const letters = word.split('');
    let out = shuffle(letters).join('');
    if (out === word && word.length > 2) out = scramble(word);
    return out;
  }
  function pickRandom(arr, n, exclude) {
    const pool = arr.filter(x => x !== exclude);
    return shuffle(pool).slice(0, n);
  }

  /* ---------- 抽取候选词 ---------- */
  function collectCandidates(scope) {
    const keys = Object.keys(App.library);
    let pool;
    if (scope === 'hard') {
      pool = keys.filter(k => starOf(k) <= 2);
    } else if (scope === 'weak') {
      pool = keys.filter(isWeakGlobal);
    } else if (scope === 'today') {
      const day = App.selectedDay;
      if (day === 'all') pool = keys.slice();
      else pool = (App.days[day] || []).slice();
    } else {
      pool = keys.slice();
    }
    if (!pool.length) pool = keys.slice();
    return pool;
  }

  /* ---------- 生成题目 ---------- */
  function genQuestion(mode, key) {
    const w = App.library[key];
    const allKeys = Object.keys(App.library);

    if (mode === 'spelling') {
      const letters = scramble(w.text);
      return {
        type: 'spelling',
        key: key,
        prompt: '根据释义拼写单词',
        meaning: w.meaning || '（无释义）',
        scramble: letters,
        answer: w.text.toLowerCase()
      };
    }

    if (mode === 'meaning') {
      const wrongs = pickRandom(
        allKeys.filter(k => k !== key && App.library[k].meaning),
        3, key
      ).map(k => App.library[k].meaning);
      const options = shuffle([w.meaning || '（无释义）'].concat(wrongs));
      return {
        type: 'meaning',
        key: key,
        prompt: '选择正确释义',
        word: w.text,
        options: options,
        answer: w.meaning || '（无释义）'
      };
    }

    if (mode === 'reverse') {
      const wrongs = pickRandom(allKeys.filter(k => k !== key), 3, key)
        .map(k => App.library[k].text);
      const options = shuffle([w.text].concat(wrongs));
      return {
        type: 'reverse',
        key: key,
        prompt: '根据释义选择正确单词',
        meaning: w.meaning || '（无释义）',
        options: options,
        answer: w.text
      };
    }

    /* contrast —— 形近对抗 */
    const rel = App.relations[key] || { syn: [], form: [] };
    let pool = rel.form.length ? rel.form.slice() : [];
    if (pool.length < 1) {
      /* 退化成反向回忆 */
      const wrongs = pickRandom(allKeys.filter(k => k !== key), 3, key)
        .map(k => App.library[k].text);
      const options = shuffle([w.text].concat(wrongs));
      return {
        type: 'reverse',
        key: key,
        prompt: '根据释义选择正确单词',
        meaning: w.meaning || '（无释义）',
        options: options,
        answer: w.text
      };
    }
    const picks = shuffle(pool).slice(0, 3);
    const options = shuffle([w.text].concat(picks.map(k => App.library[k].text)));
    return {
      type: 'contrast',
      key: key,
      prompt: '选择与释义匹配的单词',
      meaning: w.meaning || '（无释义）',
      options: options,
      answer: w.text
    };
  }

  /* ---------- 开始训练 ---------- */
  window.startTraining = function () {
    /* 防止覆盖正在进行的训练 */
    if (App.trainSession) {
      if (!confirm('当前有训练正在进行，是否放弃并开始新训练？')) return;
      App.trainSession = null;
      el('trainStageCard').style.display = 'none';
      el('trainBody').innerHTML = '';
      el('trainActions').innerHTML = '';
    }

    const mode = el('trainMode').value;
    const batch = parseInt(el('trainBatch').value, 10) || App.settings.trainBatch || 12;
    const scope = el('trainScope').value;

    const pool = collectCandidates(scope);
    if (!pool.length) { showToast('当前范围没有可训练的词', 'warn'); return; }

    const selected = shuffle(pool).slice(0, Math.min(batch, pool.length));

    App.trainSession = {
      session_id: uid(),
      started_at: nowISO(),
      mode: mode,
      scope: scope,
      batch: batch,
      queue: selected.slice(),
      idx: 0,
      total: selected.length,
      correct: 0,
      wrong: 0,
      results: [],
      current: null,
      answered: false,
      lastCorrect: false,
      reinsertedCount: 0,
      pendingRetry: []           /* 需要回炉的 key */
    };

    el('trainStageCard').style.display = '';
    renderTrainingQuestion();
    showToast('训练开始：' + selected.length + ' 题', 'ok');
  };

  /* ---------- 渲染当前题目 ---------- */
  window.renderTrainingQuestion = function () {
    const s = App.trainSession;
    if (!s) return;
    if (s.idx >= s.queue.length) { finishTraining(); return; }

    const key = s.queue[s.idx];
    const w = App.library[key];
    if (!w) { s.idx++; return renderTrainingQuestion(); }

    const q = genQuestion(s.mode, key);
    s.current = q;
    s.answered = false;

    const total = s.total, done = s.idx;
    el('trainProgFill').style.width = (total ? done / total * 100 : 0) + '%';
    el('trainProgLabel').textContent = (done + 1) + ' / ' + total;
    el('trainScoreLabel').innerHTML = '✓ <b>' + s.correct + '</b>　✗ <b style="color:var(--bad)">' + s.wrong + '</b>';

    const box = el('trainBody');
    let html = '';

    if (q.type === 'spelling') {
      html =
        '<div class="tq-prompt">' + esc(q.prompt) + '</div>' +
        '<div class="tq-mean">' + esc(q.meaning) + '</div>' +
        '<div class="tq-scramble">' + esc(q.scramble.toUpperCase()) + '</div>' +
        '<input type="text" class="tq-input" id="trainInput" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="输入单词后按 Enter">';
    } else if (q.type === 'meaning') {
      html =
        '<div class="tq-prompt">' + esc(q.prompt) + '</div>' +
        '<div class="tq-word">' + esc(q.word) + '</div>' +
        '<div class="tq-options">' +
        q.options.map((o, i) => '<button class="tq-opt" data-opt="' + i + '">' + esc(o) + '</button>').join('') +
        '</div>';
    } else if (q.type === 'reverse') {
      html =
        '<div class="tq-prompt">' + esc(q.prompt) + '</div>' +
        '<div class="tq-mean">' + esc(q.meaning) + '</div>' +
        '<div class="tq-options">' +
        q.options.map((o, i) => '<button class="tq-opt" data-opt="' + i + '">' + esc(o) + '</button>').join('') +
        '</div>';
    } else if (q.type === 'contrast') {
      html =
        '<div class="tq-prompt">' + esc(q.prompt) + '</div>' +
        '<div class="tq-mean">' + esc(q.meaning) + '</div>' +
        '<div class="tq-options">' +
        q.options.map((o, i) => '<button class="tq-opt" data-opt="' + i + '">' + esc(o) + '</button>').join('') +
        '</div>';
    }

    box.innerHTML = html + '<div class="train-feedback" id="trainFeedback"></div>';

    const actions = el('trainActions');
    actions.innerHTML = '';

    if (q.type === 'spelling') {
      const inp = el('trainInput');
      if (inp) { inp.focus(); inp.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); submitTrainingAnswer(inp.value); }
      }); }
    } else {
      qsa('.tq-opt', box).forEach(btn => {
        btn.addEventListener('click', () => {
          if (s.answered) return;
          submitTrainingAnswer(q.options[parseInt(btn.dataset.opt, 10)]);
        });
      });
    }
  };

  /* ---------- 判定答案 ---------- */
  window.submitTrainingAnswer = function (input) {
    const s = App.trainSession;
    if (!s || s.answered || !s.current) return;
    const q = s.current;

    const raw = String(input || '').trim();
    if (!raw) return;

    let correct = false;
    if (q.type === 'spelling') {
      correct = raw.toLowerCase() === q.answer.toLowerCase();
    } else {
      correct = raw === q.answer;
    }

    s.answered = true;
    s.lastCorrect = correct;
    if (correct) s.correct++; else s.wrong++;

    /* 记入历史 */
    s.results.push({
      key: q.key, type: q.type, correct: correct,
      input: raw, expected: q.answer, ts: nowISO()
    });

    /* UI 反馈 */
    const fb = el('trainFeedback');
    if (fb) {
      fb.className = 'train-feedback ' + (correct ? 'ok' : 'bad');
      fb.textContent = correct ? '✓ 正确！' : '✗ 正确答案：' + q.answer;
    }

    if (q.type === 'spelling') {
      const inp = el('trainInput');
      if (inp) { inp.classList.add(correct ? 'ok' : 'bad'); inp.disabled = true; }
    } else {
      qsa('.tq-opt', el('trainBody')).forEach(btn => {
        const txt = btn.textContent;
        if (txt === q.answer) btn.classList.add('correct');
        else if (txt === raw && !correct) btn.classList.add('wrong');
      });
    }

    /* 写回复习曲线 —— 等价于一次「熟悉 / 陌生」评分 */
    const k = q.key;
    if (App.states[k]) {
      const rating = correct ? '熟悉' : '陌生';
      const elapsed = 4000 + Math.floor(Math.random() * 4000);
      applyRating(App.states[k], rating, todayStr(), elapsed);

      /* 记录到当天 sessions */
      const today = todayStr();
      if (!App.sessions[today]) App.sessions[today] = { date: today, sessions: [], updated_at: nowISO() };
      const list = App.sessions[today].sessions;
      let rec = list.find(x => x.session_id === s.session_id);
      if (!rec) {
        rec = {
          session_id: s.session_id, started_at: s.started_at, mode: 'training',
          finished: false, total_planned: s.total, answered: 0,
          summary: { 熟悉: 0, 模糊: 0, 陌生: 0, 混淆: 0 }, reviews: []
        };
        list.push(rec);
      }
      rec.updated_at = nowISO();
      rec.answered = s.results.length;
      rec.summary[rating] = (rec.summary[rating] || 0) + 1;
      rec.reviews.push({
        word: App.library[k].text, key: k, rating: rating,
        ts: nowISO(), day: App.library[k].day, group: App.library[k].group, elapsed_ms: elapsed,
        source: 'training'
      });
      App.sessions[today].updated_at = nowISO();
      saveStates();
      saveSession(today, App.sessions[today]);

      /* 刷新掌握度 */
      const m = computeScore(k);
      if (m) App.mastery[k] = m;
    }

    /* 答错 → 稍后回炉重练一次 */
    if (!correct) {
      s.pendingRetry.push(k);
    }

    /* 按钮 */
    const actions = el('trainActions');
    actions.innerHTML = '';
    const next = document.createElement('button');
    next.className = 'btn btn-primary';
    next.textContent = (s.idx + 1 >= s.queue.length && !s.pendingRetry.length) ? '完成训练' : '下一题 ▶';
    next.onclick = advanceTraining;
    actions.appendChild(next);

    /* 更新顶部计数 */
    el('trainScoreLabel').innerHTML = '✓ <b>' + s.correct + '</b>　✗ <b style="color:var(--bad)">' + s.wrong + '</b>';
  };

  function advanceTraining() {
    const s = App.trainSession;
    if (!s) return;
    s.idx++;
    if (s.idx >= s.queue.length) {
      /* 回炉：把错误词再练一轮 */
      if (s.pendingRetry.length) {
        s.queue = s.pendingRetry.slice();
        s.pendingRetry = [];
        s.idx = 0;
        s.reinsertedCount++;
        showToast('回炉重练：' + s.queue.length + ' 题', 'warn');
      } else {
        finishTraining();
        return;
      }
    }
    renderTrainingQuestion();
  }

  /* ---------- 结束训练 ---------- */
  window.finishTraining = async function () {
    const s = App.trainSession;
    if (!s) return;
    const acc = s.results.length ? (s.correct / s.results.length * 100) : 0;

    /* 写入训练历史 */
    const today = todayStr();
    if (!App.training[today]) App.training[today] = [];
    App.training[today].push({
      session_id: s.session_id,
      started_at: s.started_at,
      ended_at: nowISO(),
      mode: s.mode,
      scope: s.scope,
      total: s.total,
      correct: s.correct,
      wrong: s.wrong,
      accuracy: acc,
      reinserted: s.reinsertedCount,
      results: s.results
    });

    await saveTraining();
    refreshMastery();

    el('trainStageCard').style.display = 'none';
    el('trainBody').innerHTML = '';
    el('trainActions').innerHTML = '';
    App.trainSession = null;

    renderTrainingHistory();
    updateHeader();
    updatePoolBar();
    renderBrowse();
    renderStats();
    showToast('训练结束：正确率 ' + acc.toFixed(1) + '%', acc >= 80 ? 'ok' : (acc >= 60 ? '' : 'warn'));
  };

  /* ---------- 训练历史 ---------- */
  window.renderTrainingHistory = function () {
    const box = el('trainHistory');
    if (!box) return;
    const dates = Object.keys(App.training).sort().reverse();
    if (!dates.length) {
      box.innerHTML = '<div class="muted">还没有训练记录，去「深度训练」开一局吧</div>';
      return;
    }
    const html = dates.slice(0, 14).map(d => {
      const list = App.training[d] || [];
      const rows = list.map(t => {
        const modeLabel = (MODES.find(m => m.id === t.mode) || { label: t.mode }).label;
        const color = t.accuracy >= 80 ? 'var(--ok)' : (t.accuracy >= 60 ? 'var(--warn)' : 'var(--bad)');
        return '<div class="dp-item">' +
          '<div class="dp-name" style="width:80px">' + d.slice(5) + '</div>' +
          '<div class="dp-bar"><i style="width:' + t.accuracy.toFixed(1) + '%;background:' + color + '"></i></div>' +
          '<div class="dp-nums">' + modeLabel + ' ｜ ' + t.correct + '/' + t.total +
            ' ｜ 正确率 <b style="color:' + color + '">' + t.accuracy.toFixed(1) + '%</b>' +
            (t.reinserted ? ' ｜ 回炉 ' + t.reinserted + ' 轮' : '') +
          '</div>' +
        '</div>';
      }).join('');
      return '<div style="margin:6px 0 10px"><b>' + d + '</b>' + rows + '</div>';
    }).join('');
    box.innerHTML = html;
  };

  /* ---------- 初始化下拉框 ---------- */
  window.initTrainingUI = function () {
    const modeSel = el('trainMode');
    if (modeSel && !modeSel.options.length) {
      MODES.forEach(m => {
        const o = document.createElement('option');
        o.value = m.id; o.textContent = m.label;
        modeSel.appendChild(o);
      });
    }
    if (el('trainBatch')) el('trainBatch').value = String(App.settings.trainBatch || 12);
  };

  window.TRAIN_MODES = MODES;
  console.log('[training] 已加载');
})();