/* ============================================================
   analytics.js — 统计分析 / 六维能力 / 遗忘曲线 / 学习计划
   ============================================================ */
(function () {
  'use strict';

  /* ---------- 基础统计 ---------- */
  window.allSessionsFlat = function () {
    const out = [];
    for (const date in App.sessions) {
      if (!App.sessions.hasOwnProperty(date)) continue;
      const sess = App.sessions[date].sessions || [];
      for (let i = 0; i < sess.length; i++) out.push([date, sess[i]]);
    }
    return out;
  };

  window.computeStats = function () {
    let sess = 0, ans = 0;
    const byR = {}, byD = {};
    const all = allSessionsFlat();
    for (let i = 0; i < all.length; i++) {
      sess++;
      const rev = all[i][1].reviews || [];
      ans += rev.length;
      const d = all[i][0];
      byD[d] = (byD[d] || 0) + rev.length;
      for (let j = 0; j < rev.length; j++) {
        const r = rev[j].rating;
        byR[r] = (byR[r] || 0) + 1;
      }
    }
    return { sessions: sess, answers: ans, byRating: byR, byDate: byD };
  };

  /* ---------- 六维能力 ---------- */
  window.computeSixDim = function () {
    const keys = Object.keys(App.library);
    const total = keys.length || 1;

    /* 1. 记忆保持（平均保持率） */
    let retSum = 0, retN = 0;
    /* 2. 反应速度（平均秒数的反向） */
    let msSum = 0, msN = 0;
    /* 3. 准确率（熟悉+模糊 / 总复习） */
    let accHit = 0, accTot = 0;
    /* 4. 稳定性（stage≥4 比例） */
    let stableN = 0;
    /* 5. 覆盖广度（有记录的词 / 全部） */
    let coveredN = 0;
    /* 6. 深度掌握（平均 stage / 9） */
    let stageSum = 0;

    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      const st = App.states[k] || {};
      const m = App.mastery[k];
      if (st.reviews > 0) coveredN++;
      if ((st.stage || 0) >= 4) stableN++;
      stageSum += (st.stage || 0);
      if (m && st.reviews) { retSum += m.retention; retN++; }
    }

    const all = allSessionsFlat();
    for (let i = 0; i < all.length; i++) {
      const rev = all[i][1].reviews || [];
      for (let j = 0; j < rev.length; j++) {
        accTot++;
        const r = rev[j].rating;
        if (r === '熟悉' || r === '模糊') accHit++;
        if (rev[j].elapsed_ms) { msSum += rev[j].elapsed_ms; msN++; }
      }
    }

    const avgRet = retN ? retSum / retN : 0;
    const avgSec = msN ? msSum / msN / 1000 : 6;
    const accuracy = accTot ? accHit / accTot : 0;
    const stability = stableN / total;
    const coverage = coveredN / total;
    const depth = (stageSum / total) / 9;

    /* 归一化到 0-100 */
    return {
      retention: Math.round(avgRet * 100),
      speed: Math.round(Math.max(0, Math.min(1, (12 - avgSec) / 10)) * 100),
      accuracy: Math.round(accuracy * 100),
      stability: Math.round(stability * 100),
      coverage: Math.round(coverage * 100),
      depth: Math.round(depth * 100)
    };
  };

  /* ---------- 遗忘曲线（理论 vs 实测） ---------- */
  window.computeForgetCurve = function () {
    /* 理论：R = exp(-0.5 * t / 1) —— 以阶段 1（间隔 1 天）为基准 */
    const theory = [];
    for (let t = 0; t <= 15; t += 0.5) theory.push({ t: t, r: Math.exp(-0.5 * t / 1) });

    /* 实测：按「距上次复习天数」分桶，取平均保持率 */
    const buckets = {};
    const keys = Object.keys(App.library);
    const today = todayStr();
    for (let i = 0; i < keys.length; i++) {
      const st = App.states[keys[i]];
      if (!st || !st.reviews || !st.last_review) continue;
      const elapsed = Math.max(0, daysBetween(st.last_review, today));
      const b = Math.min(15, Math.round(elapsed));
      if (!buckets[b]) buckets[b] = { sum: 0, n: 0 };
      buckets[b].sum += retentionRate(keys[i], today);
      buckets[b].n++;
    }
    const actual = Object.keys(buckets).map(k => ({
      t: parseFloat(k),
      r: buckets[k].n ? buckets[k].sum / buckets[k].n : 0,
      n: buckets[k].n
    })).sort((a, b) => a.t - b.t);

    return { theory: theory, actual: actual };
  };

  /* ---------- 未来 30 天压力预测 ---------- */
  window.computeForecast30 = function () {
    const sched = computeSchedule();
    const today = sched.today;
    const out = [];
    for (let d = 0; d < 30; d++) {
      const ds = addDays(today, d);
      const list = sched.dueByDate[ds] || [];
      out.push({ date: ds, count: list.length, day: d });
    }
    if (sched.overdue.length) out[0].count += sched.overdue.length;
    return out;
  };

  /* ---------- 每日学习量与正确率 ---------- */
  window.computeDailyTrend = function () {
    const byDate = {};
    const all = allSessionsFlat();
    for (let i = 0; i < all.length; i++) {
      const date = all[i][0];
      const rev = all[i][1].reviews || [];
      if (!byDate[date]) byDate[date] = { date: date, n: 0, hit: 0, ms: 0, msN: 0 };
      for (let j = 0; j < rev.length; j++) {
        byDate[date].n++;
        if (rev[j].rating === '熟悉' || rev[j].rating === '模糊') byDate[date].hit++;
        if (rev[j].elapsed_ms) { byDate[date].ms += rev[j].elapsed_ms; byDate[date].msN++; }
      }
    }
    return Object.values(byDate).sort((a, b) => a.date.localeCompare(b.date));
  };

  /* ---------- 反应时间分布 ---------- */
  window.computeRTDistribution = function () {
    const bins = [0, 1, 2, 3, 5, 8, 12, 20, 30, 9999];
    const labels = ['<1', '1-2', '2-3', '3-5', '5-8', '8-12', '12-20', '20-30', '>30'];
    const counts = new Array(labels.length).fill(0);
    const all = allSessionsFlat();
    let sum = 0, n = 0;
    for (let i = 0; i < all.length; i++) {
      const rev = all[i][1].reviews || [];
      for (let j = 0; j < rev.length; j++) {
        if (!rev[j].elapsed_ms) continue;
        const sec = rev[j].elapsed_ms / 1000;
        sum += sec; n++;
        for (let b = 0; b < labels.length; b++) {
          if (sec >= bins[b] && sec < bins[b + 1]) { counts[b]++; break; }
        }
      }
    }
    return { labels: labels, counts: counts, avg: n ? sum / n : 0, total: n };
  };

  /* ---------- 单轮疲劳曲线 ---------- */
  window.computeFatigueCurve = function () {
    /* 以每次 session 内答题顺序为横轴，统计前 60 题内的正确率变化 */
    const slots = new Array(60).fill(0).map(() => ({ hit: 0, n: 0 }));
    const all = allSessionsFlat();
    for (let i = 0; i < all.length; i++) {
      const rev = all[i][1].reviews || [];
      for (let j = 0; j < rev.length && j < 60; j++) {
        slots[j].n++;
        if (rev[j].rating === '熟悉' || rev[j].rating === '模糊') slots[j].hit++;
      }
    }
    return slots.map((s, i) => ({ idx: i + 1, acc: s.n ? s.hit / s.n : null, n: s.n }));
  };

  /* ---------- 危机词汇 ---------- */
  window.computeRiskWords = function () {
    const keys = Object.keys(App.library);
    const list = keys.map(k => {
      const m = App.mastery[k];
      if (!m) return null;
      const st = App.states[k] || {};
      /* 风险分 = 100 - 掌握分 + 错误惩罚 + 逾期惩罚 */
      let risk = (100 - m.score);
      risk += (st.wrong || 0) * 3;
      risk += (st.confuse || 0) * 5;
      if (st.due && st.due < todayStr()) risk += 15;
      return { key: k, text: m.text, meaning: m.meaning, stars: m.stars, score: m.score, risk: risk };
    }).filter(Boolean).sort((a, b) => b.risk - a.risk).slice(0, 12);
    return list;
  };

  /* ---------- 科学诊断结论 ---------- */
  window.generateInsights = function () {
    const six = computeSixDim();
    const dist = starDistribution();
    const trend = computeDailyTrend();
    const rt = computeRTDistribution();
    const fc = computeForecast30();
    const insights = [];

    /* 1. 整体水平 */
    const avgStars = dist.total ? (dist.dist[1] * 1 + dist.dist[2] * 2 + dist.dist[3] * 3 + dist.dist[4] * 4 + dist.dist[5] * 5) / dist.total : 0;
    if (avgStars >= 3.8) insights.push({ level: 'ok', text: '<b>整体掌握度优秀</b>：平均 ' + avgStars.toFixed(2) + '★，已进入长期记忆维持阶段。建议保持复习节奏，扩大新词覆盖面。' });
    else if (avgStars >= 2.8) insights.push({ level: '', text: '<b>整体掌握度中等</b>：平均 ' + avgStars.toFixed(2) + '★，大部分词汇处于短期记忆区，需继续按曲线巩固。' });
    else insights.push({ level: 'warn', text: '<b>整体掌握度偏低</b>：平均 ' + avgStars.toFixed(2) + '★，建议减少新词摄入，先攻克 ★1–★2 难词。' });

    /* 2. 危险区占比 */
    const dangerRatio = dist.total ? dist.dist[1] / dist.total : 0;
    if (dangerRatio >= 0.25) insights.push({ level: 'bad', text: '<b>' + (dangerRatio * 100).toFixed(0) + '% 词汇处于 ★1 危险区</b>，已触发遗忘临界。建议每日使用「★1 急救」模式优先复习。' });
    else if (dangerRatio >= 0.10) insights.push({ level: 'warn', text: '<b>' + (dangerRatio * 100).toFixed(0) + '% 词汇处于 ★1 危险区</b>，可用深度训练营集中突破。' });

    /* 3. 反应速度 */
    if (rt.avg > 0) {
      if (rt.avg < 3) insights.push({ level: 'ok', text: '<b>平均反应 ' + rt.avg.toFixed(1) + ' 秒</b>，属于条件反射级熟悉度，词汇提取流畅。' });
      else if (rt.avg < 6) insights.push({ level: '', text: '<b>平均反应 ' + rt.avg.toFixed(1) + ' 秒</b>，正常区间。继续强化可缩短至 3 秒以内。' });
      else insights.push({ level: 'warn', text: '<b>平均反应 ' + rt.avg.toFixed(1) + ' 秒</b>，偏慢，说明部分词汇仍停留在「再认」而非「回忆」层级。建议增加「反向回忆」训练。' });
    }

    /* 4. 复习压力 */
    const totalForecast = fc.reduce((a, b) => a + b.count, 0);
    const peak = fc.reduce((m, x) => x.count > m.count ? x : m, fc[0] || { count: 0 });
    if (totalForecast > 800) insights.push({ level: 'warn', text: '<b>未来 30 天复习总量 ' + totalForecast + ' 词次</b>，峰值出现在第 ' + peak.day + ' 天（' + peak.count + ' 词）。建议提前分散，避免疲劳堆积。' });
    else if (totalForecast > 0) insights.push({ level: '', text: '<b>未来 30 天复习总量 ' + totalForecast + ' 词次</b>，峰值第 ' + peak.day + ' 天（' + peak.count + ' 词），压力可控。' });

    /* 5. 稳定性 */
    if (six.stability < 25) insights.push({ level: 'warn', text: '<b>长期记忆转化率仅 ' + six.stability + '%</b>，大量词汇滞留在阶段 &lt; 4。建议每天固定 15 分钟做「到期复习」，加速进入长期记忆区。' });
    else if (six.stability >= 50) insights.push({ level: 'ok', text: '<b>长期记忆转化率 ' + six.stability + '%</b>，超过一半词汇已稳固。' });

    /* 6. 覆盖广度 */
    if (six.coverage < 60) insights.push({ level: 'warn', text: '<b>词库覆盖仅 ' + six.coverage + '%</b>，建议先扩大学习面，再回头巩固细节。' });

    /* 7. 学习规律 */
    if (trend.length >= 3) {
      const recent = trend.slice(-7);
      const avgN = recent.reduce((a, b) => a + b.n, 0) / recent.length;
      if (avgN < 20) insights.push({ level: 'warn', text: '<b>近 7 天日均仅 ' + avgN.toFixed(0) + ' 题</b>，学习强度偏低。建议将每日目标提高到 40–60 题。' });
      else if (avgN > 150) insights.push({ level: 'warn', text: '<b>近 7 天日均 ' + avgN.toFixed(0) + ' 题</b>，强度偏高。注意劳逸结合，正确率比数量更重要。' });
    }

    return insights;
  };

  /* ---------- 学习计划生成 ---------- */
  window.generateLearningPlan = function () {
    const today = todayStr();
    const sched = computeSchedule();
    const dist = starDistribution();

    const plan = {
      generated_at: nowISO(),
      version: 1,
      base_date: today,
      star_summary: {
        star1: dist.dist[1] || 0,
        star2: dist.dist[2] || 0,
        star3: dist.dist[3] || 0,
        star4: dist.dist[4] || 0,
        star5: dist.dist[5] || 0,
        avg: dist.avg
      },
      daily: []
    };

    const dailyReviewCap = App.settings.dailyReviewLimit || 120;
    const dailyNewCap = App.settings.dailyNewLimit || 30;

    let hardRemaining = dist.dist[1] || 0;

    for (let d = 0; d < 7; d++) {
      const date = addDays(today, d);
      const dueList = d === 0
        ? (sched.dueByDate[date] || []).concat(sched.overdue)
        : (sched.dueByDate[date] || []);

      const due = dueList.length;
      const hardN = dueList.filter(k => starOf(k) <= 2).length;
      const newN = Math.min(dailyNewCap, Math.max(0, Math.round(dailyNewCap * (d === 0 ? 0.6 : 1))));
      const reviewN = Math.min(dailyReviewCap, due);

      let note = '';
      if (hardN > 15) note = '⚠ 难词密集，建议先攻 ★1–★2';
      else if (due > dailyReviewCap) note = '⚠ 到期词超出上限，建议拆分成两轮';
      else if (d === 0) note = '今日优先：逾期 → 到期 → ★1 急救';

      plan.daily.push({
        day: d,
        date: date,
        review_target: reviewN,
        new_target: newN,
        hard_target: Math.min(hardN, 15),
        due_total: due,
        hard_total: hardN,
        note: note
      });

      hardRemaining = Math.max(0, hardRemaining - 15);
    }

    /* 攻坚建议 */
    const advice = [];
    if (dist.dist[1] > 30) advice.push({ level: 1, text: '★1 生疏词 ' + dist.dist[1] + ' 个：每日专项 15 词，配合深度训练营「拼写重构」题型，3–5 天内可降至 ★2。' });
    if (dist.dist[2] > 40) advice.push({ level: 2, text: '★2 薄弱词 ' + dist.dist[2] + ' 个：每日 20 词，用「反向回忆 + 形近对抗」交叉训练。' });
    if (dist.dist[3] > 50) advice.push({ level: 3, text: '★3 一般词 ' + dist.dist[3] + ' 个：按艾宾浩斯节奏常规复习，无需额外干预。' });
    if (dist.dist[4] + dist.dist[5] > 0) advice.push({ level: 4, text: '★4–★5 稳固词 ' + (dist.dist[4] + dist.dist[5]) + ' 个：仅需到期时点一遍，把时间让给 ★1–★2。' });
    if (!advice.length) advice.push({ level: 3, text: '暂无数据，去「今日复习」开始第一轮吧。' });

    plan.advice = advice;
    App.plan = plan;
    return plan;
  };

  /* ---------- 导出（下载） ---------- */
  window.downloadJSON = function (fileName, obj) {
    const text = JSON.stringify(obj, null, 2);
    const blob = new Blob([text], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
  };

  window.downloadXlsx = function (fileName, aoa, sheetName) {
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName || 'Sheet1');
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
  };

  console.log('[analytics] 已加载');
})();