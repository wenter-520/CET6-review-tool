/* ============================================================
   dashboard.js — 数据大屏（左侧列表 + 右侧图表/数据）
   ============================================================ */
(function () {
  'use strict';

  let clockTimer = null;
  let currentKey = 'radar';
  let resizeTimer = null;

  /* ---------- 左侧菜单定义 ---------- */
  const MENU_GROUPS = [
    { name: '记忆状态', items: [
      { id: 'radar',     icon: '🎯', name: '六维能力雷达', hint: '综合能力评估' },
      { id: 'stars',     icon: '⭐', name: '五星掌握度',   hint: '词汇掌握分布' },
      { id: 'retention', icon: '🧠', name: '保持率分桶',   hint: '安全 / 临界 / 危险' }
    ]},
    { name: '学习行为', items: [
      { id: 'trend',     icon: '📈', name: '每日学习趋势', hint: '答题量 + 正确率' },
      { id: 'heatmap',   icon: '🗓️', name: '学习热力日历', hint: '近 90 天活跃度' },
      { id: 'fatigue',   icon: '🌀', name: '单轮疲劳曲线', hint: '答题序号 → 正确率' },
      { id: 'rt',        icon: '⚡', name: '反应时间分布', hint: '认知负荷分析' }
    ]},
    { name: '复习调度', items: [
      { id: 'forget',    icon: '📉', name: '遗忘曲线',      hint: '理论 vs 实测' },
      { id: 'forecast',  icon: '📊', name: '30 天压力预测', hint: '每日到期词数' },
      { id: 'stages',    icon: '🔁', name: '复习阶段分布',  hint: '各阶段词数与保持率' }
    ]},
    { name: '词汇健康', items: [
      { id: 'groups',    icon: '📚', name: '分组统计',      hint: '基础 / 过考 / 核心' },
      { id: 'risk',      icon: '🚨', name: '危机词汇 TOP',  hint: '最高风险词' },
      { id: 'insight',   icon: '💡', name: '诊断结论',      hint: '科学分析与建议' }
    ]}
  ];

  /* ============================================================
     时钟
     ============================================================ */
  function startClock() {
    stopClock();
    const tick = () => {
      const d = new Date();
      const c = el('dashClock');
      if (c) c.textContent = pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
      const dt = el('dashDate');
      if (dt) dt.textContent = d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) +
        ' · ' + ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()];
    };
    tick();
    clockTimer = setInterval(tick, 1000);
  }
  function stopClock() {
    if (clockTimer) { clearInterval(clockTimer); clockTimer = null; }
  }

  /* ============================================================
     打开 / 关闭
     ============================================================ */
  window.openDashboard = function () {
    el('dashPage').style.display = 'flex';
    startClock();
    renderMenu();
    /* 先渲染 KPI 与统计，等一帧让 grid 布局稳定后渲染图表 */
    requestAnimationFrame(() => {
      renderDashboard();
      App._dashTimer = setInterval(() => { safe('dashRefresh', renderDashboard); }, 30000);
    });
  };
  window.closeDashboard = function () {
    el('dashPage').style.display = 'none';
    stopClock();
    if (App._dashTimer) { clearInterval(App._dashTimer); App._dashTimer = null; }
  };

  /* ============================================================
     渲染入口
     ============================================================ */
  window.renderDashboard = function () {
    if (!App.ready) return;
    refreshMastery();
    renderKpis();
    renderSideStats();
    renderPanel(currentKey);
  };

  /* ============================================================
     左侧菜单
     ============================================================ */
  function renderMenu() {
    const menu = el('dashMenu');
    if (!menu) return;
    let html = '';
    MENU_GROUPS.forEach(g => {
      html += '<div class="side-group-title">' + g.name + '</div>';
      g.items.forEach(it => {
        html += '<button class="side-item' + (it.id === currentKey ? ' on' : '') + '" data-k="' + it.id + '">' +
          '<span class="si-icon">' + it.icon + '</span>' +
          '<span class="si-text"><b>' + it.name + '</b><em>' + it.hint + '</em></span>' +
        '</button>';
      });
    });
    menu.innerHTML = html;
    menu.onclick = e => {
      let t = e.target;
      while (t && t !== menu && !(t.getAttribute && t.getAttribute('data-k'))) t = t.parentNode;
      if (!t || t === menu) return;
      selectPanel(t.getAttribute('data-k'));
    };
  }

  function selectPanel(k) {
    currentKey = k;
    qsa('.side-item', el('dashMenu')).forEach(b => {
      b.classList.toggle('on', b.getAttribute('data-k') === k);
    });
    renderPanel(k);
  }

  function renderSideStats() {
    const dist = starDistribution();
    const stats = computeStats();
    if (el('dashSideWords')) el('dashSideWords').textContent = Object.keys(App.library).length;
    if (el('dashSideDays')) el('dashSideDays').textContent = Object.keys(stats.byDate).length;
    if (el('dashSideAnswers')) el('dashSideAnswers').textContent = stats.answers;
    if (el('dashSideStars')) el('dashSideStars').textContent = avgStar(dist).toFixed(2) + '★';
  }

  /* ============================================================
     右侧面板分发
     ============================================================ */
  const RENDERERS = {
    radar:     panelRadar,
    stars:     panelStars,
    retention: panelRetention,
    trend:     panelTrend,
    heatmap:   panelHeatmap,
    fatigue:   panelFatigue,
    rt:        panelRT,
    forget:    panelForget,
    forecast:  panelForecast,
    stages:    panelStages,
    groups:    panelGroups,
    risk:      panelRisk,
    insight:   panelInsight
  };

  function renderPanel(k) {
    const chart = el('dashViewChart');
    const table = el('dashViewTable');
    if (!chart || !table) return;
    chart.innerHTML = '';
    table.innerHTML = '';

    const ctx = {
      chart: chart,
      table: table,
      title: el('dashViewTitle'),
      hint: el('dashViewHint')
    };

    const fn = RENDERERS[k] || panelRadar;
    /* 延迟一帧确保 grid 布局完成，clientWidth/Height 准确 */
    requestAnimationFrame(() => {
      try { fn(ctx); }
      catch (e) {
        console.error('[panel ' + k + ']', e);
        chart.innerHTML = '<div class="chart-empty">渲染失败</div>';
      }
    });
  }

  /* ============================================================
     KPI 卡
     ============================================================ */
  function renderKpis() {
    const dist = starDistribution();
    const six = computeSixDim();
    const stats = computeStats();
    const sched = computeSchedule();
    const avg = avgStar(dist);

    const kpis = [
      { label: '词库总量', num: Object.keys(App.library).length,
        hint: '覆盖 ' + Object.keys(App.days).filter(d => +d > 0).length + ' 天', cls: '' },
      { label: '平均掌握', num: avg.toFixed(2) + ' ★',
        hint: '掌握分均值 ' + dist.avg.toFixed(1),
        cls: avg >= 3.5 ? 'k-ok' : (avg >= 2.5 ? 'k-warn' : 'k-bad') },
      { label: '今日待复习', num: (sched.dueByDate[sched.today] || []).length + sched.overdue.length,
        hint: '逾期 ' + sched.overdue.length + ' 词',
        cls: sched.overdue.length > 30 ? 'k-bad' : (sched.overdue.length > 10 ? 'k-warn' : '') },
      { label: '累计答题', num: stats.answers, hint: '会话 ' + stats.sessions + ' 次', cls: '' },
      { label: '综合正确率', num: six.accuracy + '%', hint: '熟悉 + 模糊',
        cls: six.accuracy >= 80 ? 'k-ok' : (six.accuracy >= 60 ? 'k-warn' : 'k-bad') },
      { label: '长期记忆转化', num: six.stability + '%', hint: '阶段 ≥ 4 占比',
        cls: six.stability >= 50 ? 'k-ok' : (six.stability >= 25 ? 'k-warn' : 'k-bad') }
    ];

    el('dashKpis').innerHTML = kpis.map(k =>
      '<div class="dash-kpi ' + k.cls + '">' +
        '<div class="kk-label">' + k.label + '</div>' +
        '<div class="kk-num">' + k.num + '</div>' +
        '<div class="kk-hint">' + k.hint + '</div>' +
      '</div>'
    ).join('');
  }

  /* ============================================================
     通用小工具
     ============================================================ */
  function avgStar(dist) {
    if (!dist.total) return 0;
    return (dist.dist[1] * 1 + dist.dist[2] * 2 + dist.dist[3] * 3 + dist.dist[4] * 4 + dist.dist[5] * 5) / dist.total;
  }
  function level(v) {
    if (v >= 80) return { text: '优秀', color: '#22c55e' };
    if (v >= 60) return { text: '良好', color: '#84cc16' };
    if (v >= 40) return { text: '中等', color: '#f59e0b' };
    if (v >= 20) return { text: '偏弱', color: '#f97316' };
    return { text: '危险', color: '#ef4444' };
  }
  function accColor(a) {
    if (a >= 80) return '#22c55e';
    if (a >= 60) return '#f59e0b';
    return '#ef4444';
  }
  function tableHtml(headers, rows) {
    let h = '<table><thead><tr>';
    for (let i = 0; i < headers.length; i++) h += '<th>' + headers[i] + '</th>';
    h += '</tr></thead><tbody>';
    for (let r = 0; r < rows.length; r++) {
      h += '<tr>';
      for (let c = 0; c < rows[r].length; c++) h += '<td>' + rows[r][c] + '</td>';
      h += '</tr>';
    }
    h += '</tbody></table>';
    return h;
  }
  function barHtml(pct, color) {
    const w = Math.max(0, Math.min(100, pct));
    return '<span class="mini-bar"><i style="width:' + w + '%;background:' + color + '"></i></span>';
  }
  function starRangeText(n) {
    return ['', '<30', '30–50', '50–70', '70–85', '≥85'][n] || '-';
  }
  function heatLevel(n, maxN) {
    if (!n) return 0;
    const r = n / (maxN || 1);
    if (r <= 0.2) return 1;
    if (r <= 0.5) return 2;
    if (r <= 0.8) return 3;
    return 4;
  }

  /* ============================================================
     面板 1 · 六维能力雷达
     ============================================================ */
  function panelRadar(ctx) {
    const six = computeSixDim();
    const dist = starDistribution();
    const stats = computeStats();

    ctx.title.textContent = '🎯 六维能力雷达';
    ctx.hint.textContent = '从记忆保持、反应速度、准确率、稳定性、覆盖广度、深度掌握 6 个维度综合评估当前学习状态，越靠近外圈能力越强（满分 100）。';

    renderRadarChart(ctx.chart, [
      { label: '记忆保持', value: six.retention },
      { label: '反应速度', value: six.speed },
      { label: '准确率',   value: six.accuracy },
      { label: '稳定性',   value: six.stability },
      { label: '覆盖广度', value: six.coverage },
      { label: '深度掌握', value: six.depth }
    ]);

    const rows = [
      ['记忆保持率', six.retention, '平均记忆保持率（0–100）'],
      ['反应速度',   six.speed,     '平均反应时间反向归一化'],
      ['准确率',     six.accuracy,  '熟悉 + 模糊 占比'],
      ['稳定性',     six.stability, '复习阶段 ≥ 4 词汇占比'],
      ['覆盖广度',   six.coverage,  '有复习记录的词汇占比'],
      ['深度掌握',   six.depth,     '平均复习阶段 / 9']
    ].map(r => {
      const lv = level(r[1]);
      return [
        '<b>' + r[0] + '</b>',
        '<span class="num" style="color:' + lv.color + '">' + r[1] + '</span>',
        r[2],
        '<span class="tag" style="color:' + lv.color + ';border-color:' + lv.color + '55">' + lv.text + '</span>'
      ];
    });

    ctx.table.innerHTML = tableHtml(['维度', '得分', '说明', '等级'], rows) +
      '<div class="dash-note">平均掌握度 <b>' + avgStar(dist).toFixed(2) + '★</b> · 总词汇 <b>' + dist.total +
      '</b> · 累计答题 <b>' + stats.answers + '</b> 次 · 学习天数 <b>' + Object.keys(stats.byDate).length + '</b> 天</div>';
  }

  /* ============================================================
     面板 2 · 五星掌握度
     ============================================================ */
  function panelStars(ctx) {
    const dist = starDistribution();

    ctx.title.textContent = '⭐ 五星掌握度分布';
    ctx.hint.textContent = '掌握分 = 40×阶段分 + 30×保持率 + 20×正确率 + 10×连对，再乘复习次数置信度。按阈值划分星级：★1<30、★2 30–50、★3 50–70、★4 70–85、★5 ≥85。';

    const items = [
      { label: '★1 生疏', value: dist.dist[1] || 0, color: '#ef4444' },
      { label: '★2 薄弱', value: dist.dist[2] || 0, color: '#f59e0b' },
      { label: '★3 一般', value: dist.dist[3] || 0, color: '#64748b' },
      { label: '★4 良好', value: dist.dist[4] || 0, color: '#22c55e' },
      { label: '★5 精通', value: dist.dist[5] || 0, color: '#8b5cf6' }
    ];
    renderDonutChart(ctx.chart, items, { centerValue: dist.total, centerLabel: '词汇总数' });

    const rows = items.map((it, i) => {
      const n = it.value;
      const pct = dist.total ? n / dist.total * 100 : 0;
      return [
        '<b style="color:' + it.color + '">' + it.label + '</b>',
        '<span class="num">' + n + '</span>',
        '<span class="num">' + pct.toFixed(1) + '%</span>',
        barHtml(pct, it.color),
        starRangeText(i + 1)
      ];
    });

    ctx.table.innerHTML = tableHtml(['星级', '词数', '占比', '分布', '掌握分区间'], rows) +
      '<div class="dash-note">平均掌握分 <b>' + dist.avg.toFixed(1) +
      '</b> · 平均 <b>' + avgStar(dist).toFixed(2) + '★</b> · 危险词（★1）占比 <b style="color:#ef4444">' +
      (dist.total ? (dist.dist[1] / dist.total * 100).toFixed(1) : '0.0') + '%</b></div>';
  }

  /* ============================================================
     面板 3 · 保持率分桶
     ============================================================ */
  function panelRetention(ctx) {
    const { buckets, total } = computeRetentionBuckets();

    ctx.title.textContent = '🧠 记忆保持率分桶';
    ctx.hint.textContent = '保持率 R = exp(-0.5 × 距上次复习天数 / 当前阶段间隔)，反映词汇当前的记忆牢固程度。≥70% 安全，40–70% 临界，<40% 危险。';

    renderBarChart(ctx.chart, buckets.map(b => ({
      label: b.label,
      value: b.n,
      color: b.color
    })), { barWidth: 46, padB: 40 });

    const rows = buckets.map(b => [
      '<b style="color:' + b.color + '">' + b.label + '</b>',
      '<span class="num">' + b.n + '</span>',
      '<span class="num">' + (total ? (b.n / total * 100).toFixed(1) : '0.0') + '%</span>',
      barHtml(total ? b.n / total * 100 : 0, b.color),
      b.action
    ]);

    ctx.table.innerHTML = tableHtml(['保持率区间', '词数', '占比', '分布', '建议'], rows) +
      '<div class="dash-note">共统计 <b>' + total + '</b> 个已复习词汇</div>';
  }

  function computeRetentionBuckets() {
    const buckets = [
      { label: '≥90%',   min: 0.90, max: 1.01, n: 0, color: '#16a34a', action: '记忆极其牢固' },
      { label: '70-90%', min: 0.70, max: 0.90, n: 0, color: '#22c55e', action: '按计划复习即可' },
      { label: '50-70%', min: 0.50, max: 0.70, n: 0, color: '#f59e0b', action: '1–2 天内复习' },
      { label: '30-50%', min: 0.30, max: 0.50, n: 0, color: '#f97316', action: '今日优先复习' },
      { label: '<30%',   min: 0.00, max: 0.30, n: 0, color: '#ef4444', action: '即将遗忘，立即复习' }
    ];
    const today = todayStr();
    let total = 0;
    for (const k in App.library) {
      if (!App.library.hasOwnProperty(k)) continue;
      const st = App.states[k];
      if (!st || !st.reviews || !st.last_review) continue;
      const r = retentionRate(k, today);
      total++;
      for (let i = 0; i < buckets.length; i++) {
        if (r >= buckets[i].min && r < buckets[i].max) { buckets[i].n++; break; }
      }
    }
    return { buckets, total };
  }

  /* ============================================================
     面板 4 · 每日学习趋势
     ============================================================ */
  function panelTrend(ctx) {
    const trend = computeDailyTrend();

    ctx.title.textContent = '📈 每日学习趋势';
    ctx.hint.textContent = '综合展示每日答题量与正确率变化，用来观察学习节奏是否稳定、正确率是否波动。';

    if (!trend.length) {
      ctx.chart.innerHTML = '<div class="chart-empty">暂无学习记录</div>';
      ctx.table.innerHTML = '<div class="dash-note">去「今日复习」开始第一轮吧</div>';
      return;
    }

    const series = [
      {
        name: '每日答题量', color: '#4a6cf7', type: 'area',
        points: trend.map((t, i) => ({ x: i, y: t.n }))
      },
      {
        name: '正确率(%)', color: '#22c55e', type: 'line', dots: true,
        points: trend.map((t, i) => ({ x: i, y: t.n ? t.hit / t.n * 100 : 0 }))
      }
    ];
    renderLineChart(ctx.chart, series, {
      yMin: 0, yTicks: 4,
      xTicks: Math.min(10, trend.length),
      xFormat: x => {
        const t = trend[Math.round(x)];
        return t ? t.date.slice(5) : '';
      }
    });

    const recent = trend.slice(-14).reverse();
    const rows = recent.map(t => {
      const acc = t.n ? t.hit / t.n * 100 : 0;
      const avgMs = t.msN ? t.ms / t.msN / 1000 : 0;
      const color = accColor(acc);
      return [
        t.date,
        '<span class="num">' + t.n + '</span>',
        '<span class="num" style="color:' + color + '">' + acc.toFixed(1) + '%</span>',
        '<span class="num">' + avgMs.toFixed(2) + 's</span>',
        barHtml(acc, color)
      ];
    });

    ctx.table.innerHTML = tableHtml(['日期', '答题量', '正确率', '平均耗时', '正确率分布'], rows) +
      '<div class="dash-note">共 <b>' + trend.length + '</b> 天有学习记录 · 累计答题 <b>' +
      trend.reduce((a, b) => a + b.n, 0) + '</b> 题</div>';
  }

  /* ============================================================
     面板 5 · 学习热力日历
     ============================================================ */
  function panelHeatmap(ctx) {
    const data = computeHeatmap();
    ctx.title.textContent = '🗓️ 学习热力日历';
    ctx.hint.textContent = '近 90 天的学习活跃度，颜色越深代表当日答题越多。用于观察学习习惯是否规律。';

    const maxN = Math.max(1, ...data.map(d => d.n));
    const startDate = data[0].date;
    const startDay = new Date(startDate + 'T00:00:00').getDay(); // 0=周日

    let html = '<div class="dash-hm-wrap">';
    html += '<div class="dash-hm-grid">';
    for (let i = 0; i < startDay; i++) html += '<div class="dash-hm-cell dash-hm-empty"></div>';
    data.forEach(d => {
      const lv = heatLevel(d.n, maxN);
      html += '<div class="dash-hm-cell dash-hm-' + lv + '" title="' + d.date + '：' + d.n + ' 题"></div>';
    });
    html += '</div>';
    html += '<div class="dash-hm-legend">少 <i class="dash-hm-0"></i><i class="dash-hm-1"></i><i class="dash-hm-2"></i><i class="dash-hm-3"></i><i class="dash-hm-4"></i> 多</div>';
    html += '</div>';
    ctx.chart.innerHTML = html;

    /* 按周汇总 */
    const weeks = [];
    let week = { days: 0, n: 0, active: 0, start: '', end: '' };
    data.forEach(d => {
      if (week.days === 0) week.start = d.date;
      week.days++;
      week.n += d.n;
      if (d.n > 0) week.active++;
      week.end = d.date;
      if (week.days === 7) { weeks.push(week); week = { days: 0, n: 0, active: 0, start: '', end: '' }; }
    });
    if (week.days > 0) weeks.push(week);

    const rows = weeks.slice(-8).reverse().map(w => [
      w.start.slice(5) + ' ~ ' + w.end.slice(5),
      '<span class="num">' + w.active + ' / ' + w.days + '</span>',
      '<span class="num">' + w.n + '</span>',
      barHtml(w.n / Math.max(1, maxN * 7) * 100, '#22c55e')
    ]);

    const totalN = data.reduce((a, b) => a + b.n, 0);
    const activeDays = data.filter(d => d.n > 0).length;

    ctx.table.innerHTML = tableHtml(['周期', '活跃天数', '答题量', '强度'], rows) +
      '<div class="dash-note">近 90 天：<b>' + activeDays + '</b> 天有学习记录，共 <b>' + totalN +
      '</b> 题 · 日均 <b>' + (totalN / 90).toFixed(1) + '</b> 题 · 峰值 <b>' + maxN + '</b> 题</div>';
  }

  function computeHeatmap() {
    const byDate = computeStats().byDate;
    const today = todayStr();
    const out = [];
    for (let i = 89; i >= 0; i--) {
      const d = addDays(today, -i);
      out.push({ date: d, n: byDate[d] || 0 });
    }
    return out;
  }

  /* ============================================================
     面板 6 · 单轮疲劳曲线
     ============================================================ */
  function panelFatigue(ctx) {
    const fc = computeFatigueCurve().filter(p => p.n >= 3);
    ctx.title.textContent = '🌀 单轮疲劳曲线';
    ctx.hint.textContent = '以每轮 session 内的答题序号为横轴，统计该位置的平均正确率。若曲线明显下降，说明存在注意力疲劳。';

    if (!fc.length) {
      ctx.chart.innerHTML = '<div class="chart-empty">数据不足（每位置至少 3 题）</div>';
      ctx.table.innerHTML = '<div class="dash-note">继续积累答题记录后再来看</div>';
      return;
    }

    renderLineChart(ctx.chart, [{
      name: '单轮正确率(%)', color: '#8b5cf6', type: 'line', dots: true, r: 2.5,
      points: fc.map(p => ({ x: p.idx, y: p.acc * 100 }))
    }], {
      yMin: 0, yMax: 100, yTicks: 4,
      xTicks: 8, xFormat: x => '第' + Math.round(x) + '题'
    });

    const segs = 5;
    const segLen = Math.ceil(fc.length / segs);
    const segRows = [];
    for (let s = 0; s < segs; s++) {
      const chunk = fc.slice(s * segLen, (s + 1) * segLen).filter(p => p.n > 0);
      if (!chunk.length) continue;
      const total = chunk.reduce((a, b) => a + b.n, 0);
      const hit = chunk.reduce((a, b) => a + b.n * b.acc, 0);
      const acc = total ? hit / total * 100 : 0;
      const from = chunk[0].idx, to = chunk[chunk.length - 1].idx;
      const color = accColor(acc);
      segRows.push([
        '第 ' + from + '–' + to + ' 题',
        '<span class="num">' + total + '</span>',
        '<span class="num" style="color:' + color + '">' + acc.toFixed(1) + '%</span>',
        barHtml(acc, color)
      ]);
    }

    const first = fc[0].acc * 100, last = fc[fc.length - 1].acc * 100;
    const drop = first - last;

    ctx.table.innerHTML = tableHtml(['答题区间', '样本量', '平均正确率', '分布'], segRows) +
      '<div class="dash-note">首段正确率 <b>' + first.toFixed(1) + '%</b> · 末段正确率 <b>' + last.toFixed(1) +
      '%</b> · ' + (drop > 10
        ? '<b style="color:#ef4444">衰减 ' + drop.toFixed(1) + '%，存在明显疲劳，建议每轮控制在 30–40 题</b>'
        : '<b style="color:#22c55e">衰减 ' + drop.toFixed(1) + '%，注意力保持良好</b>') + '</div>';
  }

  /* ============================================================
     面板 7 · 反应时间分布
     ============================================================ */
  function panelRT(ctx) {
    const rt = computeRTDistribution();
    ctx.title.textContent = '⚡ 反应时间分布与认知负荷';
    ctx.hint.textContent = '反应时间反映词汇提取的自动化程度。<3 秒为条件反射级，3–6 秒为正常回忆，>8 秒说明仍在“再认”阶段。';

    if (!rt.total) {
      ctx.chart.innerHTML = '<div class="chart-empty">暂无计时记录</div>';
      ctx.table.innerHTML = '<div class="dash-note">复习时会自动记录每题耗时</div>';
      return;
    }

    const bars = rt.labels.map((l, i) => ({
      label: l + 's',
      value: rt.counts[i],
      color: i < 3 ? '#22c55e' : (i < 6 ? '#4a6cf7' : (i < 8 ? '#f59e0b' : '#ef4444'))
    }));
    renderBarChart(ctx.chart, bars, { barWidth: 24, padB: 34 });

    const rows = rt.labels.map((l, i) => {
      const n = rt.counts[i];
      const pct = rt.total ? n / rt.total * 100 : 0;
      let lvl, color;
      if (i < 3) { lvl = '条件反射'; color = '#22c55e'; }
      else if (i < 6) { lvl = '正常回忆'; color = '#4a6cf7'; }
      else if (i < 8) { lvl = '偏慢'; color = '#f59e0b'; }
      else { lvl = '严重卡顿'; color = '#ef4444'; }
      return [
        '<b>' + l + ' 秒</b>',
        '<span class="num">' + n + '</span>',
        '<span class="num">' + pct.toFixed(1) + '%</span>',
        barHtml(pct, color),
        '<span class="tag" style="color:' + color + ';border-color:' + color + '55">' + lvl + '</span>'
      ];
    });

    ctx.table.innerHTML = tableHtml(['区间', '次数', '占比', '分布', '等级'], rows) +
      '<div class="dash-note">平均反应 <b>' + rt.avg.toFixed(2) + ' 秒</b> · 有效计时 <b>' + rt.total +
      '</b> 题 · ' + (rt.avg < 3
        ? '<b style="color:#22c55e">提取流畅</b>'
        : rt.avg < 6
          ? '<b style="color:#4a6cf7">正常区间，继续强化可缩短至 3 秒内</b>'
          : '<b style="color:#f59e0b">偏慢，建议增加反向回忆训练</b>') + '</div>';
  }

  /* ============================================================
     面板 8 · 遗忘曲线
     ============================================================ */
  function panelForget(ctx) {
    const fc = computeForgetCurve();
    ctx.title.textContent = '📉 艾宾浩斯遗忘曲线 · 理论 vs 实测';
    ctx.hint.textContent = '蓝色虚线为理论遗忘曲线（R = exp(-0.5t)），绿色实线为本地实际平均保持率随时间的变化。两条曲线越接近，说明复习节奏越科学。';

    const series = [
      {
        name: '理论遗忘曲线', color: '#4a6cf7', type: 'line', dashed: true,
        points: fc.theory.map(p => ({ x: p.t, y: p.r * 100 }))
      },
      {
        name: '实测平均保持率', color: '#22c55e', type: 'area', dots: true,
        points: fc.actual.map(p => ({ x: p.t, y: p.r * 100 }))
      }
    ];
    renderLineChart(ctx.chart, series, {
      yMin: 0, yMax: 100, yTicks: 4, xTicks: 8,
      xFormat: x => x + 'd',
      yFormat: y => Math.round(y) + '%'
    });

    if (!fc.actual.length) {
      ctx.table.innerHTML = '<div class="dash-note">暂无实测数据，去复习几次后再回来查看对比</div>';
      return;
    }

    const rows = fc.actual.slice(0, 12).map(p => {
      const theory = Math.exp(-0.5 * p.t / 1) * 100;
      const diff = p.r * 100 - theory;
      const color = diff >= 0 ? '#22c55e' : '#f59e0b';
      return [
        '第 ' + p.t + ' 天',
        '<span class="num">' + (p.r * 100).toFixed(1) + '%</span>',
        '<span class="num">' + theory.toFixed(1) + '%</span>',
        '<span class="num" style="color:' + color + '">' + (diff >= 0 ? '+' : '') + diff.toFixed(1) + '%</span>',
        '<span class="num">' + (p.n || 0) + '</span>'
      ];
    });

    ctx.table.innerHTML = tableHtml(['距上次复习', '实测保持率', '理论保持率', '差值', '样本量'], rows) +
      '<div class="dash-note">差值 > 0 说明你的记忆衰减比理论模型更慢，复习效果良好</div>';
  }

  /* ============================================================
     面板 9 · 30 天压力预测
     ============================================================ */
  function panelForecast(ctx) {
    const fc = computeForecast30();
    ctx.title.textContent = '📊 未来 30 天复习压力预测';
    ctx.hint.textContent = '柱高代表当天到期的词汇数量。绿色为今天，红色代表当天到期超过 80 词的“压力高峰”。';

    const bars = fc.map((x, i) => ({
      label: i === 0 ? '今天' : (i % 5 === 0 ? x.date.slice(5) : ''),
      value: x.count,
      color: i === 0 ? '#22c55e' : (x.count > 80 ? '#ef4444' : (x.count > 40 ? '#f59e0b' : '#4a6cf7'))
    }));
    renderBarChart(ctx.chart, bars, { barWidth: 18, padB: 34 });

    const segs = [
      { name: '第 1–7 天', from: 0, to: 7 },
      { name: '第 8–15 天', from: 7, to: 15 },
      { name: '第 16–22 天', from: 15, to: 22 },
      { name: '第 23–30 天', from: 22, to: 30 }
    ];
    const rows = segs.map(s => {
      const chunk = fc.slice(s.from, s.to);
      const total = chunk.reduce((a, b) => a + b.count, 0);
      const peak = chunk.reduce((m, x) => x.count > m.count ? x : m, chunk[0] || { count: 0, day: 0 });
      const avg = chunk.length ? total / chunk.length : 0;
      return [
        s.name,
        '<span class="num">' + total + '</span>',
        '<span class="num">' + avg.toFixed(1) + '</span>',
        '<span class="num" style="color:' + (peak.count > 80 ? '#ef4444' : '#e0e7ff') + '">' + peak.count + '</span>',
        '第 ' + peak.day + ' 天'
      ];
    });

    const totalForecast = fc.reduce((a, b) => a + b.count, 0);
    const peak = fc.reduce((m, x) => x.count > m.count ? x : m, fc[0] || { count: 0, day: 0 });

    ctx.table.innerHTML = tableHtml(['区间', '总到期词次', '日均', '峰值', '峰值日期'], rows) +
      '<div class="dash-note">30 天总复习量 <b>' + totalForecast + '</b> 词次 · 峰值 <b>' + peak.count +
      '</b> 词（第 ' + peak.day + ' 天）· ' + (totalForecast > 800
        ? '<b style="color:#f59e0b">压力偏高，建议提前分散</b>'
        : '<b style="color:#22c55e">压力可控</b>') + '</div>';
  }

  /* ============================================================
     面板 10 · 复习阶段分布
     ============================================================ */
  function panelStages(ctx) {
    const stages = computeStageStats();
    ctx.title.textContent = '🔁 复习阶段分布';
    ctx.hint.textContent = '复习间隔按 1 → 1 → 3 → 7 → 14 → 30 → 60 → 120 → 240 → 365 天逐级拉长，词汇所在的阶段越靠后，说明记忆越牢固。';

    const bars = stages.map((s, i) => ({
      label: s.label.replace(/(.{2}).*/, '$1'),
      value: s.total,
      color: ['#ef4444', '#f59e0b', '#64748b', '#22c55e', '#8b5cf6', '#4a6cf7'][i] || '#4a6cf7'
    }));
    renderBarChart(ctx.chart, bars, { barWidth: 46, padB: 44 });

    const rows = stages.map((s, i) => {
      const color = ['#ef4444', '#f59e0b', '#64748b', '#22c55e', '#8b5cf6', '#4a6cf7'][i] || '#4a6cf7';
      const retPct = Math.round(s.avgRet * 100);
      const retColor = retPct >= 70 ? '#22c55e' : (retPct >= 40 ? '#f59e0b' : '#ef4444');
      return [
        '<b style="color:' + color + '">' + s.label + '</b>',
        '<span class="num">' + s.total + '</span>',
        '<span class="num">' + s.interval + '</span>',
        '<span class="num" style="color:' + retColor + '">' + (s.total ? retPct + '%' : '—') + '</span>',
        '<span class="num" style="color:' + (s.dueN > 0 ? '#ef4444' : '#64748b') + '">' + s.dueN + '</span>'
      ];
    });

    ctx.table.innerHTML = tableHtml(['阶段', '词数', '复习间隔', '平均保持率', '已到期'], rows) +
      '<div class="dash-note">' + stages.map(s => s.label + ' ' + s.total).join(' · ') + '</div>';
  }

  function computeStageStats() {
    const today = todayStr();
    return STAGE_GROUPS.map(g => {
      let total = 0, dueN = 0, retSum = 0, retN = 0;
      for (const k in App.library) {
        if (!App.library.hasOwnProperty(k)) continue;
        const st = App.states[k] || {};
        const sg = st.stage || 0;
        if (sg < g.from || sg > g.to) continue;
        total++;
        if (st.due && st.due <= today) dueN++;
        if ((st.reviews || 0) > 0) {
          retSum += retentionRate(k, today);
          retN++;
        }
      }
      return {
        label: g.label,
        hint: g.hint,
        from: g.from, to: g.to,
        interval: INTERVALS[g.from] + (INTERVALS[g.to] !== INTERVALS[g.from] ? '~' + INTERVALS[g.to] : '') + ' 天',
        total: total,
        dueN: dueN,
        avgRet: retN ? retSum / retN : 0
      };
    });
  }

  /* ============================================================
     面板 11 · 分组统计
     ============================================================ */
  function panelGroups(ctx) {
    const gs = computeGroupStats();
    const order = ['基础词汇', '过考词汇', '核心', '未分组'];
    const keys = order.filter(k => gs[k]);

    ctx.title.textContent = '📚 分组统计';
    ctx.hint.textContent = '按词库分组统计掌握情况。基础词汇高频常用、过考词汇考点密集、核心词汇提分关键。';

    if (!keys.length) {
      ctx.chart.innerHTML = '<div class="chart-empty">暂无分组数据</div>';
      ctx.table.innerHTML = '';
      return;
    }

    const bars = keys.map(k => ({
      label: k.replace('词汇', ''),
      value: gs[k].total,
      color: GROUP_COLORS[k] || '#94a3b8'
    }));
    renderBarChart(ctx.chart, bars, { barWidth: 60, padB: 40 });

    const rows = keys.map(k => {
      const s = gs[k];
      const color = GROUP_COLORS[k] || '#94a3b8';
      const pct = s.total ? (s.mastered / s.total * 100) : 0;
      return [
        '<b style="color:' + color + '">' + k + '</b>',
        '<span class="num">' + s.total + '</span>',
        '<span class="num" style="color:#22c55e">' + s.mastered + '</span>',
        '<span class="num" style="color:#ef4444">' + s.weak + '</span>',
        '<span class="num" style="color:#64748b">' + s.untouched + '</span>',
        '<span class="num">' + (s.reviews ? (s.stageSum / s.total).toFixed(2) : '0.00') + '</span>',
        barHtml(pct, '#22c55e')
      ];
    });

    ctx.table.innerHTML = tableHtml(
      ['分组', '词数', '已掌握', '薄弱', '未学', '平均阶段', '掌握率'],
      rows
    ) + '<div class="dash-note">' +
      keys.map(k => {
        const s = gs[k];
        return k + ' 掌握率 <b>' + (s.total ? (s.mastered / s.total * 100).toFixed(1) : '0.0') + '%</b>';
      }).join(' · ') +
      '</div>';
  }

  function computeGroupStats() {
    const out = {};
    for (const k in App.library) {
      if (!App.library.hasOwnProperty(k)) continue;
      const w = App.library[k];
      const g = normalizeGroup(w.group) || '未分组';
      if (!out[g]) out[g] = {
        total: 0, mastered: 0, weak: 0, untouched: 0,
        stageSum: 0, reviews: 0
      };
      const s = out[g];
      const st = App.states[k] || {};
      s.total++;
      if (isMastered(k)) s.mastered++;
      if (isWeakGlobal(k)) s.weak++;
      if (!st.reviews) s.untouched++;
      s.stageSum += st.stage || 0;
      s.reviews += st.reviews || 0;
    }
    return out;
  }

  /* ============================================================
     面板 12 · 危机词汇 TOP
     ============================================================ */
  function panelRisk(ctx) {
    const list = computeRiskWords();
    ctx.title.textContent = '🚨 高危机词汇 TOP 12';
    ctx.hint.textContent = '风险分 = (100 - 掌握分) + 错误次数 × 3 + 混淆次数 × 5 + 逾期惩罚 15。分数越高越需要优先复习。';

    if (!list.length) {
      ctx.chart.innerHTML = '<div class="chart-empty">暂无数据</div>';
      ctx.table.innerHTML = '';
      return;
    }

    const bars = list.map(r => ({
      label: r.text,
      value: Math.round(r.risk),
      color: r.stars <= 1 ? '#ef4444' : (r.stars <= 2 ? '#f59e0b' : '#4a6cf7')
    }));
    renderBarChart(ctx.chart, bars, { barWidth: 20, padB: 46 });

    const rows = list.map((r, i) => {
      const st = App.states[r.key] || {};
      const color = r.stars <= 1 ? '#ef4444' : (r.stars <= 2 ? '#f59e0b' : '#4a6cf7');
      return [
        '<b style="color:#94a3b8">' + (i + 1) + '</b>',
        '<b>' + esc(r.text) + '</b>',
        esc((r.meaning || '').slice(0, 28)),
        '<span class="num" style="color:' + color + '">' + r.risk.toFixed(0) + '</span>',
        '<span class="num">' + r.stars + '★</span>',
        '<span class="num">' + (st.wrong || 0) + '</span>',
        '<span class="num">' + (st.confuse || 0) + '</span>',
        '<span class="num">' + (st.stage || 0) + '</span>'
      ];
    });

    ctx.table.innerHTML = tableHtml(
      ['#', '单词', '释义', '风险分', '星级', '错误', '混淆', '阶段'],
      rows
    ) + '<div class="dash-note">建议优先攻克风险分 &gt; 60 的词汇，配合「深度训练营」交叉强化</div>';
  }

  /* ============================================================
     面板 13 · 诊断结论
     ============================================================ */
  function panelInsight(ctx) {
    const insights = generateInsights();
    ctx.title.textContent = '💡 科学诊断结论与行动建议';
    ctx.hint.textContent = '基于六维能力、星级分布、遗忘曲线、学习节奏等多维数据，自动生成的针对性诊断结论。';

    const six = computeSixDim();
    const bars = [
      { label: '保持', value: six.retention, color: '#22c55e' },
      { label: '速度', value: six.speed, color: '#4a6cf7' },
      { label: '准确', value: six.accuracy, color: '#8b5cf6' },
      { label: '稳定', value: six.stability, color: '#f59e0b' },
      { label: '覆盖', value: six.coverage, color: '#06b6d4' },
      { label: '深度', value: six.depth, color: '#ec4899' }
    ];
    renderBarChart(ctx.chart, bars, { barWidth: 60, padB: 36 });

    if (!insights.length) {
      ctx.table.innerHTML = '<div class="dash-note">数据不足，去复习几轮后再来看</div>';
      return;
    }

    ctx.table.innerHTML = insights.map(i =>
      '<div class="dash-insight-item ' + (i.level || '') + '">' + i.text + '</div>'
    ).join('') +
    '<div class="dash-note">共 <b>' + insights.length + '</b> 条诊断结论 · 每 30 秒自动刷新</div>';
  }

  /* ============================================================
     事件绑定
     ============================================================ */
  window.bindDashboardEvents = function () {
    on('btnOpenDash', 'click', openDashboard);
    on('btnCloseDash', 'click', closeDashboard);

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && el('dashPage').style.display !== 'none') closeDashboard();
    });

    /* 窗口尺寸变化 → 重绘当前面板，避免 SVG 与容器尺寸失配 */
    window.addEventListener('resize', () => {
      const dash = el('dashPage');
      if (!dash || dash.style.display === 'none') return;
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => renderPanel(currentKey), 180);
    });
  };

  console.log('[dashboard] 已加载');
})();