/* ============================================================
   mastery.js — 五星掌握度模型
   掌握分 = 40×阶段分 + 30×保持率 + 20×正确率 + 10×连对
            再乘复习次数置信度(0.4~1.0)
   星级阈值：★1<30 ｜ ★2 30–50 ｜ ★3 50–70 ｜ ★4 70–85 ｜ ★5 ≥85
   ============================================================ */
(function () {
  'use strict';

  const MAX_STAGE = 9;

  /* 单次评分 → 该词当前掌握分 */
  function computeScore(key) {
    const st = App.states[key];
    const lib = App.library[key];
    if (!lib) return null;

    const stage      = st ? (st.stage || 0) : 0;
    const reviews    = st ? (st.reviews || 0) : 0;
    const wrong      = st ? (st.wrong || 0) : 0;
    const confuse    = st ? (st.confuse || 0) : 0;
    const lastRating = st ? (st.last_rating || null) : null;

    /* 1) 阶段分（0–40）：stage/9 → 0~40 */
    const stageScore = (stage / MAX_STAGE) * 40;

    /* 2) 保持率（0–30） */
    const ret = reviews ? retentionRate(key) : 0;
    const retScore = Math.min(1, Math.max(0, ret)) * 30;

    /* 3) 正确率（0–20）：熟悉+模糊算对，陌生算错，混淆算错 */
    const wrongTotal = wrong + confuse;
    const acc = reviews > 0 ? Math.max(0, (reviews - wrongTotal)) / reviews : 0;
    const accScore = Math.min(1, acc) * 20;

    /* 4) 连对分（0–10）：从 history 末尾往回数「熟悉」的连续次数 */
    let streak = 0;
    if (st && Array.isArray(st.history)) {
      for (let i = st.history.length - 1; i >= 0; i--) {
        if (st.history[i].r === '熟悉') streak++;
        else break;
      }
    }
    const streakScore = Math.min(streak, 5) * 2;

    /* 置信度：review 次数少时向下打折 */
    let conf;
    if (reviews <= 0)      conf = 0.40;
    else if (reviews <= 1) conf = 0.60;
    else if (reviews <= 3) conf = 0.75;
    else if (reviews <= 6) conf = 0.88;
    else                   conf = 1.00;

    let score = (stageScore + retScore + accScore + streakScore) * conf;

    /* 最近一次是陌生/混淆 → 再打 0.7 折 */
    if (lastRating === '陌生' || lastRating === '混淆') score *= 0.70;
    else if (lastRating === '模糊') score *= 0.88;

    score = Math.max(0, Math.min(100, score));
    const stars = starLevel(score);

    return {
      key: key,
      text: lib.text,
      meaning: lib.meaning || '',
      day: lib.day,
      group: lib.group || '',
      stage: stage,
      reviews: reviews,
      wrong: wrong,
      confuse: confuse,
      retention: ret,
      accuracy: acc,
      streak: streak,
      confidence: conf,
      score: score,
      stars: stars
    };
  }

  window.computeScore = computeScore;

  /* 全库刷新 App.mastery */
  window.refreshMastery = function () {
    const out = {};
    for (const k in App.library) {
      if (!App.library.hasOwnProperty(k)) continue;
      const m = computeScore(k);
      if (m) out[k] = m;
    }
    App.mastery = out;
    return out;
  };

  /* 提取星级 */
  window.starOf = function (key) {
    const m = App.mastery[key];
    return m ? m.stars : 1;
  };

  /* 星级按钮 HTML */
  window.starHtml = function (n, cls) {
    n = Math.max(0, Math.min(5, n | 0));
    let s = '<span class="star-cell s' + n + (cls ? ' ' + cls : '') + '">';
    for (let i = 1; i <= 5; i++) s += '<span class="' + (i <= n ? 'on' : 'off') + '">★</span>';
    s += '</span>';
    return s;
  };

  /* 星级分布统计 */
  window.starDistribution = function () {
    const dist = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    let total = 0, sum = 0;
    for (const k in App.mastery) {
      if (!App.mastery.hasOwnProperty(k)) continue;
      const m = App.mastery[k];
      dist[m.stars] = (dist[m.stars] || 0) + 1;
      sum += m.score;
      total++;
    }
    return { dist: dist, total: total, avg: total ? sum / total : 0 };
  };

  /* 难词（★1–★2）*/
  window.hardKeys = function () {
    const out = [];
    for (const k in App.mastery) {
      if (!App.mastery.hasOwnProperty(k)) continue;
      if (App.mastery[k].stars <= 2) out.push(k);
    }
    return out;
  };

  console.log('[mastery] 已加载');
})();