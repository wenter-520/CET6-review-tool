/* ============================================================
   app.js — 引导 / 事件绑定 / 视图切换
   ============================================================ */
(function () {
  'use strict';

  /* ============================================================
     标签切换
     ============================================================ */
  window.switchTab = function (name) {
    qsa('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
    const names = ['review', 'training', 'mistakes', 'curve', 'browse', 'confuse', 'stats', 'plan', 'data'];
    names.forEach(n => {
      const sec = el('tab-' + n);
      if (sec) sec.hidden = (n !== name);
    });
    App.activeTab = name;
    if (name === 'browse') renderBrowse();
    else if (name === 'confuse') renderConfuse();
    else if (name === 'curve') renderCurve();
    else if (name === 'stats') renderStats();
    else if (name === 'data') { renderData(); renderFsInfo(); }
    else if (name === 'mistakes') renderMistakes();
    else if (name === 'plan') renderPlan();
    else if (name === 'training') renderTrainingHistory();
    else if (name === 'review') { renderModeDesc(); updatePoolBar(); renderNewWordPanel(); }
  };

  /* ============================================================
     关系构建（形近 + 近义）
     ============================================================ */
  function buildRelations() {
    const keys = Object.keys(App.library);
    const rel = {};
    for (let i = 0; i < keys.length; i++) rel[keys[i]] = { syn: [], form: [] };

    /* 形近 */
    for (let i = 0; i < keys.length; i++) {
      const a = keys[i];
      if (a.length < 4 || a.indexOf(' ') >= 0) continue;
      for (let j = i + 1; j < keys.length; j++) {
        const b = keys[j];
        if (b.length < 4 || b.indexOf(' ') >= 0) continue;
        if (Math.abs(a.length - b.length) > 3) continue;
        if (a[0] !== b[0] && a.slice(0, 3) !== b.slice(0, 3)) continue;
        const d = levenshtein(a, b);
        const limit = Math.min(a.length, b.length) <= 5 ? 1 : 2;
        if (d <= limit) { rel[a].form.push(b); rel[b].form.push(a); }
      }
    }

    /* 近义 */
    const synonyms = App.synonyms || {};
    for (const k in synonyms) {
      if (!synonyms.hasOwnProperty(k)) continue;
      if (!(k in rel)) continue;
      const syns = synonyms[k];
      if (!Array.isArray(syns)) continue;
      for (let i = 0; i < syns.length; i++) {
        const t = String(syns[i]).trim().toLowerCase();
        if (!t || t === k || t.indexOf(' ') >= 0) continue;
        if (t in rel) {
          if (rel[k].syn.indexOf(t) < 0) rel[k].syn.push(t);
          if (rel[t].syn.indexOf(k) < 0) rel[t].syn.push(k);
        }
      }
    }
    return rel;
  }

  /* ============================================================
     指示器 / 欢迎
     ============================================================ */
  function updateWdIndicator(connected, name) {
    const ind = el('wdIndicator');
    const lab = el('wdLabel');
    if (!ind || !lab) return;
    if (connected) {
      ind.className = 'wd-indicator connected';
      lab.innerHTML = '数据目录：<b>' + esc(name) + '</b>';
    } else {
      ind.className = 'wd-indicator';
      lab.textContent = '未连接数据目录';
    }
  }

  function showWelcomeError(icon, title, subHtml, actionsHtml) {
    el('welcomeIcon').textContent = icon;
    el('welcomeTitle').textContent = title;
    el('welcomeSub').innerHTML = subHtml;
    const actions = el('welcomeActions');
    if (actionsHtml) {
      actions.style.display = '';
      actions.innerHTML = actionsHtml;
    } else {
      actions.style.display = 'none';
    }
  }

  function fileProtocolHelp() {
    showWelcomeError(
      '🔒',
      '需要通过本地服务器打开',
      '浏览器安全策略禁止 <code>file://</code> 页面直接读取同级文件。<br>请在 <b>CET6</b> 文件夹打开终端，运行以下命令后访问对应网址：',
      '<button class="btn btn-primary btn-lg" id="btnCopyCmd">📋 复制启动命令</button>'
    );
    el('welcomeActions').onclick = function () {
      const cmd = 'python -m http.server 8000';
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(cmd).then(
          () => showToast('已复制：' + cmd, 'ok'),
          () => showToast('复制失败，请手动输入：' + cmd, 'warn')
        );
      } else {
        showToast('请手动输入：' + cmd, 'warn');
      }
    };
  }

  function dataNotFoundHelp() {
    showWelcomeError(
      '📁',
      '未找到词库文件',
      '程序已在 <code>' + esc(Store.base ? Store.base.href : '') + '</code> 下搜索，但没有找到 <code>*.xlsx</code> 词库文件。<br>请检查目录结构是否与下方一致：',
      '<button class="btn btn-primary btn-lg" id="btnRetryLoad">🔄 重新检测</button>'
    );
    el('welcomeActions').onclick = function () { bootstrap(); };
  }

  /* ============================================================
     文件绑定信息渲染
     ============================================================ */
  function renderFsInfo() {
    const box = el('fsInfo');
    if (!box) return;
    if (typeof FileSync === 'undefined') {
      box.innerHTML = '<span style="color:var(--warn)">⚠ filesync.js 未加载</span>';
      return;
    }
    if (!FileSync.isSupported()) {
      box.innerHTML = '<span style="color:var(--warn)">⚠ 当前浏览器不支持 File System Access API。请使用「📦 导出全部数据」手动备份。</span>';
      return;
    }
    if (!FileSync.dirHandle) {
      box.innerHTML = '未绑定数据目录。建议点击「📂 绑定数据目录」，选择 <code>CET6/词汇复习程序/.userdata/</code> 或任意空目录。';
      return;
    }
    let extra = '';
    if (FileSync.lastWriteAt) extra += ' · 最近写入：<b>' + esc(FileSync.lastWriteAt) + '</b>';
    if (FileSync.lastError) extra += ' · <span style="color:var(--bad)">错误：' + esc(FileSync.lastError) + '</span>';
    box.innerHTML =
      '✅ 已绑定目录：<b>' + esc(FileSync.dirHandle.name) + '</b>' + extra +
      '<br><span style="color:var(--text-m)">每次答题后自动写入（1.5 秒合并一次）。</span>';
  }
  window.renderFsInfo = renderFsInfo;

  /* ============================================================
     引导
     ============================================================ */
  async function bootstrap() {
    el('welcomeIcon').textContent = '⏳';
    el('welcomeTitle').textContent = '正在连接数据目录…';
    el('welcomeSub').innerHTML = '按相对路径自动定位词库与用户数据';
    el('welcomeActions').style.display = 'none';

    if (location.protocol === 'file:') { fileProtocolHelp(); return; }

    const ok = await Store.init();
    if (!ok) {
      Store.base = new URL('../', location.href);
      Store.files = [];
    }

    try {
      /* ---------- 恢复数据目录句柄（如果有绑定） ---------- */
      try {
        if (typeof FileSync !== 'undefined') {
          const state = await FileSync.restoreHandle();
          console.log('[bootstrap] FileSync.restoreHandle =', state);
        }
      } catch (e) {
        console.warn('[bootstrap] 恢复目录绑定失败', e);
      }

      /* ---------- 加载用户数据（三方合并） ---------- */
      const savedStates = await loadUserdata();
      await loadAuxData();
      const r = await loadLibrary();

      App.library = r.library;
      App.days = r.days;
      App.loadInfo = {
        studyFiles: r.studyFiles,
        skipped: r.skipped,
        typos: r.typos,
        byGroup: r.byGroup,
        byGroupDay: r.byGroupDay
      };

      if (!Object.keys(App.library).length) { dataNotFoundHelp(); return; }

      App.states = rebuildStates(savedStates);
      const degraded = applyOverdueDegradation();
      App.relations = buildRelations();

      refreshMastery();

      App.meta.lastLoaded = nowISO();
      await saveMeta();
      await saveSettings();
      await saveMastery();

      const dayNums = Object.keys(App.days).map(Number).filter(n => n > 0);
      if (dayNums.length === 1) App.selectedDay = dayNums[0];

      App.ready = true;

      el('welcomePage').style.display = 'none';
      el('mainPage').style.display = '';
      el('headerInfo').style.display = '';
      el('btnReload').style.display = '';
      el('btnOpenDash').style.display = '';
      updateWdIndicator(true, decodeURIComponent(Store.base.pathname || Store.base.href));

      initTrainingUI();

      safe('renderDayBar', renderDayBar);
      safe('renderModeDesc', renderModeDesc);
      safe('updateHeader', updateHeader);
      safe('updatePoolBar', updatePoolBar);
      safe('renderNewWordPanel', renderNewWordPanel);
      safe('renderBrowse', renderBrowse);
      safe('renderConfuse', renderConfuse);
      safe('renderMistakes', renderMistakes);
      safe('renderCurve', renderCurve);
      safe('renderStats', renderStats);
      safe('renderData', renderData);
      safe('renderFsInfo', renderFsInfo);
      safe('renderPlan', renderPlan);
      safe('renderTrainingHistory', renderTrainingHistory);

      let extra = '';
      if (degraded > 0) extra += '，逾期自动降级 ' + degraded + ' 词';
      showToast('已连接数据目录，加载 ' + Object.keys(App.library).length + ' 词' + extra, 'ok');
    } catch (e) {
      console.error('[bootstrap]', e);
      showWelcomeError('⚠️', '加载失败', esc(e.message), '');
    }
  }

  /* ============================================================
     事件绑定
     ============================================================ */
  function bindAll() {
    /* tab */
    qsa('.tab').forEach(tab => {
      tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    /* 日切换 */
    on('dayBtnAll', 'click', () => selectDay('all'));

    /* 复习控制 */
    on('btnStart', 'click', startSession);
    on('btnFlip', 'click', flipCard);
    on('btnPrev', 'click', goPrev);
    on('btnSkip', 'click', skipWord);

    /* 模式 */
    qsa('.mode-btn[data-mode]').forEach(btn => {
      btn.addEventListener('click', () => {
        qsa('.mode-btn[data-mode]').forEach(b => b.classList.toggle('on', b === btn));
        App.mode = btn.dataset.mode;
        renderModeDesc();
        updatePoolBar();
      });
    });

    /* 分组 */
    qsa('.group-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        qsa('.group-btn').forEach(b => b.classList.toggle('on', b === btn));
        App.groupFilter = btn.dataset.group === 'all' ? 'all' : btn.dataset.group;
        renderModeDesc();
        updatePoolBar();
      });
    });

    /* 评分按钮 */
    qsa('.rate-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.disabled) return;
        rate(btn.dataset.r);
      });
    });

    /* 总览筛选 */
    ['bSearch', 'bGroup', 'bState', 'bStage', 'bErrors', 'bRet'].forEach(id => {
      on(id, id === 'bSearch' ? 'input' : 'change', renderBrowse);
    });
    if (el('bStars')) on('bStars', 'change', renderBrowse);
    on('bRefresh', 'click', renderBrowse);

    /* 易混 */
    on('cFilter', 'change', renderConfuse);
    on('cRefresh', 'click', renderConfuse);

    /* 错题本 */
    on('btnReviewAllMistakes', 'click', () => {
      const keys = getMistakeKeys('all');
      if (!keys.length) { showToast('暂无错题', 'warn'); return; }
      startQueueFromKeys(keys, 'weak', '错题重练');
    });
    on('btnReviewConfused', 'click', () => {
      const keys = getMistakeKeys('confused');
      if (!keys.length) { showToast('暂无混淆词', 'warn'); return; }
      startQueueFromKeys(keys, 'weak', '混淆词重练');
    });
    on('btnReviewWrong', 'click', () => {
      const keys = getMistakeKeys('wrong');
      if (!keys.length) { showToast('暂无错误词', 'warn'); return; }
      startQueueFromKeys(keys, 'weak', '错误词重练');
    });

    /* 新词学习 —— 一次学完全部 */
    on('btnStudyAllNew', 'click', () => {
      const keys = allUntouchedKeys();
      if (!keys.length) { showToast('没有未复习的新词', 'warn'); return; }
      startQueueFromKeys(keys, 'new', '新词学习');
    });

    /* 深度训练 */
    on('btnTrainStart', 'click', startTraining);

    /* 学习计划 */
    on('btnGenPlan', 'click', () => {
      generateLearningPlan();
      savePlan();
      renderPlan();
      showToast('学习计划已重新生成', 'ok');
    });
    on('btnExportPlan', 'click', exportPlan);

    /* 导出 */
    on('btnExportMaster', 'click', exportMaster);
    on('btnPreviewMaster', 'click', previewMaster);
    on('btnExportMastery', 'click', exportMastery);
    on('btnExportMistakes', 'click', exportMistakes);
    on('btnExportWeak', 'click', exportWeak);
    on('btnExportDaily', 'click', exportDaily);
    on('btnExportSessions', 'click', exportSessions);
    on('btnExportTraining', 'click', exportTraining);

    /* ============================================================
       数据目录绑定
       ============================================================ */
    on('btnBindDir', 'click', async () => {
      if (typeof FileSync === 'undefined') { showToast('filesync.js 未加载', 'err'); return; }
      const h = await FileSync.bindDirectory();
      if (!h) return;

      /* 读目录内容 → 与当前状态合并 */
      const data = await FileSync.readAll();
      if (data && (data.states || Object.keys(data.sessions || {}).length)) {
        if (data.states) {
          const cur = App.states || {};
          for (const k in data.states) {
            if (!data.states.hasOwnProperty(k)) continue;
            const a = cur[k], b = data.states[k];
            if (!a) cur[k] = b;
            else if (!b) continue;
            else cur[k] = ((a.reviews || 0) >= (b.reviews || 0)) ? a : b;
          }
          App.states = rebuildStates(cur);
        }
        if (data.sessions) {
          for (const d in data.sessions) {
            if (!data.sessions.hasOwnProperty(d)) continue;
            const a = (App.sessions || {})[d], b = data.sessions[d];
            if (!a) App.sessions[d] = b;
            else if (!b) continue;
            else {
              const aN = (a.sessions || []).length;
              const bN = (b.sessions || []).length;
              App.sessions[d] = (aN >= bN) ? a : b;
            }
          }
        }
        if (data.training) {
          for (const d in data.training) {
            if (!data.training.hasOwnProperty(d)) continue;
            if (!App.training[d]) App.training[d] = data.training[d];
            else App.training[d] = App.training[d].concat(data.training[d]);
          }
        }
        if (data.meta)     App.meta = Object.assign({}, App.meta || {}, data.meta);
        if (data.settings) App.settings = Object.assign({}, DEFAULT_SETTINGS, data.settings);
        if (data.mastery)  App.mastery = Object.assign({}, App.mastery || {}, data.mastery);
        if (data.plan)     App.plan = data.plan;

        refreshMastery();
        await idbSet('states', window.snapshotStates());
        await idbSet('sessions', App.sessions);
        await idbSet('training', App.training);

        renderDayBar();
        updateHeader();
        updatePoolBar();
        renderNewWordPanel();
        renderBrowse();
        renderMistakes();
        renderCurve();
        renderStats();
        renderData();
        renderPlan();

        showToast('已合并目录数据：' +
          Object.keys(App.sessions).length + ' 天会话', 'ok');
      }

      await FileSync.writeAll();
      renderFsInfo();
    });

    on('btnSyncNow', 'click', async () => {
      if (typeof FileSync === 'undefined' || !FileSync.dirHandle) {
        showToast('请先绑定数据目录', 'warn'); return;
      }
      const ok = await FileSync.writeAll();
      renderFsInfo();
      showToast(ok ? '已同步到目录：' + FileSync.dirHandle.name : '同步失败', ok ? 'ok' : 'err');
    });

    on('btnUnbindDir', 'click', async () => {
      if (typeof FileSync === 'undefined') return;
      if (!confirm('解除绑定？目录文件会保留，浏览器内的数据也会保留。')) return;
      await FileSync.unbind();
      renderFsInfo();
    });

    /* ============================================================
       设置
       ============================================================ */
    on('btnSaveSettings', 'click', async () => {
      const num = (id, def, min, max) => {
        let v = parseInt(el(id).value, 10);
        if (isNaN(v)) v = def;
        if (v < min) v = min;
        if (v > max) v = max;
        return v;
      };
      App.settings.dailyNewLimit = num('setNewLimit', 30, 0, 500);
      App.settings.dailyReviewLimit = num('setReviewLimit', 120, 0, 1000);
      App.settings.overdueDays = num('setOverdueDays', 3, 1, 30);
      App.settings.fastMs = num('setFastMs', 2000, 500, 10000);
      App.settings.slowMs = num('setSlowMs', 10000, 2000, 60000);
      App.settings.trainBatch = num('setTrainBatch', 12, 4, 50);
      App.settings.colWord = num('setColWord', 0, 0, 10);
      App.settings.colMeaning = num('setColMeaning', 1, 0, 10);
      App.settings.colTag = num('setColTag', 2, 0, 10);
      App.settings.libPrefix = (el('setLibPrefix').value || '').trim();

      await saveSettings();
      showToast('设置已保存', 'ok');
      renderModeDesc();
      updatePoolBar();
      renderNewWordPanel();
      if (el('trainBatch')) el('trainBatch').value = String(App.settings.trainBatch);
    });

    on('btnResetSettings', 'click', async () => {
      if (!confirm('恢复默认设置？')) return;
      App.settings = Object.assign({}, DEFAULT_SETTINGS);
      await saveSettings();
      renderData();
      showToast('已恢复默认', 'ok');
    });

    /* 辅助数据重载 */
    on('btnReloadAux', 'click', async () => {
      if (!Store.base) { showToast('未连接数据目录', 'warn'); return; }
      try {
        await loadAuxData();
        App.relations = buildRelations();
        renderConfuse();
        renderData();
        showToast('辅助数据已重新加载', 'ok');
      } catch (e) {
        console.error('[reloadAux]', e);
        showToast('重新加载失败：' + e.message, 'err');
      }
    });

    /* 待复习清单组 */
    const dueListEl = el('dueList');
    if (dueListEl) {
      dueListEl.addEventListener('click', e => {
        let t = e.target;
        while (t && t !== dueListEl && !(t.getAttribute && t.getAttribute('data-due'))) t = t.parentNode;
        if (!t || t === dueListEl) return;
        const v = t.getAttribute('data-due');
        const sched = computeSchedule();
        let keys = [], label = '到期复习';
        if (v === 'overdue') { keys = sched.overdue.slice(); label = '逾期补复习'; }
        else if (v === 'today') { keys = (sched.dueByDate[sched.today] || []).slice(); label = '今日到期复习'; }
        else { keys = (sched.dueByDate[v] || []).slice(); label = v + ' 到期复习'; }
        startQueueFromKeys(keys, 'due', label);
      });
    }

    /* 阶段组 */
    const stagePlanEl = el('stagePlan');
    if (stagePlanEl) {
      stagePlanEl.addEventListener('click', e => {
        let t = e.target;
        while (t && t !== stagePlanEl && !(t.getAttribute && t.getAttribute('data-stage-from'))) t = t.parentNode;
        if (!t || t === stagePlanEl) return;
        const from = parseInt(t.getAttribute('data-stage-from'), 10);
        const to = parseInt(t.getAttribute('data-stage-to'), 10);
        const today = todayStr();
        const keys = [];
        const all = Object.keys(App.library);
        for (let i = 0; i < all.length; i++) {
          const k = all[i], st = App.states[k];
          if (!st || !st.due) continue;
          const sg = st.stage || 0;
          if (sg < from || sg > to) continue;
          if (st.due <= today) keys.push(k);
        }
        startQueueFromKeys(keys, 'due', '阶段复习');
      });
    }

    on('btnStartAllDue', 'click', () => {
      const sched = computeSchedule();
      const keys = sched.overdue.concat(sched.dueByDate[sched.today] || []);
      if (!keys.length) { showToast('当前没有到期的词', 'warn'); return; }
      startQueueFromKeys(keys, 'due', '全部到期复习');
    });

    /* 重载词库 */
    on('btnReload', 'click', async () => {
      if (!Store.base) return;
      showToast('正在重载词库…');
      try {
        await Store.init();
        const savedStates = await loadUserdata();
        await loadAuxData();
        const r = await loadLibrary();
        App.library = r.library;
        App.days = r.days;
        App.loadInfo = {
          studyFiles: r.studyFiles,
          skipped: r.skipped,
          typos: r.typos,
          byGroup: r.byGroup,
          byGroupDay: r.byGroupDay
        };
        App.states = rebuildStates(savedStates);
        applyOverdueDegradation();
        App.relations = buildRelations();
        refreshMastery();
        renderDayBar();
        renderModeDesc();
        updateHeader();
        updatePoolBar();
        renderNewWordPanel();
        renderBrowse();
        renderConfuse();
        renderMistakes();
        renderCurve();
        renderStats();
        renderData();
        renderFsInfo();
        renderPlan();
        renderTrainingHistory();
        showToast('已重载：' + Object.keys(App.library).length + ' 词', 'ok');
      } catch (e) {
        console.error('[reload]', e);
        showToast('重载失败：' + e.message, 'err');
      }
    });

    /* ============================================================
       全量备份 / 恢复 / 清空
       ============================================================ */
    on('btnBackupAll', 'click', async () => {
      try {
        downloadJSON('cet6-backup-' + todayStr() + '.json', {
          version: 3,
          exported_at: nowISO(),
          states:   App.states   || {},
          sessions: App.sessions || {},
          meta:     App.meta     || {},
          settings: App.settings || {},
          training: App.training || {},
          mastery:  App.mastery  || {},
          plan:     App.plan     || null
        });
        showToast('已导出全部数据', 'ok');
      } catch (e) {
        console.error('[backup]', e);
        showToast('导出失败：' + e.message, 'err');
      }
    });

    on('btnRestoreAll', 'click', () => el('restoreFile').click());

    /* ============================================================
       从 JSON 恢复（合并 / 覆盖二选一）
       ============================================================ */
    on('restoreFile', 'change', e => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const data = JSON.parse(reader.result);
          if (!data || typeof data !== 'object') throw new Error('文件格式不正确');

          const merge = confirm(
            '导入方式：\n\n' +
            '【确定】= 合并（推荐，保留当前数据和备份的并集）\n' +
            '【取消】= 覆盖（完全替换当前数据）'
          );

          if (merge) {
            /* ---- 合并模式 ---- */
            const curStates = App.states || {};
            if (data.states) {
              for (const k in data.states) {
                if (!data.states.hasOwnProperty(k)) continue;
                const a = curStates[k], b = data.states[k];
                if (!a) curStates[k] = b;
                else if (!b) continue;
                else curStates[k] = ((a.reviews || 0) >= (b.reviews || 0)) ? a : b;
              }
            }

            if (data.sessions) {
              for (const d in data.sessions) {
                if (!data.sessions.hasOwnProperty(d)) continue;
                const a = (App.sessions || {})[d], b = data.sessions[d];
                if (!a) App.sessions[d] = b;
                else if (!b) continue;
                else {
                  const aN = (a.sessions || []).length;
                  const bN = (b.sessions || []).length;
                  App.sessions[d] = (aN >= bN) ? a : b;
                }
              }
            }

            if (data.training) {
              for (const d in data.training) {
                if (!data.training.hasOwnProperty(d)) continue;
                if (!App.training[d]) App.training[d] = data.training[d];
                else App.training[d] = App.training[d].concat(data.training[d]);
              }
            }

            if (data.meta)     App.meta = Object.assign({}, App.meta || {}, data.meta);
            if (data.settings) App.settings = Object.assign({}, DEFAULT_SETTINGS, data.settings);
            if (data.mastery)  App.mastery = Object.assign({}, App.mastery || {}, data.mastery);
            if (data.plan)     App.plan = data.plan;

            App.states = rebuildStates(App.states);
            refreshMastery();
            await idbSet('states', window.snapshotStates());
            await idbSet('sessions', App.sessions);
            await idbSet('training', App.training);

            showToast('已合并导入：' +
              Object.keys(App.sessions).length + ' 天会话，' +
              Object.keys(App.states).length + ' 条状态', 'ok');
          } else {
            /* ---- 覆盖模式 ---- */
            if (!confirm('⚠ 将用备份完全替换当前数据，此操作不可撤销，继续？')) return;
            if (data.states)   App.states = data.states;
            if (data.sessions) App.sessions = data.sessions;
            if (data.meta)     App.meta = data.meta;
            if (data.settings) App.settings = Object.assign({}, DEFAULT_SETTINGS, data.settings);
            if (data.training) App.training = data.training;
            if (data.mastery)  App.mastery = data.mastery;
            if (data.plan)     App.plan = data.plan;

            await idbSet('states', data.states || {});
            await idbSet('sessions', data.sessions || {});
            await idbSet('meta', data.meta || {});
            await idbSet('settings', App.settings);
            await idbSet('training', data.training || {});
            await idbSet('mastery', data.mastery || {});
            if (data.plan) await idbSet('plan', data.plan);

            showToast('已覆盖导入，正在重新加载…', 'ok');
          }

          /* 导入后如果绑定了目录，同步写回 */
          if (typeof FileSync !== 'undefined' && FileSync.dirHandle) {
            setTimeout(() => { FileSync.writeAll(); }, 800);
          }

          setTimeout(() => location.reload(), 900);
        } catch (err) {
          console.error('[restore]', err);
          showToast('导入失败：' + err.message, 'err');
        } finally {
          el('restoreFile').value = '';
        }
      };
      reader.readAsText(f);
    });

    on('btnClearStates', 'click', async () => {
      if (!confirm('确定清空所有学习记录吗？\n这会删除浏览器本地保存的全部学习数据，不可恢复。')) return;
      await idbDel('states');
      await idbDel('sessions');
      await idbDel('meta');
      await idbDel('training');
      await idbDel('mastery');
      await idbDel('plan');
      App.sessions = {};
      App.training = {};
      App.plan = null;
      App.states = rebuildStates({});
      refreshMastery();
      await saveStates();
      updateHeader();
      updatePoolBar();
      renderBrowse();
      renderMistakes();
      renderCurve();
      renderStats();
      renderData();
      renderFsInfo();
      renderPlan();
      renderTrainingHistory();
      renderNewWordPanel();
      showToast('学习记录已清空', 'ok');
    });

    /* ============================================================
       键盘快捷键
       ============================================================ */
    document.addEventListener('keydown', e => {
      if (App.activeTab !== 'review') return;
      const tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;

      if (e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
        const fb = el('btnFlip');
        if (fb && !fb.disabled) flipCard();
        return;
      }
      if (e.key === 'ArrowLeft' || e.key === 'Backspace') {
        e.preventDefault();
        const pb = el('btnPrev');
        if (pb && !pb.disabled) goPrev();
        return;
      }
      if (e.key === 's' || e.key === 'S' || e.key === 'ArrowRight') {
        e.preventDefault();
        const sb = el('btnSkip');
        if (sb && !sb.disabled) skipWord();
        return;
      }
      if (['1', '2', '3', '4'].indexOf(e.key) >= 0 && App.session && App.currentKey) {
        rate(RATINGS[parseInt(e.key, 10) - 1]);
      }
    });

    /* 大屏事件 */
    if (typeof bindDashboardEvents === 'function') bindDashboardEvents();
  }

  /* ============================================================
     启动
     ============================================================ */
  function init() {
    bindAll();
    bootstrap();
    console.log('[CET6 v10] 初始化完成（目录自动写 + 三方合并）');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else setTimeout(init, 0);

  /* 导出给其他模块调用 */
  window.__bootstrap = bootstrap;
})();