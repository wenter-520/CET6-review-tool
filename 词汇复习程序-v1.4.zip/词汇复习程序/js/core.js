/* ============================================================
   core.js — 全局常量 / 工具函数 / App 状态
   ============================================================ */
(function () {
  'use strict';

  /* ---------- 常量 ---------- */
  window.RATINGS = ['熟悉', '模糊', '陌生', '混淆'];
  window.RATING_COLORS = { 熟悉: '#22c55e', 模糊: '#f59e0b', 陌生: '#ef4444', 混淆: '#8b5cf6' };
  window.INTERVALS = [1, 1, 3, 7, 14, 30, 60, 120, 240, 365];

  window.STAGE_GROUPS = [
    { from: 0, to: 1, label: '初始巩固', hint: '学完当天 → 隔 1 天' },
    { from: 2, to: 2, label: '短期强化', hint: '隔 3 天再复习' },
    { from: 3, to: 3, label: '中期巩固', hint: '隔 7 天再复习' },
    { from: 4, to: 4, label: '长期记忆', hint: '隔 14 天再复习' },
    { from: 5, to: 5, label: '深度记忆', hint: '隔 30 天再复习' },
    { from: 6, to: 9, label: '条件反射', hint: '隔 60 天以上' }
  ];

  window.DAY_RE = /第\s*([0-9一二三四五六七八九十两零]+)\s*天/;
  window.CN_DIGITS = { 零: 0, 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
  window.UNFAMILIAR_RATINGS = { 模糊: 1, 陌生: 1, 混淆: 1 };

  window.GROUP_ORDER = ['基础词汇', '过考词汇', '核心'];
  window.GROUP_ALIASES = { 基础: '基础词汇', 过考: '过考词汇', 核心词汇: '核心' };
  window.GROUP_WEIGHT = { 基础词汇: 0, 过考词汇: 1, 核心: 2 };
  window.GROUP_COLORS = { 基础词汇: '#4a6cf7', 过考词汇: '#8b5cf6', 核心: '#f59e0b' };
  window.GROUP_HINTS = {
    '基础词汇': '高频常用，务必一次性掌握',
    '过考词汇': '考点密集，重点记忆搭配与辨析',
    '核心': '提分关键，反复消化直至条件反射'
  };

  window.INVALID_TOKENS = {
    '': 1, 'false': 1, 'true': 1, 'none': 1, 'null': 1, 'nan': 1, 'n/a': 1,
    '单词': 1, '词汇': 1, '意思': 1, '适用': 1, '日期': 1,
    '基础词汇': 1, '过考词汇': 1, '核心': 1, '核心词汇': 1
  };

  window.AUX_SYNONYMS     = 'synonyms.json';
  window.AUX_TYPO_HINTS   = 'typo_hints.json';
  window.AUX_COLLOCATIONS = 'collocations.json';
  window.AUX_PLAN         = 'learning_plan.json';

  window.EXPORT_NAMES = [
    '熟悉度总表', '错题明细', '弱项清单', '每日答题记录', '会话明细',
    '训练记录', 'vocabulary_mastery', 'learning_plan', 'cet6-backup'
  ];

  window.SEED_TYPO_HINTS = {
    'selffish': 'selfish', 'lauch': 'launch', 'livehood': 'livelihood',
    'italian': 'Italian', 'guarentee': 'guarantee'
  };

  /* ---------- 默认设置 ---------- */
  window.DEFAULT_SETTINGS = {
    dailyNewLimit: 30,
    dailyReviewLimit: 120,
    overdueDays: 3,
    fastMs: 2000,
    slowMs: 10000,
    trainBatch: 12,
    libPrefix: '',
    colWord: 0,
    colMeaning: 1,
    colTag: 2
  };

  /* ---------- 全局状态 ---------- */
  window.App = {
    library: {},
    days: {},
    states: {},
    relations: {},
    synonyms: {},
    typoHints: {},
    collocations: {},
    mastery: {},
    training: {},
    plan: null,
    meta: { vocabSnapshot: {}, lastLoaded: null },
    sessions: {},
    settings: Object.assign({}, window.DEFAULT_SETTINGS),
    loadInfo: { skipped: [], typos: [], byGroup: {}, byGroupDay: {}, studyFiles: [] },
    session: null, sessionReasons: {}, currentKey: null,
    cardFlipped: false, cardStartTs: 0,
    mode: 'review', groupFilter: 'all', activeTab: 'review', selectedDay: 'all',
    trainSession: null,
    ready: false,
    _sched: null,
    _dashTimer: null
  };

  /* ---------- DOM ---------- */
  window.el  = function (id) { return document.getElementById(id); };
  window.qs  = function (sel, root) { return (root || document).querySelector(sel); };
  window.qsa = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  window.on  = function (id, evt, fn) {
    const e = el(id);
    if (!e) { console.warn('[bind] missing #' + id); return; }
    e.addEventListener(evt, fn);
  };
  window.safe = function (name, fn) {
    try { fn(); } catch (e) { console.error('[' + name + ']', e); }
  };

  /* ---------- 时间 ---------- */
  window.pad2 = function (n) { return n < 10 ? '0' + n : '' + n; };
  window.todayStr = function () {
    const d = new Date();
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  };
  window.nowISO = function () {
    const d = new Date();
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + 'T' +
      pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  };
  window.addDays = function (dateStr, n) {
    const d = new Date(dateStr + 'T00:00:00');
    d.setDate(d.getDate() + n);
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  };
  window.daysBetween = function (a, b) {
    const da = new Date(a + 'T00:00:00'), db = new Date(b + 'T00:00:00');
    return Math.round((db - da) / 86400000);
  };

  /* ---------- 杂项 ---------- */
  window.uid = function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
  };
  window.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  window.deepClone = function (obj) {
    if (obj == null) return obj;
    try { return JSON.parse(JSON.stringify(obj)); } catch (e) { return null; }
  };

  window.showToast = function (msg, type) {
    const e = el('toast'); if (!e) return;
    e.textContent = msg;
    e.className = 'toast show ' + (type || '');
    clearTimeout(e._t);
    e._t = setTimeout(function () { e.classList.remove('show'); }, 2600);
  };

  window.setSavingState = function (state, text) {
    const e = el('saveIndicator'); if (!e) return;
    if (state === 'hide') { e.classList.remove('show'); return; }
    e.classList.add('show');
    e.classList.remove('saving', 'saved');
    e.classList.add(state);
    e.textContent = text;
    if (state === 'saved') setTimeout(function () { e.classList.remove('show'); }, 1200);
  };

  /* ---------- 中文数字 ---------- */
  window.cnToInt = function (s) {
    s = String(s || '').trim(); if (!s) return null;
    if (/^\d+$/.test(s)) return parseInt(s, 10);
    if (s.indexOf('十') >= 0) {
      const p = s.split('十'), l = p[0], r = p[1];
      return (l ? (CN_DIGITS[l] != null ? CN_DIGITS[l] : 1) : 1) * 10 + (r ? (CN_DIGITS[r] != null ? CN_DIGITS[r] : 0) : 0);
    }
    if (s.length === 1 && s in CN_DIGITS) return CN_DIGITS[s];
    let n = 0;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (!(c in CN_DIGITS)) return null;
      n = n * 10 + CN_DIGITS[c];
    }
    return n;
  };

  window.parseDayLabel = function (text) {
    if (!text) return null;
    const m = DAY_RE.exec(String(text));
    return m ? cnToInt(m[1]) : null;
  };

  /* ---------- 分组 ---------- */
  window.normalizeGroup = function (name) {
    if (!name) return '';
    name = String(name).trim();
    return GROUP_ALIASES[name] || name;
  };
  window.groupWeight = function (name) {
    const g = normalizeGroup(name);
    return (g in GROUP_WEIGHT) ? GROUP_WEIGHT[g] : -1;
  };

  /* ---------- 单词过滤 ---------- */
  window.isValidWord = function (text) {
    if (!text) return false;
    const low = text.toLowerCase();
    if (low in INVALID_TOKENS) return false;
    if (/^[\u4e00-\u9fa5\s]+$/.test(text)) return false;
    if (/^[\d\s.\-/:]+$/.test(text)) return false;
    return true;
  };
  window.detectTypo = function (text) {
    return App.typoHints[String(text).toLowerCase()] || null;
  };

  /* ---------- 编辑距离 ---------- */
  window.levenshtein = function (a, b) {
    if (a === b) return 0;
    const la = a.length, lb = b.length;
    if (!la) return lb; if (!lb) return la;
    let prev = [];
    for (let i = 0; i <= lb; i++) prev[i] = i;
    for (let i = 1; i <= la; i++) {
      const cur = [i];
      for (let j = 1; j <= lb; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      }
      prev = cur;
    }
    return prev[lb];
  };

  /* ---------- 星级通用辅助 ---------- */
  window.starText = function (n, ch) {
    ch = ch || '★';
    n = Math.max(0, Math.min(5, n | 0));
    let s = '';
    for (let i = 0; i < 5; i++) s += (i < n ? ch : '☆');
    return s;
  };
  window.starLevel = function (score) {
    if (score < 30) return 1;
    if (score < 50) return 2;
    if (score < 70) return 3;
    if (score < 85) return 4;
    return 5;
  };
  window.starColor = function (n) {
    return ['', '#ef4444', '#f59e0b', '#64748b', '#22c55e', '#8b5cf6'][n] || '#94a3b8';
  };

  console.log('[core] 已加载');
})();