/* ============================================================
   filesync.js — 文件系统同步（.userdata 目录专用）
   首次点按钮选择目录，之后完全自动
   ============================================================ */
(function () {
  'use strict';

  const SUPPORTED = typeof window.showDirectoryPicker === 'function';

  /* 目录选择器 id —— 浏览器会记住用户上次选的位置 */
  const PICKER_ID = 'cet6-userdata-v1';

  const IDB_HANDLE_KEY = 'fsDirHandle';
  const SESSIONS_DIR = 'sessions';

  /* 目标目录名（用于校验用户是否选对了） */
  const TARGET_DIR_NAME = '.userdata';

  const pending = {
    states: false,
    meta: false,
    settings: false,
    mastery: false,
    training: false,
    plan: false,
    sessions: {}
  };
  let writeTimer = null;
  let writeChain = Promise.resolve();

  function enqueue(fn) {
    writeChain = writeChain.then(fn).catch(e => {
      console.error('[fsync]', e);
      FileSync.lastError = e.message || String(e);
      updateFsIndicator('error');
    });
    return writeChain;
  }

  async function saveHandleToIDB(handle) {
    try { await idbSet(IDB_HANDLE_KEY, handle); }
    catch (e) { console.warn('[fsync] 保存句柄失败', e); }
  }
  async function loadHandleFromIDB() {
    try { return await idbGet(IDB_HANDLE_KEY); }
    catch (e) { return null; }
  }
  async function deleteHandleFromIDB() {
    try { await idbDel(IDB_HANDLE_KEY); } catch (e) {}
  }

  async function getFileHandle(fileName, create) {
    const root = FileSync.dirHandle;
    if (!root) throw new Error('未绑定目录');
    return await root.getFileHandle(fileName, { create: !!create });
  }
  async function getSessionsDir(create) {
    const root = FileSync.dirHandle;
    if (!root) throw new Error('未绑定目录');
    return await root.getDirectoryHandle(SESSIONS_DIR, { create: !!create });
  }

  async function readJsonFile(fileName) {
    try {
      const fh = await getFileHandle(fileName, false);
      const file = await fh.getFile();
      const text = await file.text();
      if (!text.trim()) return null;
      return JSON.parse(text);
    } catch (e) {
      if (e.name === 'NotFoundError') return null;
      console.warn('[fsync] readJsonFile ' + fileName, e);
      return null;
    }
  }
  async function readSessionJson(date) {
    try {
      const dir = await getSessionsDir(false);
      const fh = await dir.getFileHandle(date + '.json', { create: false });
      const file = await fh.getFile();
      const text = await file.text();
      if (!text.trim()) return null;
      return JSON.parse(text);
    } catch (e) {
      if (e.name === 'NotFoundError') return null;
      console.warn('[fsync] readSessionJson ' + date, e);
      return null;
    }
  }
  async function listSessionDates() {
    try {
      const dir = await getSessionsDir(false);
      const out = [];
      for await (const [name, handle] of dir.entries()) {
        if (handle.kind !== 'file') continue;
        const m = /^(\d{4}-\d{2}-\d{2})\.json$/.exec(name);
        if (m) out.push(m[1]);
      }
      out.sort();
      return out;
    } catch (e) {
      return [];
    }
  }

  async function writeJsonFile(fileName, data) {
    const fh = await getFileHandle(fileName, true);
    const writable = await fh.createWritable();
    await writable.write(JSON.stringify(data, null, 2));
    await writable.close();
  }
  async function writeSessionJson(date, data) {
    const dir = await getSessionsDir(true);
    const fh = await dir.getFileHandle(date + '.json', { create: true });
    const writable = await fh.createWritable();
    await writable.write(JSON.stringify(data, null, 2));
    await writable.close();
  }

  async function checkPermission(handle, request) {
    if (!handle) return false;
    const opts = { mode: 'readwrite' };
    let perm = 'prompt';
    try { perm = await handle.queryPermission(opts); }
    catch (e) { return false; }
    if (perm === 'granted') return true;
    if (request) {
      try { perm = await handle.requestPermission(opts); }
      catch (e) { return false; }
      return perm === 'granted';
    }
    return false;
  }

  /* ============================================================
     FileSync 主体
     ============================================================ */
  const FileSync = {
    dirHandle: null,
    lastWriteAt: null,
    lastError: null,

    isSupported() { return SUPPORTED; },

    /* ---------- 校验目录名是否是 .userdata ---------- */
    _validateDirName(name) {
      /* 允许用户选择任意目录，但给个提示 */
      if (name === TARGET_DIR_NAME) return true;
      return false;  /* 不强制，返回 false 只用于提示 */
    },

    /* ---------- 绑定目录（用户点按钮触发） ---------- */
    async bindDirectory() {
      if (!SUPPORTED) {
        showToast('当前浏览器不支持文件系统访问，请用 Chrome / Edge / Opera', 'warn');
        return null;
      }
      try {
        const opts = {
          id: PICKER_ID,
          mode: 'readwrite'
        };
        /* 如果之前绑定过，startIn 指定到上次的句柄 */
        if (this.dirHandle) {
          opts.startIn = this.dirHandle;
        }
        const handle = await window.showDirectoryPicker(opts);

        /* 校验目录名（仅警告，不阻断） */
        if (handle.name !== TARGET_DIR_NAME) {
          const ok = confirm(
            '你选择的目录是：' + handle.name + '\n' +
            '推荐选择 .userdata 文件夹（在 CET6/词汇复习程序/ 下）。\n\n' +
            '仍要使用当前目录吗？'
          );
          if (!ok) return null;
        }

        const perm = await checkPermission(handle, true);
        if (!perm) { showToast('未获得读写权限', 'warn'); return null; }

        this.dirHandle = handle;
        this.lastError = null;
        await saveHandleToIDB(handle);
        updateFsIndicator('bound');

        /* 记住 IDB 里也保存一份目录名，便于下次显示 */
        try { await idbSet('fsDirName', handle.name); } catch (e) {}

        showToast('已绑定数据目录：' + handle.name, 'ok');
        return handle;
      } catch (e) {
        if (e.name === 'AbortError') return null;
        console.error('[fsync] bindDirectory', e);
        showToast('绑定失败：' + e.message, 'err');
        return null;
      }
    },

    /* ---------- 启动时自动恢复（完全静默） ---------- */
    async restoreHandle() {
      if (!SUPPORTED) return 'unsupported';
      const handle = await loadHandleFromIDB();
      if (!handle) return 'none';

      try {
        /* 检查目录是否还存在 */
        try {
          await handle.getFileHandle('.__probe__', { create: false });
        } catch (e) {
          if (e.name === 'NotFoundError') {
            /* 文件不存在是正常的，只要不是句柄错误就 OK */
          }
        }
      } catch (e) {
        console.warn('[fsync] 句柄已失效', e);
        await deleteHandleFromIDB();
        return 'none';
      }

      this.dirHandle = handle;
      const perm = await checkPermission(handle, false);

      if (perm) {
        /* 完全自动，无需交互 */
        updateFsIndicator('bound');
        console.log('[fsync] 已自动恢复目录：', handle.name);
        return 'granted';
      } else {
        /* 权限过期，需要用户点一次按钮 */
        updateFsIndicator('needs-permission');
        console.log('[fsync] 目录权限过期，需用户授权：', handle.name);
        return 'needs-permission';
      }
    },

    /* 需要用户交互才能重新授权 */
    async requestPermission() {
      if (!this.dirHandle) return false;
      const ok = await checkPermission(this.dirHandle, true);
      if (ok) {
        this.lastError = null;
        updateFsIndicator('bound');
        showToast('已授权，可以自动写文件了', 'ok');
        /* 授权后立刻做一次全量同步 */
        setTimeout(() => { this.writeAll(); }, 100);
        return true;
      }
      showToast('未授权', 'warn');
      return false;
    },

    async unbind() {
      this.dirHandle = null;
      this.lastWriteAt = null;
      this.lastError = null;
      await deleteHandleFromIDB();
      try { await idbDel('fsDirName'); } catch (e) {}
      updateFsIndicator('none');
      showToast('已解除目录绑定（浏览器内数据仍然保留）', 'ok');
    },

    /* ---------- 读取全量 ---------- */
    async readAll() {
      if (!this.dirHandle) return null;
      const ok = await checkPermission(this.dirHandle, false);
      if (!ok) return null;

      const out = {
        states:   await readJsonFile('states.json'),
        meta:     await readJsonFile('meta.json'),
        settings: await readJsonFile('settings.json'),
        mastery:  await readJsonFile('mastery.json'),
        training: await readJsonFile('training.json'),
        plan:     await readJsonFile('plan.json'),
        sessions: {}
      };

      const dates = await listSessionDates();
      for (const d of dates) {
        const s = await readSessionJson(d);
        if (s) out.sessions[d] = s;
      }

      console.log('[fsync] readAll:', {
        states: out.states ? Object.keys(out.states).length : 0,
        sessions: Object.keys(out.sessions).length
      });
      return out;
    },

    /* ---------- 全量写入 ---------- */
    async writeAll() {
      if (!this.dirHandle) return false;
      const ok = await checkPermission(this.dirHandle, true);
      if (!ok) { updateFsIndicator('needs-permission'); return false; }

      return enqueue(async () => {
        try {
          await writeJsonFile('states.json', window.snapshotStates());
          await writeJsonFile('meta.json', App.meta || {});
          await writeJsonFile('settings.json', App.settings || {});
          await writeJsonFile('mastery.json', App.mastery || {});
          await writeJsonFile('training.json', App.training || {});
          if (App.plan) await writeJsonFile('plan.json', App.plan);

          const dates = Object.keys(App.sessions || {});
          for (const d of dates) {
            await writeSessionJson(d, App.sessions[d]);
          }

          this.lastWriteAt = nowISO();
          this.lastError = null;
          updateFsIndicator('bound');
          return true;
        } catch (e) {
          console.error('[fsync] writeAll', e);
          this.lastError = e.message || String(e);
          updateFsIndicator('error');
          return false;
        }
      });
    },

    /* ---------- 单个文件写入 ---------- */
    async writeStates() {
      if (!this.dirHandle) return false;
      return enqueue(async () => {
        await writeJsonFile('states.json', window.snapshotStates());
        this.lastWriteAt = nowISO();
      });
    },
    async writeMeta() {
      if (!this.dirHandle) return false;
      return enqueue(async () => {
        await writeJsonFile('meta.json', App.meta || {});
        this.lastWriteAt = nowISO();
      });
    },
    async writeSettings() {
      if (!this.dirHandle) return false;
      return enqueue(async () => {
        await writeJsonFile('settings.json', App.settings || {});
        this.lastWriteAt = nowISO();
      });
    },
    async writeMastery() {
      if (!this.dirHandle) return false;
      return enqueue(async () => {
        await writeJsonFile('mastery.json', App.mastery || {});
        this.lastWriteAt = nowISO();
      });
    },
    async writeTraining() {
      if (!this.dirHandle) return false;
      return enqueue(async () => {
        await writeJsonFile('training.json', App.training || {});
        this.lastWriteAt = nowISO();
      });
    },
    async writePlan() {
      if (!this.dirHandle) return false;
      return enqueue(async () => {
        if (App.plan) await writeJsonFile('plan.json', App.plan);
        this.lastWriteAt = nowISO();
      });
    },
    async writeSession(date) {
      if (!this.dirHandle) return false;
      const data = (App.sessions || {})[date];
      if (!data) return false;
      return enqueue(async () => {
        await writeSessionJson(date, data);
        this.lastWriteAt = nowISO();
      });
    },

    /* ---------- 节流调度 ---------- */
    markDirty(type, arg) {
      if (!this.dirHandle) return;
      if (type === 'session') {
        pending.sessions[arg] = true;
      } else {
        pending[type] = true;
      }
      clearTimeout(writeTimer);
      writeTimer = setTimeout(() => { this.flush(); }, 1500);
      updateFsIndicator('writing');
    },

    /* ---------- 立即冲刷 ---------- */
    async flush() {
      if (!this.dirHandle) return;
      clearTimeout(writeTimer);
      writeTimer = null;

      const toWriteStates   = pending.states;
      const toWriteMeta     = pending.meta;
      const toWriteSettings = pending.settings;
      const toWriteMastery  = pending.mastery;
      const toWriteTraining = pending.training;
      const toWritePlan     = pending.plan;
      const sessionDates    = Object.keys(pending.sessions);

      pending.states = false;
      pending.meta = false;
      pending.settings = false;
      pending.mastery = false;
      pending.training = false;
      pending.plan = false;
      pending.sessions = {};

      if (!toWriteStates && !toWriteMeta && !toWriteSettings && !toWriteMastery &&
          !toWriteTraining && !toWritePlan && sessionDates.length === 0) {
        return;
      }

      const ok = await checkPermission(this.dirHandle, false);
      if (!ok) { updateFsIndicator('needs-permission'); return; }

      enqueue(async () => {
        try {
          if (toWriteStates)   await writeJsonFile('states.json', window.snapshotStates());
          if (toWriteMeta)     await writeJsonFile('meta.json', App.meta || {});
          if (toWriteSettings) await writeJsonFile('settings.json', App.settings || {});
          if (toWriteMastery)  await writeJsonFile('mastery.json', App.mastery || {});
          if (toWriteTraining) await writeJsonFile('training.json', App.training || {});
          if (toWritePlan && App.plan) await writeJsonFile('plan.json', App.plan);
          for (const d of sessionDates) {
            const data = (App.sessions || {})[d];
            if (data) await writeSessionJson(d, data);
          }
          this.lastWriteAt = nowISO();
          this.lastError = null;
          updateFsIndicator('bound');
          setSavingState('saved', '✓ 已写入文件');
        } catch (e) {
          console.error('[fsync] flush', e);
          this.lastError = e.message || String(e);
          updateFsIndicator('error');
          setSavingState('saving', '⚠ 写文件失败');
        }
      });
    }
  };

  /* ============================================================
     顶部指示器状态机
     ============================================================ */
  window.updateFsIndicator = function (status) {
    const ind = el('fsIndicator');
    const lab = el('fsLabel');
    if (!ind || !lab) return;

    ind.onclick = null;
    ind.style.cursor = 'default';

    switch (status) {
      case 'bound': {
        const name = FileSync.dirHandle ? FileSync.dirHandle.name : '.userdata';
        ind.className = 'wd-indicator connected';
        const extra = FileSync.lastWriteAt ? ' · ' + FileSync.lastWriteAt.slice(11, 19) : '';
        lab.innerHTML = '💾 <b>' + esc(name) + '</b>' + extra;
        break;
      }
      case 'writing': {
        const name = FileSync.dirHandle ? FileSync.dirHandle.name : '.userdata';
        ind.className = 'wd-indicator pending';
        lab.innerHTML = '💾 写入中：<b>' + esc(name) + '</b>…';
        break;
      }
      case 'needs-permission': {
        const name = FileSync.dirHandle ? FileSync.dirHandle.name : '.userdata';
        ind.className = 'wd-indicator pending';
        ind.style.cursor = 'pointer';
        lab.innerHTML = '⚠ 点此授权访问 <b>' + esc(name) + '</b>';
        ind.onclick = async () => { await FileSync.requestPermission(); };
        break;
      }
      case 'error': {
        ind.className = 'wd-indicator pending';
        lab.innerHTML = '⚠ 写入失败：' + esc(FileSync.lastError || '未知错误');
        break;
      }
      case 'unsupported':
        ind.className = 'wd-indicator';
        lab.textContent = '当前浏览器不支持目录同步';
        break;
      default:
        ind.className = 'wd-indicator';
        lab.textContent = SUPPORTED ? '未绑定 .userdata' : '当前浏览器不支持目录同步';
    }
  };

  window.FileSync = FileSync;

  /* 页面卸载/切后台前冲刷 */
  window.addEventListener('beforeunload', () => {
    if (FileSync.dirHandle) FileSync.flush();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden' && FileSync.dirHandle) FileSync.flush();
  });

  console.log('[fsync] 已加载，API 支持：' + SUPPORTED);
})();