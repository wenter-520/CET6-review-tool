@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo  CET6 词汇复习 - 本地服务器
echo  目录：%CD%
echo  按 Ctrl+C 停止服务器
echo ========================================

start "" http://localhost:8000/start.html

python -m http.server 8000